<?php
require_once 'config.php';
include 'includes/header.php';

// Handle customer actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'add') {
        $first_name = $conn->real_escape_string($_POST['first_name']);
        $last_name = $conn->real_escape_string($_POST['last_name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $address = $conn->real_escape_string($_POST['address']);
        $city = $conn->real_escape_string($_POST['city']);
        $customer_type = $conn->real_escape_string($_POST['customer_type']);
        
        $sql = "INSERT INTO customers (first_name, last_name, email, phone, address, city, customer_type) 
                VALUES ('$first_name', '$last_name', '$email', '$phone', '$address', '$city', '$customer_type')";
        
        if ($conn->query($sql)) {
            echo "<script>window.onload = function() { showToast('Customer added successfully!'); }</script>";
        }
    }
}

// Get statistics
$total_customers = $conn->query("SELECT COUNT(*) as count FROM customers")->fetch_assoc()['count'] ?? 0;
$active_customers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE status='active'")->fetch_assoc()['count'] ?? 0;
$vip_customers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE customer_type='vip'")->fetch_assoc()['count'] ?? 0;
$wholesale_customers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE customer_type='wholesale'")->fetch_assoc()['count'] ?? 0;

// Get customers with order stats
$customers = $conn->query("
    SELECT c.*, 
           COUNT(o.id) as total_orders,
           COALESCE(SUM(o.total_amount), 0) as total_spent,
           MAX(o.order_date) as last_order
    FROM customers c
    LEFT JOIN orders o ON c.id = o.customer_id
    GROUP BY c.id
    ORDER BY c.created_at DESC
");
?>

<!-- Customers Page Content -->
<div class="page-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-text">
            <h1>Customer Management</h1>
            <p>View and manage your customer database</p>
        </div>
        <button class="btn btn-primary" onclick="openAddCustomerModal()">
            <i class="fas fa-user-plus"></i>
            Add Customer
        </button>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #6d5acf 0%, #a78bfa 100%)">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-details">
                <h3>TOTAL CUSTOMERS</h3>
                <p class="stat-value"><?php echo $total_customers; ?></p>
                <span class="stat-trend positive">Registered users</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%)">
                <i class="fas fa-user-check"></i>
            </div>
            <div class="stat-details">
                <h3>ACTIVE</h3>
                <p class="stat-value"><?php echo $active_customers; ?></p>
                <span class="stat-trend positive"><?php echo $total_customers ? round(($active_customers/$total_customers)*100, 1) : 0; ?>% active</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #f97316 0%, #fb923c 100%)">
                <i class="fas fa-crown"></i>
            </div>
            <div class="stat-details">
                <h3>VIP</h3>
                <p class="stat-value"><?php echo $vip_customers; ?></p>
                <span class="stat-trend positive">Premium customers</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #ef4444 0%, #f87171 100%)">
                <i class="fas fa-briefcase"></i>
            </div>
            <div class="stat-details">
                <h3>WHOLESALE</h3>
                <p class="stat-value"><?php echo $wholesale_customers; ?></p>
                <span class="stat-trend positive">Business accounts</span>
            </div>
        </div>
    </div>

    <!-- Customer Demographics -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px;">
        <div class="table-wrapper">
            <h3 style="margin-bottom: 15px;">Top Locations</h3>
            <div style="display: flex; flex-direction: column; gap: 10px;">
                <?php
                $locations = $conn->query("SELECT city, COUNT(*) as count FROM customers WHERE city IS NOT NULL GROUP BY city ORDER BY count DESC LIMIT 5");
                if ($locations && $locations->num_rows > 0):
                    while($loc = $locations->fetch_assoc()):
                ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span><?php echo htmlspecialchars($loc['city']); ?></span>
                        <span style="font-weight: 600;"><?php echo $loc['count']; ?></span>
                    </div>
                <?php 
                    endwhile;
                else:
                ?>
                    <p style="color: var(--gray);">No location data</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="table-wrapper">
            <h3 style="margin-bottom: 15px;">Customer Type</h3>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <?php
                $types = $conn->query("SELECT customer_type, COUNT(*) as count FROM customers GROUP BY customer_type");
                $type_colors = ['regular' => 'var(--primary)', 'vip' => '#f97316', 'wholesale' => '#10b981'];
                while($type = $types->fetch_assoc()):
                    $percentage = $total_customers ? round(($type['count']/$total_customers)*100, 1) : 0;
                ?>
                    <div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span><?php echo ucfirst($type['customer_type']); ?></span>
                            <span><?php echo $type['count']; ?> (<?php echo $percentage; ?>%)</span>
                        </div>
                        <div style="width: 100%; height: 8px; background: #f3f4f6; border-radius: 4px;">
                            <div style="width: <?php echo $percentage; ?>%; height: 100%; background: <?php echo $type_colors[$type['customer_type']]; ?>; border-radius: 4px;"></div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        
        <div class="table-wrapper">
            <h3 style="margin-bottom: 15px;">Recent Activity</h3>
            <div style="display: flex; flex-direction: column; gap: 12px;">
                <?php
                $recent = $conn->query("
                    SELECT c.first_name, c.last_name, o.order_number, o.order_date 
                    FROM customers c 
                    JOIN orders o ON c.id = o.customer_id 
                    ORDER BY o.order_date DESC 
                    LIMIT 5
                ");
                if ($recent && $recent->num_rows > 0):
                    while($act = $recent->fetch_assoc()):
                ?>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="width: 32px; height: 32px; background: #f3f4f6; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-user" style="font-size: 14px;"></i>
                        </div>
                        <div>
                            <p style="font-weight: 500;"><?php echo htmlspecialchars($act['first_name'] . ' ' . $act['last_name']); ?></p>
                            <p style="font-size: 12px; color: var(--gray);">Order #<?php echo $act['order_number']; ?></p>
                        </div>
                        <span style="margin-left: auto; font-size: 12px; color: var(--gray);"><?php echo date('M d', strtotime($act['order_date'])); ?></span>
                    </div>
                <?php 
                    endwhile;
                endif;
                ?>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="filters-section" style="margin-bottom: 20px;">
        <div class="filter-group">
            <label>Type:</label>
            <select id="typeFilter" class="filter-select" onchange="filterCustomers()">
                <option value="">All Types</option>
                <option value="regular">Regular</option>
                <option value="vip">VIP</option>
                <option value="wholesale">Wholesale</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label>Status:</label>
            <select id="statusFilter" class="filter-select" onchange="filterCustomers()">
                <option value="">All</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label>Sort by:</label>
            <select id="sortFilter" class="filter-select" onchange="sortCustomers()">
                <option value="newest">Newest First</option>
                <option value="name">Name A-Z</option>
                <option value="orders">Most Orders</option>
                <option value="spent">Highest Spent</option>
            </select>
        </div>
        
        <button class="btn btn-secondary" onclick="exportCustomers()">
            <i class="fas fa-download"></i>
            Export List
        </button>
    </div>

    <!-- Customers Table -->
    <div class="table-wrapper">
        <table class="products-table">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Contact</th>
                    <th>Type</th>
                    <th>Total Orders</th>
                    <th>Total Spent</th>
                    <th>Status</th>
                    <th>Last Order</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="customersTableBody">
                <?php if ($customers && $customers->num_rows > 0): ?>
                    <?php while($customer = $customers->fetch_assoc()): 
                        $type_colors = [
                            'regular' => '#f3f4f6',
                            'vip' => '#f97316',
                            'wholesale' => '#10b981'
                        ];
                        $type_color = $type_colors[$customer['customer_type']] ?? '#f3f4f6';
                        $text_color = in_array($customer['customer_type'], ['vip', 'wholesale']) ? 'white' : 'var(--dark)';
                    ?>
                        <tr>
                            <td class="product-cell">
                                <div class="product-info">
                                    <div class="product-icon" style="background: <?php echo $type_color; ?>; color: <?php echo $text_color; ?>;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="product-details">
                                        <h4><?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></h4>
                                        <p>Member since <?php echo date('M Y', strtotime($customer['created_at'])); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($customer['email']); ?><br>
                                <small><?php echo htmlspecialchars($customer['phone'] ?? 'No phone'); ?></small>
                            </td>
                            <td>
                                <span class="category-badge" style="background: <?php echo $type_color; ?>; color: <?php echo $text_color; ?>;">
                                    <?php echo ucfirst($customer['customer_type']); ?>
                                </span>
                            </td>
                            <td><?php echo $customer['total_orders']; ?> orders</td>
                            <td class="price-cell">$<?php echo number_format($customer['total_spent'], 2); ?></td>
                            <td>
                                <span class="status-badge <?php echo $customer['status'] == 'active' ? 'status-instock' : 'status-out'; ?>">
                                    <?php echo ucfirst($customer['status']); ?>
                                </span>
                            </td>
                            <td><?php echo $customer['last_order'] ? date('M d, Y', strtotime($customer['last_order'])) : 'Never'; ?></td>
                            <td class="actions-cell">
                                <button class="action-btn view" onclick='viewCustomer(<?php echo json_encode($customer); ?>)' title="View">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit" onclick='editCustomer(<?php echo $customer['id']; ?>)' title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn delete" onclick="deleteCustomer(<?php echo $customer['id']; ?>)" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            No customers found. Click "Add Customer" to get started.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Customer Modal -->
<div id="customerModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add New Customer</h2>
            <button class="close-btn" onclick="closeCustomerModal()"><i class="fas fa-times"></i></button>
        </div>
        
        <form method="POST">
            <input type="hidden" name="action" value="add">
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> First Name</label>
                    <input type="text" name="first_name" placeholder="Enter first name" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Last Name</label>
                    <input type="text" name="last_name" placeholder="Enter last name" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" placeholder="customer@example.com" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> Phone</label>
                    <input type="text" name="phone" placeholder="+1 234 567 8900">
                </div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-map-marker-alt"></i> Address</label>
                <input type="text" name="address" placeholder="Street address">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-city"></i> City</label>
                    <input type="text" name="city" placeholder="City">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Customer Type</label>
                    <select name="customer_type">
                        <option value="regular">Regular</option>
                        <option value="vip">VIP</option>
                        <option value="wholesale">Wholesale</option>
                    </select>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Save Customer
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeCustomerModal()">
                    <i class="fas fa-times"></i>
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openAddCustomerModal() {
    document.getElementById('customerModal').style.display = 'block';
}

function closeCustomerModal() {
    document.getElementById('customerModal').style.display = 'none';
}

function viewCustomer(customer) {
    showToast('View customer feature coming soon!');
}

function editCustomer(id) {
    showToast('Edit customer feature coming soon!');
}

function deleteCustomer(id) {
    if (confirm('Are you sure you want to delete this customer?')) {
        showToast('Delete feature coming soon!');
    }
}

function filterCustomers() {
    const type = document.getElementById('typeFilter').value;
    const status = document.getElementById('statusFilter').value;
    showToast(`Filtering by: ${type} type, ${status} status`);
}

function sortCustomers() {
    const sortBy = document.getElementById('sortFilter').value;
    showToast(`Sorting by: ${sortBy}`);
}

function exportCustomers() {
    showToast('Exporting customer list...');
}

function handleSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#customersTableBody tr');
    
    rows.forEach(row => {
        if (row.cells.length > 1) {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        }
    });
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('customerModal');
    if (event.target == modal) {
        closeCustomerModal();
    }
}
</script>

<?php include 'includes/footer.php'; ?>