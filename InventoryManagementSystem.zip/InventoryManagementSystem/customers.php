<?php
ob_start();
require_once 'config.php';
requireLogin();

// Get customers
$customers = $conn->query("SELECT * FROM customers ORDER BY created_at DESC");

// Get customer statistics
$totalCustomers = $conn->query("SELECT COUNT(*) as count FROM customers")->fetch_assoc()['count'] ?? 0;
$activeCustomers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE status='active'")->fetch_assoc()['count'] ?? 0;
$vipCustomers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE customer_type='vip'")->fetch_assoc()['count'] ?? 0;
$wholesaleCustomers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE customer_type='wholesale'")->fetch_assoc()['count'] ?? 0;

require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Customer Management</h1>
        <p>Manage your customers</p>
    </div>
    <button class="btn btn-primary" onclick="openAddCustomerModal()">
        <i class="fas fa-user-plus"></i>
        Add Customer
    </button>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL CUSTOMERS</h3>
            <p class="stat-value"><?php echo $totalCustomers; ?></p>
            <span class="stat-trend positive">Registered</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-user-check"></i>
        </div>
        <div class="stat-details">
            <h3>ACTIVE</h3>
            <p class="stat-value"><?php echo $activeCustomers; ?></p>
            <span class="stat-trend positive"><?php echo $totalCustomers ? round(($activeCustomers/$totalCustomers)*100, 1) : 0; ?>%</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-crown"></i>
        </div>
        <div class="stat-details">
            <h3>VIP</h3>
            <p class="stat-value"><?php echo $vipCustomers; ?></p>
            <span class="stat-trend positive">Premium</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-briefcase"></i>
        </div>
        <div class="stat-details">
            <h3>WHOLESALE</h3>
            <p class="stat-value"><?php echo $wholesaleCustomers; ?></p>
            <span class="stat-trend positive">Business</span>
        </div>
    </div>
</div>

<div class="table-wrapper">
    <table class="products-table" id="customersTable">
        <thead>
            <tr>
                <th>Customer</th>
                <th>Contact</th>
                <th>Type</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($customers && $customers->num_rows > 0): ?>
                <?php while($customer = $customers->fetch_assoc()): 
                    $type_colors = [
                        'regular' => 'var(--bg-secondary)',
                        'vip' => '#f39c12',
                        'wholesale' => '#00b894'
                    ];
                    $type_color = $type_colors[$customer['customer_type']] ?? 'var(--bg-secondary)';
                    $text_color = in_array($customer['customer_type'], ['vip', 'wholesale']) ? 'white' : 'var(--text-primary)';
                ?>
                    <tr data-customer-id="<?php echo $customer['id']; ?>">
                        <td class="product-cell">
                            <div class="product-info">
                                <div class="product-icon" style="background: <?php echo $type_color; ?>; color: <?php echo $text_color; ?>;">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="product-details">
                                    <h4 style="color: var(--text-primary);"><?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></h4>
                                </div>
                            </div>
                        </td>
                        <td style="color: var(--text-primary);"><?php echo htmlspecialchars($customer['email']); ?></td>
                        <td>
                            <span class="category-badge" style="background: <?php echo $type_color; ?>; color: <?php echo $text_color; ?>; border: none;">
                                <?php echo ucfirst($customer['customer_type']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="status-badge <?php echo $customer['status'] == 'active' ? 'status-instock' : 'status-out'; ?>">
                                <?php echo ucfirst($customer['status']); ?>
                            </span>
                        </td>
                        <td class="actions-cell">
                            <button class="action-btn view" onclick='openCustomerViewModal(<?php echo json_encode($customer); ?>)' title="View"><i class="fas fa-eye"></i></button>
                            <button class="action-btn edit" onclick='openCustomerEditModal(<?php echo json_encode($customer); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="action-btn delete" onclick='openDeleteCustomerModal(<?php echo $customer['id']; ?>, <?php echo json_encode($customer['first_name'] . ' ' . $customer['last_name']); ?>)' title="Delete"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'include/footer.php'; ?>