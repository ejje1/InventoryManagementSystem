<?php
require_once 'config.php';
include 'includes/header.php';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['save_general'])) {
        // Save general settings
        $store_name = $conn->real_escape_string($_POST['store_name']);
        $timezone = $conn->real_escape_string($_POST['timezone']);
        $currency = $conn->real_escape_string($_POST['currency']);
        $date_format = $conn->real_escape_string($_POST['date_format']);
        
        $conn->query("INSERT INTO settings (setting_key, setting_value) VALUES 
            ('store_name', '$store_name'),
            ('timezone', '$timezone'),
            ('currency', '$currency'),
            ('date_format', '$date_format')
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        
        echo "<script>window.onload = function() { showToast('Settings saved successfully!'); }</script>";
    }
}

// Get current settings
$settings = [];
$result = $conn->query("SELECT setting_key, setting_value FROM settings");
while($row = $result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<!-- Settings Page Content -->
<div class="page-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-text">
            <h1>Settings</h1>
            <p>Configure your system preferences</p>
        </div>
        <button class="btn btn-primary" onclick="saveAllSettings()">
            <i class="fas fa-save"></i>
            Save Changes
        </button>
    </div>

    <!-- Settings Navigation -->
    <div style="display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;">
        <button class="settings-tab active" onclick="switchTab('general')" id="tab-general">
            <i class="fas fa-sliders-h"></i> General
        </button>
        <button class="settings-tab" onclick="switchTab('notifications')" id="tab-notifications">
            <i class="fas fa-bell"></i> Notifications
        </button>
        <button class="settings-tab" onclick="switchTab('security')" id="tab-security">
            <i class="fas fa-shield-alt"></i> Security
        </button>
        <button class="settings-tab" onclick="switchTab('users')" id="tab-users">
            <i class="fas fa-users-cog"></i> Users & Roles
        </button>
        <button class="settings-tab" onclick="switchTab('backup')" id="tab-backup">
            <i class="fas fa-database"></i> Backup
        </button>
        <button class="settings-tab" onclick="switchTab('integrations')" id="tab-integrations">
            <i class="fas fa-plug"></i> Integrations
        </button>
        <button class="settings-tab" onclick="switchTab('company')" id="tab-company">
            <i class="fas fa-building"></i> Company
        </button>
    </div>

    <!-- General Settings -->
    <div id="general-settings" class="settings-section active-section">
        <form method="POST" class="table-wrapper">
            <input type="hidden" name="save_general" value="1">
            <h3 style="margin-bottom: 25px;">General Settings</h3>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 30px;">
                <div>
                    <div class="form-group">
                        <label><i class="fas fa-store"></i> Store Name</label>
                        <input type="text" name="store_name" value="<?php echo $settings['store_name'] ?? 'StockFlow Inventory'; ?>" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-globe"></i> Timezone</label>
                        <select name="timezone" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                            <option value="UTC-8" <?php echo ($settings['timezone'] ?? '') == 'UTC-8' ? 'selected' : ''; ?>>UTC-8 (Pacific Time)</option>
                            <option value="UTC-5" <?php echo ($settings['timezone'] ?? '') == 'UTC-5' ? 'selected' : ''; ?>>UTC-5 (Eastern Time)</option>
                            <option value="UTC+0" <?php echo ($settings['timezone'] ?? '') == 'UTC+0' ? 'selected' : ''; ?>>UTC+0 (GMT)</option>
                            <option value="UTC+1" <?php echo ($settings['timezone'] ?? '') == 'UTC+1' ? 'selected' : ''; ?>>UTC+1 (Central European)</option>
                            <option value="UTC+8" <?php echo ($settings['timezone'] ?? '') == 'UTC+8' ? 'selected' : ''; ?>>UTC+8 (Singapore)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-language"></i> Language</label>
                        <select name="language" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                            <option value="en" selected>English (US)</option>
                            <option value="en-gb">English (UK)</option>
                            <option value="es">Spanish</option>
                            <option value="fr">French</option>
                            <option value="de">German</option>
                        </select>
                    </div>
                </div>
                
                <div>
                    <div class="form-group">
                        <label><i class="fas fa-money-bill-wave"></i> Currency</label>
                        <select name="currency" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                            <option value="USD" <?php echo ($settings['currency'] ?? 'USD') == 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                            <option value="EUR" <?php echo ($settings['currency'] ?? '') == 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                            <option value="GBP" <?php echo ($settings['currency'] ?? '') == 'GBP' ? 'selected' : ''; ?>>GBP (£)</option>
                            <option value="JPY" <?php echo ($settings['currency'] ?? '') == 'JPY' ? 'selected' : ''; ?>>JPY (¥)</option>
                            <option value="CAD" <?php echo ($settings['currency'] ?? '') == 'CAD' ? 'selected' : ''; ?>>CAD ($)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Date Format</label>
                        <select name="date_format" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                            <option value="m/d/Y" <?php echo ($settings['date_format'] ?? 'm/d/Y') == 'm/d/Y' ? 'selected' : ''; ?>>MM/DD/YYYY</option>
                            <option value="d/m/Y" <?php echo ($settings['date_format'] ?? '') == 'd/m/Y' ? 'selected' : ''; ?>>DD/MM/YYYY</option>
                            <option value="Y-m-d" <?php echo ($settings['date_format'] ?? '') == 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> Time Format</label>
                        <select name="time_format" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                            <option value="12" selected>12-hour (AM/PM)</option>
                            <option value="24">24-hour</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 30px;">
                <h4 style="margin-bottom: 15px;">System Preferences</h4>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="checkbox" name="auto_updates" checked> Enable automatic inventory updates
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="checkbox" name="low_stock_alerts" checked> Show low stock alerts
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="checkbox" name="guest_checkout"> Enable guest checkout
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="checkbox" name="email_notifications" checked> Enable email notifications
                </label>
            </div>
            
            <div class="form-actions" style="margin-top: 30px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Save General Settings
                </button>
            </div>
        </form>
    </div>

    <!-- Notifications Settings -->
    <div id="notifications-settings" class="settings-section">
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px;">Notification Preferences</h3>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 30px;">
                <div>
                    <h4 style="margin-bottom: 15px;">Email Notifications</h4>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox" checked> New order placed
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox" checked> Low stock alert
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox" checked> New customer registration
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox"> Daily summary report
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox"> Weekly performance report
                    </label>
                </div>
                
                <div>
                    <h4 style="margin-bottom: 15px;">System Notifications</h4>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox" checked> System updates
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox" checked> Security alerts
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox"> Backup completion
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox"> Error reports
                    </label>
                </div>
            </div>
            
            <div style="margin-top: 30px;">
                <h4 style="margin-bottom: 15px;">Notification Methods</h4>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="radio" name="notification_method" checked> Email
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="radio" name="notification_method"> SMS
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="radio" name="notification_method"> Both
                </label>
            </div>
            
            <div class="form-actions" style="margin-top: 30px;">
                <button class="btn btn-primary" onclick="saveSettings('notifications')">
                    <i class="fas fa-save"></i>
                    Save Notification Settings
                </button>
            </div>
        </div>
    </div>

    <!-- Security Settings -->
    <div id="security-settings" class="settings-section">
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px;">Security Settings</h3>
            
            <div style="margin-bottom: 30px;">
                <h4 style="margin-bottom: 15px;">Password Policy</h4>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                    <div class="form-group">
                        <label>Minimum password length</label>
                        <input type="number" value="8" min="6" max="20" style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                    </div>
                    <div class="form-group">
                        <label>Password expiry (days)</label>
                        <input type="number" value="90" min="0" style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                    </div>
                </div>
                
                <div style="margin-top: 15px;">
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <input type="checkbox"> Require special characters
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <input type="checkbox"> Require numbers
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <input type="checkbox"> Require uppercase letters
                    </label>
                </div>
            </div>
            
            <div style="margin-bottom: 30px;">
                <h4 style="margin-bottom: 15px;">Two-Factor Authentication</h4>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="checkbox"> Enable 2FA for all users
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                    <input type="checkbox" checked> Require 2FA for admin accounts
                </label>
            </div>
            
            <div>
                <h4 style="margin-bottom: 15px;">Session Settings</h4>
                <div class="form-group">
                    <label>Session timeout (minutes)</label>
                    <input type="number" value="30" style="width: 200px; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                </div>
            </div>
            
            <div class="form-actions" style="margin-top: 30px;">
                <button class="btn btn-primary" onclick="saveSettings('security')">
                    <i class="fas fa-save"></i>
                    Save Security Settings
                </button>
            </div>
        </div>
    </div>

    <!-- Users & Roles Settings -->
    <div id="users-settings" class="settings-section">
        <div class="table-wrapper">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h3>User Management</h3>
                <button class="btn btn-primary" onclick="addNewUser()">
                    <i class="fas fa-user-plus"></i>
                    Add User
                </button>
            </div>
            
            <table class="products-table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
                    if ($users && $users->num_rows > 0):
                        while($user = $users->fetch_assoc()):
                    ?>
                        <tr>
                            <td class="product-cell">
                                <div class="product-info">
                                    <div class="product-icon" style="background: var(--primary); color: white;">
                                        <i class="fas fa-user-shield"></i>
                                    </div>
                                    <div class="product-details">
                                        <h4><?php echo htmlspecialchars($user['username']); ?></h4>
                                    </div>
                                </div>
                            </td>
                            <td><span class="category-badge" style="background: <?php echo $user['role'] == 'administrator' ? 'var(--primary)' : '#10b981'; ?>; color: white;"><?php echo ucfirst($user['role']); ?></span></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><span class="status-badge <?php echo $user['status'] == 'active' ? 'status-instock' : 'status-out'; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                            <td><?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                            <td class="actions-cell">
                                <button class="action-btn edit" title="Edit"><i class="fas fa-edit"></i></button>
                                <button class="action-btn delete" title="Disable"><i class="fas fa-ban"></i></button>
                            </td>
                        </tr>
                    <?php 
                        endwhile;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Backup Settings -->
    <div id="backup-settings" class="settings-section">
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px;">Backup Settings</h3>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 30px; margin-bottom: 30px;">
                <div>
                    <h4 style="margin-bottom: 15px;">Automatic Backup</h4>
                    <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                        <input type="checkbox" checked> Enable automatic backups
                    </label>
                    
                    <div class="form-group">
                        <label>Backup Frequency</label>
                        <select style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                            <option>Every 6 hours</option>
                            <option selected>Daily</option>
                            <option>Weekly</option>
                            <option>Monthly</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Keep backups for</label>
                        <select style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                            <option>7 days</option>
                            <option selected>30 days</option>
                            <option>90 days</option>
                            <option>1 year</option>
                        </select>
                    </div>
                </div>
                
                <div>
                    <h4 style="margin-bottom: 15px;">Latest Backups</h4>
                    <div style="background: #f9fafb; padding: 15px; border-radius: 10px;">
                        <p style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Feb 24, 2024 3:00 AM</span>
                            <span style="color: var(--success);">Success (150 MB)</span>
                        </p>
                        <p style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Feb 23, 2024 3:00 AM</span>
                            <span style="color: var(--success);">Success (148 MB)</span>
                        </p>
                        <p style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Feb 22, 2024 3:00 AM</span>
                            <span style="color: var(--success);">Success (152 MB)</span>
                        </p>
                        <p style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Feb 21, 2024 3:00 AM</span>
                            <span style="color: var(--success);">Success (149 MB)</span>
                        </p>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 15px;">
                <button class="btn btn-primary" onclick="backupNow()">
                    <i class="fas fa-database"></i>
                    Backup Now
                </button>
                <button class="btn btn-secondary" onclick="restoreBackup()">
                    <i class="fas fa-undo"></i>
                    Restore from Backup
                </button>
                <button class="btn btn-secondary" onclick="downloadBackup()">
                    <i class="fas fa-download"></i>
                    Download Latest Backup
                </button>
            </div>
        </div>
    </div>

    <!-- Integrations Settings -->
    <div id="integrations-settings" class="settings-section">
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px;">Integrations</h3>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <!-- PayPal -->
                <div style="border: 2px solid #f3f4f6; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px;">
                    <i class="fab fa-paypal" style="font-size: 48px; color: #003087;"></i>
                    <div style="flex: 1;">
                        <h4>PayPal</h4>
                        <p style="color: var(--gray); font-size: 13px; margin-bottom: 10px;">Payment processing</p>
                        <button class="btn btn-secondary" style="width: 100%;">Connect</button>
                    </div>
                </div>
                
                <!-- Stripe -->
                <div style="border: 2px solid #f3f4f6; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px;">
                    <i class="fab fa-stripe" style="font-size: 48px; color: #6772E5;"></i>
                    <div style="flex: 1;">
                        <h4>Stripe</h4>
                        <p style="color: var(--gray); font-size: 13px; margin-bottom: 10px;">Payment processing</p>
                        <button class="btn btn-secondary" style="width: 100%;">Connect</button>
                    </div>
                </div>
                
                <!-- ShipStation -->
                <div style="border: 2px solid #f3f4f6; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px;">
                    <i class="fas fa-truck" style="font-size: 48px; color: #f97316;"></i>
                    <div style="flex: 1;">
                        <h4>ShipStation</h4>
                        <p style="color: var(--gray); font-size: 13px; margin-bottom: 10px;">Shipping integration</p>
                        <button class="btn btn-secondary" style="width: 100%;">Connect</button>
                    </div>
                </div>
                
                <!-- Google Analytics -->
                <div style="border: 2px solid #f3f4f6; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px;">
                    <i class="fab fa-google" style="font-size: 48px; color: #4285F4;"></i>
                    <div style="flex: 1;">
                        <h4>Google Analytics</h4>
                        <p style="color: var(--gray); font-size: 13px; margin-bottom: 10px;">Analytics integration</p>
                        <button class="btn btn-secondary" style="width: 100%;">Connect</button>
                    </div>
                </div>
                
                <!-- Mailchimp -->
                <div style="border: 2px solid #f3f4f6; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px;">
                    <i class="fab fa-mailchimp" style="font-size: 48px; color: #FFE01B;"></i>
                    <div style="flex: 1;">
                        <h4>Mailchimp</h4>
                        <p style="color: var(--gray); font-size: 13px; margin-bottom: 10px;">Email marketing</p>
                        <button class="btn btn-secondary" style="width: 100%;">Connect</button>
                    </div>
                </div>
                
                <!-- Slack -->
                <div style="border: 2px solid #f3f4f6; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px;">
                    <i class="fab fa-slack" style="font-size: 48px; color: #4A154B;"></i>
                    <div style="flex: 1;">
                        <h4>Slack</h4>
                        <p style="color: var(--gray); font-size: 13px; margin-bottom: 10px;">Team notifications</p>
                        <button class="btn btn-secondary" style="width: 100%;">Connect</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Company Settings -->
    <div id="company-settings" class="settings-section">
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px;">Company Information</h3>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 30px;">
                <div>
                    <div class="form-group">
                        <label><i class="fas fa-building"></i> Company Name</label>
                        <input type="text" value="StockFlow Inc." style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Company Email</label>
                        <input type="email" value="info@stockflow.com" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Company Phone</label>
                        <input type="text" value="+1 (555) 123-4567" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                    </div>
                </div>
                
                <div>
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Address</label>
                        <textarea rows="3" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">123 Business Ave, Suite 100
New York, NY 10001
United States</textarea>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-globe"></i> Website</label>
                        <input type="url" value="https://www.stockflow.com" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-file-invoice"></i> Tax ID / VAT Number</label>
                <input type="text" value="12-3456789" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px;">
            </div>
            
            <div class="form-actions" style="margin-top: 30px;">
                <button class="btn btn-primary" onclick="saveSettings('company')">
                    <i class="fas fa-save"></i>
                    Save Company Information
                </button>
            </div>
        </div>
    </div>
</div>

<script>
let currentTab = 'general';

function switchTab(tab) {
    // Update tab buttons
    document.querySelectorAll('.settings-tab').forEach(btn => {
        btn.classList.remove('active');
    });
    document.getElementById(`tab-${tab}`).classList.add('active');
    
    // Hide all sections
    document.querySelectorAll('.settings-section').forEach(section => {
        section.classList.remove('active-section');
    });
    
    // Show selected section
    document.getElementById(`${tab}-settings`).classList.add('active-section');
    currentTab = tab;
}

function saveAllSettings() {
    showToast('All settings saved successfully!');
}

function saveSettings(section) {
    showToast(`${section} settings saved successfully!`);
}

function addNewUser() {
    showToast('Add user feature coming soon!');
}

function backupNow() {
    showToast('Starting backup...', 'info');
    setTimeout(() => showToast('Backup completed successfully!'), 2000);
}

function restoreBackup() {
    if (confirm('Are you sure you want to restore from backup? This will overwrite current data.')) {
        showToast('Restore initiated...', 'info');
    }
}

function downloadBackup() {
    showToast('Downloading latest backup...', 'info');
}

function handleSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    // Implement search logic if needed
}
</script>

<?php include 'includes/footer.php'; ?>