<?php
ob_start();
require_once 'config.php';
requireLogin();

require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Settings</h1>
        <p>Configure your preferences</p>
    </div>
</div>

<div style="display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;">
    <button class="settings-tab active" onclick="switchSettingsTab('general')">General</button>
    <button class="settings-tab" onclick="switchSettingsTab('notifications')">Notifications</button>
    <button class="settings-tab" onclick="switchSettingsTab('security')">Security</button>
</div>

<div id="general-settings" class="settings-section active-section">
    <div class="table-wrapper">
        <h3 style="margin-bottom: 25px; color: var(--text-primary);">General Settings</h3>
        <div class="form-group">
            <label style="color: var(--text-primary);">Store Name</label>
            <input type="text" value="JLC BEST CONSTRUCTION" class="settings-input">
        </div>
        <div class="form-group">
            <label style="color: var(--text-primary);">Currency</label>
            <select class="settings-select">
                <option value="PHP" selected>PHP (₱)</option>
                <option value="USD">USD ($)</option>
            </select>
        </div>
    </div>
</div>

<div id="notifications-settings" class="settings-section">
    <div class="table-wrapper">
        <h3 style="margin-bottom: 25px; color: var(--text-primary);">Notifications</h3>
        <label class="checkbox-label" style="color: var(--text-primary);">
            <input type="checkbox" checked> Email notifications
        </label>
        <label class="checkbox-label" style="color: var(--text-primary);">
            <input type="checkbox" checked> Low stock alerts
        </label>
    </div>
</div>

<div id="security-settings" class="settings-section">
    <div class="table-wrapper">
        <h3 style="margin-bottom: 25px; color: var(--text-primary);">Security</h3>
        <div class="form-group">
            <label style="color: var(--text-primary);">Minimum password length</label>
            <input type="number" value="8" class="settings-input" style="width: 100px;">
        </div>
    </div>
</div>

<?php require_once 'include/footer.php'; ?>