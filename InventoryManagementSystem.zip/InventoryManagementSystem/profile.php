<?php
require_once 'config.php';
require_once 'user.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$user = new User($conn);
$current_user = $user->getUserById($_SESSION['user_id']);

// Check if user exists
if (!$current_user) {
    session_destroy();
    header("Location: login.php?error=user_not_found");
    exit();
}

$message = '';
$message_type = '';

// Handle profile updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_username'])) {
        $new_username = $conn->real_escape_string($_POST['new_username']);
        $result = $user->updateUsername($_SESSION['user_id'], $new_username);
        
        $message = $result['message'];
        $message_type = $result['success'] ? 'success' : 'error';
        
        if ($result['success']) {
            $current_user['username'] = $new_username;
        }
    }
    
    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if ($new_password !== $confirm_password) {
            $message = 'New password and confirm password do not match';
            $message_type = 'error';
        } else {
            $result = $user->updatePassword($_SESSION['user_id'], $current_password, $new_password);
            $message = $result['message'];
            $message_type = $result['success'] ? 'success' : 'error';
        }
    }
}

// Include header from include folder
include 'include/header.php';
?>

<!-- Toast Notification Container -->
<div id="toastContainer" class="toast-container"></div>

<?php if ($message): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo htmlspecialchars($message); ?>', '<?php echo $message_type; ?>');
    });
</script>
<?php endif; ?>

<div class="profile-wrapper">
    <div class="profile-container">
        <!-- Profile Header with Stats -->
        <div class="profile-header-modern">
            <div class="profile-cover">
                <div class="profile-avatar-large">
                    <i class="fas fa-user-circle"></i>
                </div>
                <div class="profile-title">
                    <h1>Profile Settings</h1>
                    <p>Manage your account information and security</p>
                </div>
            </div>
            <div class="profile-stats">
                <div class="stat-item">
                    <span class="stat-value"><?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '1'; ?></span>
                    <span class="stat-label">User ID</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo isset($current_user['username']) ? htmlspecialchars($current_user['username']) : 'Admin'; ?></span>
                    <span class="stat-label">Username</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">Active</span>
                    <span class="stat-label">Status</span>
                </div>
            </div>
        </div>

        <div class="profile-grid">
            <!-- Update Username Card -->
            <div class="profile-card-modern">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-user-edit"></i>
                    </div>
                    <h3>Change Username</h3>
                    <p>Update your display name</p>
                </div>
                <div class="card-body">
                    <form method="POST" action="" class="modern-form" id="usernameForm">
                        <div class="form-group-modern">
                            <label for="new_username">
                                <i class="fas fa-user"></i>
                                <span>New Username</span>
                            </label>
                            <input type="text" 
                                   id="new_username" 
                                   name="new_username" 
                                   value="<?php echo isset($current_user['username']) ? htmlspecialchars($current_user['username']) : ''; ?>"
                                   placeholder="Enter new username"
                                   required>
                            <div class="input-focus-bg"></div>
                        </div>
                        <button type="submit" name="update_username" class="btn-modern btn-primary">
                            <i class="fas fa-save"></i>
                            <span>Update Username</span>
                        </button>
                    </form>
                </div>
            </div>

            <!-- Change Password Card -->
            <div class="profile-card-modern">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-lock"></i>
                    </div>
                    <h3>Change Password</h3>
                    <p>Update your password (min. 8 characters)</p>
                </div>
                <div class="card-body">
                    <form method="POST" action="" class="modern-form" id="passwordForm">
                        <div class="form-group-modern">
                            <label for="current_password">
                                <i class="fas fa-lock"></i>
                                <span>Current Password</span>
                            </label>
                            <div class="password-wrapper">
                                <input type="password" 
                                       id="current_password" 
                                       name="current_password" 
                                       placeholder="Enter current password"
                                       required>
                                <button type="button" class="password-toggle" onclick="togglePassword('current_password')">
                                    <i class="fas fa-eye" id="toggle_current_password"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-group-modern">
                            <label for="new_password">
                                <i class="fas fa-key"></i>
                                <span>New Password</span>
                            </label>
                            <div class="password-wrapper">
                                <input type="password" 
                                       id="new_password" 
                                       name="new_password" 
                                       placeholder="Enter new password"
                                       pattern=".{8,}" 
                                       title="Password must be at least 8 characters"
                                       required>
                                <button type="button" class="password-toggle" onclick="togglePassword('new_password')">
                                    <i class="fas fa-eye" id="toggle_new_password"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-group-modern">
                            <label for="confirm_password">
                                <i class="fas fa-check-circle"></i>
                                <span>Confirm Password</span>
                            </label>
                            <div class="password-wrapper">
                                <input type="password" 
                                       id="confirm_password" 
                                       name="confirm_password" 
                                       placeholder="Confirm new password"
                                       required>
                                <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye" id="toggle_confirm_password"></i>
                                </button>
                            </div>
                        </div>

                        <button type="submit" name="update_password" class="btn-modern btn-primary">
                            <i class="fas fa-save"></i>
                            <span>Update Password</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
:root {
    --primary-color: #75e6da;
    --primary-dark: #5bc8be;
    --primary-light: #a1f0e8;
    --secondary-color: #6c5ce7;
    --success-color: #2ecc71;
    --danger-color: #e74c3c;
    
    /* Light theme variables (default) */
    --bg-gradient-start: #f5f7fa;
    --bg-gradient-end: #e9ecef;
    --card-bg: #ffffff;
    --text-primary: #2c3e50;
    --text-secondary: #7f8c8d;
    --border-color: #e0e0e0;
    --input-bg: #ffffff;
    --input-border: #e0e0e0;
    --input-text: #2c3e50;
    --shadow-color: rgba(0, 0, 0, 0.1);
    --stat-divider: rgba(0, 0, 0, 0.1);
    --card-header-bg: linear-gradient(135deg, #75e6da20, #6c5ce720);
    --toast-bg: rgba(255, 255, 255, 0.95);
}

/* Dark theme variables */
body:not(.light-theme) {
    --bg-gradient-start: #1a1a1a;
    --bg-gradient-end: #2c2c2c;
    --card-bg: #2c2c2c;
    --text-primary: #ffffff;
    --text-secondary: #b0b0b0;
    --border-color: #404040;
    --input-bg: #3c3c3c;
    --input-border: #404040;
    --input-text: #ffffff;
    --shadow-color: rgba(0, 0, 0, 0.3);
    --stat-divider: rgba(255, 255, 255, 0.1);
    --card-header-bg: rgba(117, 230, 218, 0.1);
    --toast-bg: rgba(44, 44, 44, 0.95);
}

/* Toast Notification Container */
.toast-container {
    position: fixed;
    bottom: 30px;
    right: 30px;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 10px;
    pointer-events: none;
}

/* Toast Notification */
.toast-notification {
    min-width: 300px;
    max-width: 400px;
    padding: 16px 20px;
    border-radius: 12px;
    background: var(--toast-bg);
    box-shadow: 0 10px 30px var(--shadow-color);
    display: flex;
    align-items: center;
    gap: 12px;
    transform: translateX(100%);
    opacity: 0;
    animation: slideInRight 0.3s ease forwards;
    pointer-events: auto;
    border-left: 4px solid transparent;
    backdrop-filter: blur(10px);
}

.toast-notification.success {
    border-left-color: var(--success-color);
}

.toast-notification.success i:first-child {
    color: var(--success-color);
}

.toast-notification.error {
    border-left-color: var(--danger-color);
}

.toast-notification.error i:first-child {
    color: var(--danger-color);
}

.toast-notification i:first-child {
    font-size: 24px;
}

.toast-content {
    flex: 1;
    font-size: 14px;
    font-weight: 500;
    color: var(--text-primary);
}

.toast-close {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    font-size: 18px;
    padding: 0;
    transition: all 0.3s ease;
    opacity: 0.5;
}

.toast-close:hover {
    opacity: 1;
    color: var(--primary-color);
    transform: scale(1.1);
}

.toast-progress {
    position: absolute;
    bottom: 0;
    left: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    border-radius: 0 0 0 12px;
    animation: progress 5s linear forwards;
}

@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOutRight {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

@keyframes progress {
    from {
        width: 100%;
    }
    to {
        width: 0%;
    }
}

/* Main Wrapper */
.profile-wrapper {
    padding: 30px;
    min-height: calc(100vh - 200px);
    background: linear-gradient(135deg, var(--bg-gradient-start), var(--bg-gradient-end));
    transition: background 0.3s ease;
}

/* Modern Profile Container */
.profile-container {
    max-width: 1200px;
    margin: 0 auto;
}

/* Modern Header */
.profile-header-modern {
    background: var(--card-bg);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 25px var(--shadow-color);
    margin-bottom: 30px;
    transition: all 0.3s ease;
}

.profile-cover {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    padding: 40px 30px;
    position: relative;
    display: flex;
    align-items: center;
    gap: 30px;
}

.profile-avatar-large {
    width: 100px;
    height: 100px;
    background: var(--card-bg);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 10px 25px var(--shadow-color);
    border: 4px solid rgba(255,255,255,0.3);
    transition: background 0.3s ease;
}

.profile-avatar-large i {
    font-size: 60px;
    color: var(--primary-color);
}

.profile-title h1 {
    color: white;
    font-size: 32px;
    font-weight: 700;
    margin: 0 0 5px 0;
}

.profile-title p {
    color: rgba(255,255,255,0.9);
    font-size: 16px;
    margin: 0;
}

.profile-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    background: var(--card-header-bg);
    padding: 20px 30px;
    transition: background 0.3s ease;
}

.stat-item {
    text-align: center;
    position: relative;
}

.stat-item:not(:last-child)::after {
    content: '';
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 1px;
    height: 30px;
    background: var(--stat-divider);
    transition: background 0.3s ease;
}

.stat-value {
    display: block;
    font-size: 24px;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 5px;
}

.stat-label {
    font-size: 14px;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: color 0.3s ease;
}

/* Profile Grid */
.profile-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
    gap: 30px;
}

/* Modern Cards */
.profile-card-modern {
    background: var(--card-bg);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 25px var(--shadow-color);
    transition: all 0.3s ease;
    border: 1px solid rgba(117, 230, 218, 0.1);
}

.profile-card-modern:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(117, 230, 218, 0.2);
}

.card-header {
    padding: 25px 30px;
    background: var(--card-header-bg);
    border-bottom: 2px solid var(--primary-color);
    position: relative;
    transition: background 0.3s ease;
}

.card-icon {
    width: 50px;
    height: 50px;
    background: var(--card-bg);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 15px;
    box-shadow: 0 2px 4px var(--shadow-color);
    transition: background 0.3s ease;
}

.card-icon i {
    font-size: 24px;
    color: var(--primary-color);
}

.card-header h3 {
    color: var(--text-primary);
    font-size: 20px;
    font-weight: 600;
    margin: 0 0 5px 0;
    transition: color 0.3s ease;
}

.card-header p {
    color: var(--text-secondary);
    font-size: 14px;
    margin: 0;
    transition: color 0.3s ease;
}

.card-body {
    padding: 30px;
}

/* Modern Form */
.modern-form {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.form-group-modern {
    position: relative;
}

.form-group-modern label {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
    color: var(--text-primary);
    font-size: 14px;
    font-weight: 500;
    transition: color 0.3s ease;
}

.form-group-modern label i {
    color: var(--primary-color);
    font-size: 16px;
}

.form-group-modern input {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid var(--input-border);
    border-radius: 12px;
    font-size: 15px;
    transition: all 0.3s ease;
    background: var(--input-bg);
    color: var(--input-text);
}

.form-group-modern input:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 4px rgba(117, 230, 218, 0.1);
}

.form-group-modern input:hover {
    border-color: var(--primary-light);
}

.form-group-modern input::placeholder {
    color: var(--text-secondary);
    opacity: 0.7;
}

/* Password Wrapper */
.password-wrapper {
    position: relative;
}

.password-wrapper input {
    padding-right: 45px;
}

.password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--primary-color);
    cursor: pointer;
    padding: 5px;
    font-size: 18px;
    transition: all 0.3s ease;
}

.password-toggle:hover {
    color: var(--primary-dark);
    transform: translateY(-50%) scale(1.1);
}

/* Modern Buttons */
.btn-modern {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 14px 24px;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-modern::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
}

.btn-modern:hover::before {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    box-shadow: 0 10px 25px rgba(117, 230, 218, 0.2);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 15px 30px rgba(117, 230, 218, 0.3);
}

/* Responsive */
@media (max-width: 768px) {
    .profile-wrapper {
        padding: 15px;
    }
    
    .profile-cover {
        flex-direction: column;
        text-align: center;
        padding: 30px 20px;
    }
    
    .profile-title {
        text-align: center;
    }
    
    .profile-title h1 {
        font-size: 24px;
    }
    
    .profile-stats {
        grid-template-columns: 1fr;
        gap: 15px;
    }
    
    .stat-item::after {
        display: none;
    }
    
    .profile-grid {
        grid-template-columns: 1fr;
    }
    
    .card-body {
        padding: 20px;
    }
    
    .toast-container {
        bottom: 20px;
        right: 20px;
        left: 20px;
    }
    
    .toast-notification {
        min-width: auto;
        max-width: none;
    }
}

/* Ensure smooth transitions */
.profile-wrapper,
.profile-header-modern,
.profile-card-modern,
.card-header,
.form-group-modern label,
.form-group-modern input,
.stat-label,
.stat-item::after {
    transition: all 0.3s ease;
}
</style>

<script>
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const toggleIcon = document.getElementById('toggle_' + inputId);
    
    if (input.type === 'password') {
        input.type = 'text';
        toggleIcon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        toggleIcon.className = 'fas fa-eye';
    }
}

// Toast notification function
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast-notification ${type}`;
    toast.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        <div class="toast-content">${message}</div>
        <button class="toast-close" onclick="this.closest('.toast-notification').remove()">&times;</button>
        <div class="toast-progress"></div>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }
    }, 5000);
    
    // Close button functionality
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 300);
    });
}

// Form validation - REMOVED e.preventDefault() to allow normal form submission
document.getElementById('passwordForm')?.addEventListener('submit', function(e) {
    const newPass = document.getElementById('new_password').value;
    const confirmPass = document.getElementById('confirm_password').value;
    
    if (newPass !== confirmPass) {
        e.preventDefault();
        showToast('Passwords do not match!', 'error');
        return false;
    }
    
    if (newPass.length < 8) {
        e.preventDefault();
        showToast('Password must be at least 8 characters!', 'error');
        return false;
    }
    
    // Allow form to submit normally
    return true;
});

// Username validation
document.getElementById('usernameForm')?.addEventListener('submit', function(e) {
    const username = document.getElementById('new_username').value;
    
    if (username.length < 3) {
        e.preventDefault();
        showToast('Username must be at least 3 characters!', 'error');
        return false;
    }
    
    // Allow form to submit normally
    return true;
});

// Add ripple effect to buttons
document.querySelectorAll('.btn-modern').forEach(button => {
    button.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        ripple.classList.add('ripple');
        this.appendChild(ripple);
        
        const x = e.clientX - e.target.offsetLeft;
        const y = e.clientY - e.target.offsetTop;
        
        ripple.style.left = `${x}px`;
        ripple.style.top = `${y}px`;
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
});

// Smooth animations on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.profile-card-modern').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'all 0.6s ease';
    observer.observe(card);
});

// Theme synchronization with header
document.addEventListener('DOMContentLoaded', function() {
    const isLightTheme = document.body.classList.contains('light-theme');
    console.log('Current theme:', isLightTheme ? 'Light' : 'Dark');
});

// Listen for theme changes from header
const observer2 = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        if (mutation.attributeName === 'class') {
            const isLightTheme = document.body.classList.contains('light-theme');
            console.log('Theme changed to:', isLightTheme ? 'Light' : 'Dark');
        }
    });
});

observer2.observe(document.body, { attributes: true });
</script>

<?php
// Include footer if you have one
// include 'include/footer.php';
?>

