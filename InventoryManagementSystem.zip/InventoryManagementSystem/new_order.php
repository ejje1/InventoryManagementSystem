<?php
ob_start();
require_once 'config.php';
requireLogin();

// First, let's check what columns exist in the products table
$product_columns_check = $conn->query("SHOW COLUMNS FROM products");
$product_columns = [];
while ($column = $product_columns_check->fetch_assoc()) {
    $product_columns[] = $column['Field'];
}

// Determine which stock column to use
$stock_column = 'stock'; // Default assumption
if (in_array('stock_quantity', $product_columns)) {
    $stock_column = 'stock_quantity';
} elseif (in_array('quantity', $product_columns)) {
    $stock_column = 'quantity';
} elseif (in_array('stock', $product_columns)) {
    $stock_column = 'stock';
} else {
    // If no stock column found, we'll handle it differently
    $stock_column = null;
}

// Check what columns exist in the orders table
$order_columns_check = $conn->query("SHOW COLUMNS FROM orders");
$order_columns = [];
while ($column = $order_columns_check->fetch_assoc()) {
    $order_columns[] = $column['Field'];
}

// Get all products for the order form
if ($stock_column) {
    $products = $conn->query("SELECT * FROM products WHERE $stock_column > 0 ORDER BY name ASC");
} else {
    $products = $conn->query("SELECT * FROM products ORDER BY name ASC");
}

// Generate unique order number
function generateOrderNumber() {
    return 'ORD-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_number = $_POST['order_number'];
    $customer_name = $_POST['customer_name'];
    $customer_email = $_POST['customer_email'];
    $customer_phone = $_POST['customer_phone'];
    $shipping_address = $_POST['shipping_address'] ?? '';
    $payment_method = 'cash';
    $order_date = date('Y-m-d H:i:s');
    $status = 'pending';
    
    // Get order items
    $product_ids = $_POST['product_id'];
    $quantities = $_POST['quantity'];
    $prices = $_POST['price'];
    
    // Calculate total amount
    $total_amount = 0;
    $items = [];
    for ($i = 0; $i < count($product_ids); $i++) {
        if (!empty($product_ids[$i]) && $quantities[$i] > 0) {
            $subtotal = $prices[$i] * $quantities[$i];
            $total_amount += $subtotal;
            $items[] = [
                'product_id' => $product_ids[$i],
                'quantity' => $quantities[$i],
                'price' => $prices[$i],
                'subtotal' => $subtotal
            ];
        }
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Build the INSERT query based on existing columns
        $insert_columns = ['order_number', 'customer_name', 'order_date', 'total_amount', 'status'];
        $insert_values = [$order_number, $customer_name, $order_date, $total_amount, $status];
        $placeholders = ['?', '?', '?', '?', '?'];
        
        // Add optional columns if they exist
        if (in_array('customer_email', $order_columns)) {
            $insert_columns[] = 'customer_email';
            $insert_values[] = $customer_email;
            $placeholders[] = '?';
        }
        
        if (in_array('customer_phone', $order_columns)) {
            $insert_columns[] = 'customer_phone';
            $insert_values[] = $customer_phone;
            $placeholders[] = '?';
        }
        
        if (in_array('shipping_address', $order_columns)) {
            $insert_columns[] = 'shipping_address';
            $insert_values[] = $shipping_address;
            $placeholders[] = '?';
        }
        
        if (in_array('payment_method', $order_columns)) {
            $insert_columns[] = 'payment_method';
            $insert_values[] = $payment_method;
            $placeholders[] = '?';
        }
        
        // Build and execute the query
        $order_query = "INSERT INTO orders (" . implode(', ', $insert_columns) . ") 
                       VALUES (" . implode(', ', $placeholders) . ")";
        
        $types = str_repeat('s', count($insert_values)); // All strings for now
        $stmt = $conn->prepare($order_query);
        $stmt->bind_param($types, ...$insert_values);
        $stmt->execute();
        $order_id = $conn->insert_id;
        $stmt->close();
        
        // Insert order items
        foreach ($items as $item) {
            $item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($item_query);
            $stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
            $stmt->execute();
            $stmt->close();
            
            // Update product stock if stock column exists
            if ($stock_column) {
                $stock_query = "UPDATE products SET $stock_column = $stock_column - ? WHERE id = ?";
                $stmt = $conn->prepare($stock_query);
                $stmt->bind_param("ii", $item['quantity'], $item['product_id']);
                $stmt->execute();
                $stmt->close();
            }
        }
        
        // Commit transaction
        $conn->commit();
        $_SESSION['success'] = "Order created successfully! Order #: " . $order_number;
        header("Location: orders.php");
        exit();
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        $_SESSION['error'] = "Error creating order: " . $e->getMessage();
        // Redirect back to the form with error
        header("Location: new_order.php");
        exit();
    }
}

require_once 'include/header.php';
?>

<style>
/* New Order Page Styles */
.new-order-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.form-section {
    background: var(--bg-primary);
    border: 1px solid var(--border-navy);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
}

.form-section h2 {
    color: var(--text-primary);
    font-size: 18px;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #75e6da;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-section h2 i {
    color: #75e6da;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-secondary);
    font-weight: 500;
    font-size: 14px;
}

.form-group label i {
    color: #75e6da;
    margin-right: 5px;
    width: 16px;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px 12px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-navy);
    border-radius: 8px;
    color: var(--text-primary);
    font-size: 14px;
    transition: all 0.3s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #75e6da;
    box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.1);
    outline: none;
}

.form-group input:hover,
.form-group select:hover,
.form-group textarea:hover {
    border-color: #75e6da;
}

/* Payment Method Section */
.payment-section {
    background: linear-gradient(135deg, rgba(117, 230, 218, 0.1), rgba(108, 92, 231, 0.1));
    border: 2px solid #75e6da;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 20px;
}

.payment-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #75e6da, #6c5ce7);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 30px;
}

.payment-info {
    flex: 1;
}

.payment-info h3 {
    color: var(--text-primary);
    font-size: 18px;
    margin-bottom: 5px;
}

.payment-info p {
    color: var(--text-secondary);
    font-size: 14px;
}

.payment-badge {
    background: #75e6da;
    color: #1a1c3c;
    padding: 8px 20px;
    border-radius: 30px;
    font-weight: 600;
    font-size: 16px;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

/* Product Selection Table */
.products-selection {
    margin-top: 20px;
    overflow-x: auto;
}

.products-selection table {
    width: 100%;
    border-collapse: collapse;
    min-width: 800px;
}

.products-selection th {
    background: var(--bg-secondary);
    padding: 12px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    border-bottom: 2px solid var(--border-navy);
}

.products-selection td {
    padding: 12px;
    border-bottom: 1px solid var(--border-navy);
    color: var(--text-primary);
}

.products-selection .product-select {
    width: 20px;
    height: 20px;
    cursor: pointer;
    accent-color: #75e6da;
}

.products-selection .quantity-input {
    width: 80px;
    padding: 6px;
    text-align: center;
    background: var(--bg-secondary);
    border: 1px solid var(--border-navy);
    border-radius: 5px;
    color: var(--text-primary);
}

.products-selection .quantity-input:focus {
    border-color: #75e6da;
    outline: none;
}

.products-selection .price-cell {
    color: #75e6da;
    font-weight: 600;
}

.products-selection .stock-cell {
    color: var(--text-secondary);
}

/* Category badge */
.category-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
    background: linear-gradient(135deg, #75e6da, #6c5ce7);
    color: white;
}

/* Status badges for stock */
.status-badge {
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
    display: inline-block;
}

.status-instock {
    background: rgba(117, 230, 218, 0.15);
    color: #75e6da;
}

.status-low {
    background: rgba(243, 156, 18, 0.15);
    color: #f39c12;
}

.status-out {
    background: rgba(214, 48, 49, 0.15);
    color: #d63031;
}

/* Selected Products Summary */
.selected-products {
    background: var(--bg-secondary);
    border-radius: 8px;
    padding: 15px;
    margin-top: 20px;
}

.selected-products h3 {
    color: var(--text-primary);
    font-size: 16px;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.selected-products h3 i {
    color: #75e6da;
}

.selected-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background: var(--bg-primary);
    border: 1px solid var(--border-navy);
    border-radius: 8px;
    margin-bottom: 10px;
}

.selected-item-info {
    flex: 1;
}

.selected-item-name {
    color: var(--text-primary);
    font-weight: 500;
    margin-bottom: 5px;
}

.selected-item-details {
    color: var(--text-secondary);
    font-size: 13px;
}

.selected-item-details span {
    color: #75e6da;
    font-weight: 600;
    margin: 0 5px;
}

.selected-item-remove {
    color: #d63031;
    cursor: pointer;
    padding: 5px 10px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.selected-item-remove:hover {
    background: rgba(214, 48, 49, 0.1);
}

/* Total Amount */
.total-amount-box {
    background: linear-gradient(135deg, #75e6da, #6c5ce7);
    padding: 20px;
    border-radius: 8px;
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.total-amount-box span {
    color: white;
    font-size: 16px;
    font-weight: 500;
}

.total-amount-box .amount {
    font-size: 24px;
    font-weight: 700;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 15px;
    justify-content: flex-end;
    margin-top: 30px;
}

.btn {
    padding: 12px 25px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-primary {
    background: linear-gradient(135deg, #75e6da, #6c5ce7);
    color: white;
    box-shadow: 0 4px 15px rgba(117, 230, 218, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(117, 230, 218, 0.4);
}

.btn-primary:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
}

.btn-secondary {
    background: var(--navy-light);
    border: 1px solid var(--border-navy);
    color: #75e6da;
}

.btn-secondary:hover {
    background: var(--navy-dark);
    transform: translateY(-2px);
    border-color: #75e6da;
}

/* Product row highlight */
.product-row.selected {
    background: rgba(117, 230, 218, 0.1);
}

.product-row.out-of-stock {
    opacity: 0.5;
    pointer-events: none;
}

/* Search and filter */
.search-box {
    margin-bottom: 20px;
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.search-input {
    flex: 1;
    min-width: 250px;
    padding: 10px 15px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-navy);
    border-radius: 8px;
    color: var(--text-primary);
}

.search-input:focus {
    border-color: #75e6da;
    outline: none;
}

.category-filter {
    width: 200px;
    padding: 10px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-navy);
    border-radius: 8px;
    color: var(--text-primary);
}

.category-filter:focus {
    border-color: #75e6da;
    outline: none;
}

/* Required field indicator */
.required::after {
    content: '*';
    color: #75e6da;
    margin-left: 4px;
}
</style>

<div class="new-order-container">
    <div class="welcome-section">
        <div class="welcome-text">
            <h1><i class="fas fa-plus-circle" style="color: #75e6da;"></i> Create New Order</h1>
            <p>Add customer details and select products</p>
        </div>
        <a href="orders.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i>
            Back to Orders
        </a>
    </div>

    <!-- Payment Method Notice - Cash Only -->
    <div class="payment-section">
        <div class="payment-icon">
            <i class="fas fa-money-bill-wave"></i>
        </div>
        <div class="payment-info">
            <h3>Payment Method: Cash Only</h3>
            <p>This store accepts cash payments only. All orders will be processed with cash as the payment method.</p>
        </div>
        <div class="payment-badge">
            <i class="fas fa-check-circle"></i> CASH ONLY
        </div>
    </div>

    <form method="POST" action="" id="orderForm">
        <!-- Customer Information Section -->
        <div class="form-section">
            <h2><i class="fas fa-user"></i> Customer Information</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label><i class="fas fa-hashtag"></i> Order Number</label>
                    <input type="text" name="order_number" value="<?php echo generateOrderNumber(); ?>" readonly class="bg-opacity-50">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Customer Name <span class="required"></span></label>
                    <input type="text" name="customer_name" required placeholder="Enter customer name">
                </div>
                
                <?php if (in_array('customer_email', $order_columns)): ?>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="customer_email" placeholder="customer@example.com">
                </div>
                <?php endif; ?>
                
                <?php if (in_array('customer_phone', $order_columns)): ?>
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> Phone Number</label>
                    <input type="tel" name="customer_phone" placeholder="Enter phone number">
                </div>
                <?php endif; ?>
                
                <?php if (in_array('shipping_address', $order_columns)): ?>
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label><i class="fas fa-map-marker-alt"></i> Shipping Address</label>
                    <textarea name="shipping_address" rows="3" placeholder="Enter complete shipping address"></textarea>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Product Selection Section -->
        <div class="form-section">
            <h2><i class="fas fa-box"></i> Select Products</h2>
            
            <!-- Search and Filter -->
            <div class="search-box">
                <input type="text" id="productSearch" class="search-input" placeholder="Search products..." onkeyup="filterProducts()">
                <select id="categoryFilter" class="category-filter" onchange="filterProducts()">
                    <option value="">All Categories</option>
                    <?php
                    // Get unique categories from products
                    $categories = $conn->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''");
                    while ($cat = $categories->fetch_assoc()) {
                        echo "<option value=\"" . htmlspecialchars($cat['category']) . "\">" . htmlspecialchars($cat['category']) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Products Table -->
            <div class="products-selection">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 50px">Select</th>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <?php if ($stock_column): ?>
                            <th>Stock</th>
                            <?php endif; ?>
                            <th style="width: 100px">Quantity</th>
                        </tr>
                    </thead>
                    <tbody id="productsTableBody">
                        <?php if ($products && $products->num_rows > 0): ?>
                            <?php while($product = $products->fetch_assoc()): 
                                $stock_value = $stock_column ? ($product[$stock_column] ?? 0) : 999;
                                $stock_class = 'status-instock';
                                if ($stock_column) {
                                    if ($stock_value <= 0) {
                                        $stock_class = 'status-out';
                                    } elseif ($stock_value <= 5) {
                                        $stock_class = 'status-low';
                                    }
                                }
                            ?>
                                <tr class="product-row <?php echo ($stock_column && $stock_value <= 0) ? 'out-of-stock' : ''; ?>" 
                                    data-product-id="<?php echo $product['id']; ?>"
                                    data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                    data-product-price="<?php echo $product['price']; ?>"
                                    data-product-stock="<?php echo $stock_value; ?>"
                                    data-category="<?php echo htmlspecialchars($product['category'] ?? ''); ?>">
                                    <td>
                                        <input type="checkbox" class="product-select" 
                                               onchange="toggleProductSelection(this, <?php echo $product['id']; ?>)"
                                               <?php echo ($stock_column && $stock_value <= 0) ? 'disabled' : ''; ?>>
                                    </td>
                                    <td>
                                        <strong style="color: var(--text-primary);"><?php echo htmlspecialchars($product['name']); ?></strong>
                                        <?php if (!empty($product['description'])): ?>
                                            <br><small style="color: var(--text-secondary);"><?php echo substr(htmlspecialchars($product['description']), 0, 50) . '...'; ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="category-badge"><?php echo htmlspecialchars($product['category'] ?? 'Uncategorized'); ?></span>
                                    </td>
                                    <td class="price-cell">₱<?php echo number_format($product['price'], 2); ?></td>
                                    <?php if ($stock_column): ?>
                                    <td>
                                        <span class="status-badge <?php echo $stock_class; ?>">
                                            <?php echo $stock_value; ?> units
                                        </span>
                                    </td>
                                    <?php endif; ?>
                                    <td>
                                        <input type="number" class="quantity-input" 
                                               min="1" max="<?php echo $stock_value; ?>" 
                                               value="1" disabled
                                               onchange="updateSelectedProduct(<?php echo $product['id']; ?>, this.value)">
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?php echo $stock_column ? '6' : '5'; ?>" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                                    <i class="fas fa-box-open" style="font-size: 48px; margin-bottom: 15px;"></i>
                                    <br>No products available.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Selected Products Summary -->
            <div class="selected-products" id="selectedProductsContainer" style="display: none;">
                <h3><i class="fas fa-shopping-cart"></i> Selected Products</h3>
                <div id="selectedProductsList"></div>
                
                <!-- Hidden inputs for form submission -->
                <div id="hiddenInputsContainer"></div>
                
                <!-- Total Amount -->
                <div class="total-amount-box">
                    <span>Total Amount:</span>
                    <span class="amount" id="totalAmount">₱0.00</span>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <button type="button" class="btn btn-secondary" onclick="window.location.href='orders.php'">
                <i class="fas fa-times"></i>
                Cancel
            </button>
            <button type="submit" class="btn btn-primary" id="submitBtn" disabled>
                <i class="fas fa-check"></i>
                Create Order (Cash)
            </button>
        </div>
    </form>
</div>

<script>
// Store selected products
let selectedProducts = [];

// Toggle product selection
function toggleProductSelection(checkbox, productId) {
    const row = checkbox.closest('tr');
    const quantityInput = row.querySelector('.quantity-input');
    const productName = row.dataset.productName;
    const productPrice = parseFloat(row.dataset.productPrice);
    const maxStock = parseInt(row.dataset.productStock);
    
    if (checkbox.checked) {
        // Validate stock
        if (maxStock <= 0) {
            alert('This product is out of stock!');
            checkbox.checked = false;
            return;
        }
        
        // Add to selected products
        const quantity = parseInt(quantityInput.value) || 1;
        selectedProducts.push({
            id: productId,
            name: productName,
            price: productPrice,
            quantity: Math.min(quantity, maxStock),
            maxStock: maxStock,
            row: row
        });
        quantityInput.disabled = false;
        row.classList.add('selected');
    } else {
        // Remove from selected products
        selectedProducts = selectedProducts.filter(p => p.id !== productId);
        quantityInput.disabled = true;
        quantityInput.value = 1;
        row.classList.remove('selected');
    }
    
    updateSelectedProductsDisplay();
}

// Update quantity for selected product
function updateSelectedProduct(productId, quantity) {
    const product = selectedProducts.find(p => p.id === productId);
    if (product) {
        quantity = parseInt(quantity) || 1;
        quantity = Math.min(Math.max(quantity, 1), product.maxStock);
        product.quantity = quantity;
        
        // Update input value
        const row = product.row;
        const quantityInput = row.querySelector('.quantity-input');
        quantityInput.value = quantity;
        
        updateSelectedProductsDisplay();
    }
}

// Update selected products display
function updateSelectedProductsDisplay() {
    const container = document.getElementById('selectedProductsContainer');
    const list = document.getElementById('selectedProductsList');
    const hiddenContainer = document.getElementById('hiddenInputsContainer');
    const totalAmountSpan = document.getElementById('totalAmount');
    const submitBtn = document.getElementById('submitBtn');
    
    if (selectedProducts.length === 0) {
        container.style.display = 'none';
        submitBtn.disabled = true;
        return;
    }
    
    container.style.display = 'block';
    submitBtn.disabled = false;
    
    // Generate HTML for selected products
    let html = '';
    let hiddenHtml = '';
    let total = 0;
    
    selectedProducts.forEach(product => {
        const subtotal = product.price * product.quantity;
        total += subtotal;
        
        html += `
            <div class="selected-item">
                <div class="selected-item-info">
                    <div class="selected-item-name">${product.name}</div>
                    <div class="selected-item-details">
                        ₱${product.price.toFixed(2)} × ${product.quantity} = <span>₱${subtotal.toFixed(2)}</span>
                    </div>
                </div>
                <div class="selected-item-remove" onclick="removeSelectedProduct(${product.id})">
                    <i class="fas fa-times"></i>
                </div>
            </div>
        `;
        
        // Hidden inputs for form submission
        hiddenHtml += `
            <input type="hidden" name="product_id[]" value="${product.id}">
            <input type="hidden" name="quantity[]" value="${product.quantity}">
            <input type="hidden" name="price[]" value="${product.price}">
        `;
    });
    
    list.innerHTML = html;
    hiddenContainer.innerHTML = hiddenHtml;
    totalAmountSpan.textContent = '₱' + total.toFixed(2);
}

// Remove selected product
function removeSelectedProduct(productId) {
    const product = selectedProducts.find(p => p.id === productId);
    if (product) {
        // Uncheck checkbox
        const checkbox = product.row.querySelector('.product-select');
        if (checkbox) {
            checkbox.checked = false;
            toggleProductSelection(checkbox, productId);
        }
    }
}

// Filter products by search and category
function filterProducts() {
    const searchTerm = document.getElementById('productSearch').value.toLowerCase();
    const category = document.getElementById('categoryFilter').value.toLowerCase();
    const rows = document.querySelectorAll('.product-row');
    
    rows.forEach(row => {
        const productName = row.dataset.productName.toLowerCase();
        const productCategory = (row.dataset.category || '').toLowerCase();
        
        const matchesSearch = productName.includes(searchTerm);
        const matchesCategory = category === '' || productCategory === category;
        
        if (matchesSearch && matchesCategory) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Form validation before submit
document.getElementById('orderForm').addEventListener('submit', function(e) {
    if (selectedProducts.length === 0) {
        e.preventDefault();
        alert('Please select at least one product.');
        return;
    }
    
    const customerName = document.querySelector('input[name="customer_name"]').value.trim();
    if (!customerName) {
        e.preventDefault();
        alert('Please enter customer name.');
        return;
    }
});

// Auto-hide alerts
setTimeout(function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        alert.style.opacity = '0';
        setTimeout(() => {
            alert.style.display = 'none';
        }, 300);
    });
}, 3000);

// Initialize filter on page load
document.addEventListener('DOMContentLoaded', function() {
    filterProducts();
});
</script>

<?php require_once 'include/footer.php'; ?>