<?php
// Start session and output buffering
session_start();
ob_start();

// Include database configuration
require_once 'config.php';

// Require login
requireLogin();

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: orders.php');
    exit();
}

// Get the action type
$action = $_POST['action'] ?? '';

// Process based on action
switch ($action) {
    case 'delete':
        // Delete order
        deleteOrder($conn);
        break;
        
    case 'edit':
        // Edit order
        editOrder($conn);
        break;
        
    case 'add':
        // Add new order
        addOrder($conn);
        break;
        
    default:
        // Invalid action
        $_SESSION['error'] = 'Invalid action specified.';
        header('Location: orders.php');
        exit();
}

/**
 * Delete an order
 */
function deleteOrder($conn) {
    // Get order ID
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    
    // Validate order ID
    if ($order_id <= 0) {
        $_SESSION['error'] = 'Invalid order ID. Please try again.';
        header('Location: orders.php');
        exit();
    }
    
    // Check if order exists
    $check_sql = "SELECT order_number FROM orders WHERE id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $order_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        $_SESSION['error'] = 'Order not found. It may have been already deleted.';
        header('Location: orders.php');
        exit();
    }
    
    $order = $check_result->fetch_assoc();
    $order_number = $order['order_number'];
    $check_stmt->close();
    
    // Prepare SQL statement for deletion
    $sql = "DELETE FROM orders WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    
    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Order "' . htmlspecialchars($order_number) . '" deleted successfully!';
    } else {
        $_SESSION['error'] = 'Error deleting order: ' . $conn->error;
    }
    
    $stmt->close();
    header('Location: orders.php');
    exit();
}

/**
 * Edit an existing order
 */
function editOrder($conn) {
    // Get and sanitize form data
    $order_id = intval($_POST['order_id'] ?? 0);
    $customer_name = sanitizeInput($conn, $_POST['customer_name'] ?? '');
    $status = sanitizeInput($conn, $_POST['status'] ?? '');
    $total_amount = floatval($_POST['total_amount'] ?? 0);
    $order_date = $_POST['order_date'] ?? date('Y-m-d');
    
    // Validate required fields
    $errors = [];
    
    if ($order_id <= 0) {
        $errors[] = 'Invalid order ID.';
    }
    
    if (empty($customer_name)) {
        $errors[] = 'Customer name is required.';
    }
    
    if (empty($status)) {
        $errors[] = 'Status is required.';
    }
    
    if ($total_amount < 0) {
        $errors[] = 'Total amount cannot be negative.';
    }
    
    // If there are errors, redirect back with error messages
    if (!empty($errors)) {
        $_SESSION['error'] = implode(' ', $errors);
        header('Location: orders.php');
        exit();
    }
    
    // Check if order exists
    $check_sql = "SELECT id, order_number FROM orders WHERE id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $order_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        $_SESSION['error'] = 'Order not found.';
        header('Location: orders.php');
        exit();
    }
    
    $order = $check_result->fetch_assoc();
    $order_number = $order['order_number'];
    $check_stmt->close();
    
    // Prepare SQL statement - removed created_at from update
    $sql = "UPDATE orders 
            SET customer_name = ?, status = ?, total_amount = ?, order_date = ?
            WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdsi", $customer_name, $status, $total_amount, $order_date, $order_id);
    
    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Order "' . htmlspecialchars($order_number) . '" updated successfully!';
    } else {
        $_SESSION['error'] = 'Error updating order: ' . $conn->error;
    }
    
    $stmt->close();
    header('Location: orders.php');
    exit();
}

/**
 * Add a new order
 */
function addOrder($conn) {
    // Generate order number automatically
    $date_prefix = date('Ymd');
    $random_num = rand(1000, 9999);
    $order_number = 'ORD-' . $date_prefix . '-' . $random_num;
    
    // Get and sanitize form data
    $customer_name = sanitizeInput($conn, $_POST['customer_name'] ?? '');
    $status = sanitizeInput($conn, $_POST['status'] ?? 'pending');
    $total_amount = floatval($_POST['total_amount'] ?? 0);
    $order_date = $_POST['order_date'] ?? date('Y-m-d');
    
    // Validate required fields
    $errors = [];
    
    if (empty($customer_name)) {
        $errors[] = 'Customer name is required.';
    }
    
    if ($total_amount < 0) {
        $errors[] = 'Total amount cannot be negative.';
    }
    
    // If there are errors, redirect back with error messages
    if (!empty($errors)) {
        $_SESSION['error'] = implode(' ', $errors);
        header('Location: orders.php');
        exit();
    }
    
    // Prepare SQL statement - removed created_at
    $sql = "INSERT INTO orders (order_number, customer_name, status, total_amount, order_date) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssds", $order_number, $customer_name, $status, $total_amount, $order_date);
    
    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Order created successfully! Order #: ' . $order_number;
    } else {
        $_SESSION['error'] = 'Error creating order: ' . $conn->error;
    }
    
    $stmt->close();
    header('Location: orders.php');
    exit();
}

/**
 * Helper function to sanitize input data
 */
function sanitizeInput($conn, $data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Close database connection
$conn->close();
?>