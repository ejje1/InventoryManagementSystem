<?php
require_once 'config.php';
include 'includes/header.php';

// Handle order actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'update_status') {
        $order_id = intval($_POST['order_id']);
        $status = $conn->real_escape_string($_POST['status']);
        $conn->query("UPDATE orders SET status='$status' WHERE id=$order_id");
        echo "<script>window.onload = function() { showToast('Order status updated!'); }</script>";
    }
}

// Get statistics
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;
$completed_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='completed'")->fetch_assoc()['count'] ?? 0;
$pending_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='pending'")->fetch_assoc()['count'] ?? 0;
$cancelled_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='cancelled'")->fetch_assoc()['count'] ?? 0;
$total_revenue = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status='completed'")->fetch_assoc()['total'] ?? 0;

// Get today's orders
$today_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE DATE(order_date) = CURDATE()")->fetch_assoc()['count'] ?? 0;
$today_revenue = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE DATE(order_date) = CURDATE() AND status='completed'")->fetch_assoc()['total'] ?? 0;

// Get orders
$orders = $conn->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 50");
?>

<!-- Orders Page Content -->
<div class="page-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-text">
            <h1>Orders Management</h1>
            <p>Track and manage all customer orders</p>
        </div>
        <button class="btn btn-primary" onclick="createNewOrder()">
            <i class="fas fa-plus"></i>
            New Order
        </button>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #6d5acf 0%, #a78bfa 100%)">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="stat-details">
                <h3>TOTAL ORDERS</h3>
                <p class="stat-value"><?php echo $total_orders; ?></p>
                <span class="stat-trend positive">
                    <i class="fas fa-arrow-up"></i> All time
                </span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%)">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3>COMPLETED</h3>
                <p class="stat-value"><?php echo $completed_orders; ?></p>
                <span class="stat-trend positive"><?php echo $total_orders ? round(($completed_orders/$total_orders)*100, 1) : 0; ?>% of total</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #f97316 0%, #fb923c 100%)">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-details">
                <h3>PENDING</h3>
                <p class="stat-value"><?php echo $pending_orders; ?></p>
                <span class="stat-trend negative"><?php echo $total_orders ? round(($pending_orders/$total_orders)*100, 1) : 0; ?>% of total</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #ef4444 0%, #f87171 100%)">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="stat-details">
                <h3>CANCELLED</h3>
                <p class="stat-value"><?php echo $cancelled_orders; ?></p>
                <span class="stat-trend negative"><?php echo $total_orders ? round(($cancelled_orders/$total_orders)*100, 1) : 0; ?>% of total</span>
            </div>
        </div>
    </div>

    <!-- Today's Summary -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="flex-direction: column; align-items: flex-start;">
            <h3 style="color: var(--gray); margin-bottom: 10px;">Today's Orders</h3>
            <p style="font-size: 32px; font-weight: 700; color: var(--dark);"><?php echo $today_orders; ?></p>
            <span class="stat-trend positive">Orders placed today</span>
        </div>
        <div class="stat-card" style="flex-direction: column; align-items: flex-start;">
            <h3 style="color: var(--gray); margin-bottom: 10px;">Revenue Today</h3>
            <p style="font-size: 32px; font-weight: 700; color: var(--primary);">$<?php echo number_format($today_revenue, 2); ?></p>
            <span class="stat-trend positive">From completed orders</span>
        </div>
        <div class="stat-card" style="flex-direction: column; align-items: flex-start;">
            <h3 style="color: var(--gray); margin-bottom: 10px;">Avg. Order Value</h3>
            <p style="font-size: 32px; font-weight: 700; color: var(--dark);">$<?php echo $total_orders ? number_format($total_revenue/$total_orders, 2) : '0.00'; ?></p>
            <span class="stat-trend positive">Overall average</span>
        </div>
    </div>

    <!-- Filters -->
    <div class="filters-section" style="margin-bottom: 20px;">
        <div class="filter-group">
            <label>Status:</label>
            <select id="statusFilter" class="filter-select" onchange="filterOrders()">
                <option value="">All Orders</option>
                <option value="pending">Pending</option>
                <option value="processing">Processing</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label>Date Range:</label>
            <select id="dateFilter" class="filter-select" onchange="filterOrders()">
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="year">This Year</option>
            </select>
        </div>
        
        <button class="btn btn-secondary" onclick="exportOrders()">
            <i class="fas fa-download"></i>
            Export Orders
        </button>
    </div>

    <!-- Orders Table -->
    <div class="table-wrapper">
        <table class="products-table">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="ordersTableBody">
                <?php if ($orders && $orders->num_rows > 0): ?>
                    <?php while($order = $orders->fetch_assoc()): 
                        // Get order items count
                        $items = $conn->query("SELECT COUNT(*) as count FROM order_items WHERE order_id=" . $order['id']);
                        $item_count = $items->fetch_assoc()['count'] ?? 0;
                    ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                            <td>
                                <div class="product-info">
                                    <div class="product-icon" style="width: 32px; height: 32px;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="product-details">
                                        <h4 style="font-size: 14px;"><?php echo htmlspecialchars($order['customer_name']); ?></h4>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                            <td><?php echo $item_count; ?> items</td>
                            <td class="price-cell">$<?php echo number_format($order['total_amount'], 2); ?></td>
                            <td>
                                <?php
                                $payment_icons = [
                                    'visa' => 'fab fa-cc-visa',
                                    'mastercard' => 'fab fa-cc-mastercard',
                                    'paypal' => 'fab fa-cc-paypal',
                                    'amex' => 'fab fa-cc-amex',
                                    'cash' => 'fas fa-money-bill-wave'
                                ];
                                $payment_method = strtolower($order['payment_method'] ?? 'cash');
                                $icon = isset($payment_icons[$payment_method]) ? $payment_icons[$payment_method] : 'fas fa-credit-card';
                                ?>
                                <i class="<?php echo $icon; ?>" style="color: var(--primary);"></i>
                                <span style="margin-left: 5px;"><?php echo ucfirst($payment_method); ?></span>
                            </td>
                            <td>
                                <select class="status-select" onchange="updateOrderStatus(<?php echo $order['id']; ?>, this.value)" style="padding: 5px; border-radius: 5px; border: 1px solid #e5e7eb;">
                                    <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </td>
                            <td class="actions-cell">
                                <button class="action-btn view" onclick='viewOrder(<?php echo json_encode($order); ?>)' title="View Order">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit" onclick='editOrder(<?php echo $order['id']; ?>)' title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn delete" onclick="cancelOrder(<?php echo $order['id']; ?>)" title="Cancel">
                                    <i class="fas fa-times"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            No orders found. Click "New Order" to create one.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function createNewOrder() {
    window.location.href = 'new_order.php';
}

function updateOrderStatus(orderId, status) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="action" value="update_status">
        <input type="hidden" name="order_id" value="${orderId}">
        <input type="hidden" name="status" value="${status}">
    `;
    document.body.appendChild(form);
    form.submit();
}

function viewOrder(order) {
    // Implement view order modal
    showToast('View order feature coming soon!');
}

function editOrder(orderId) {
    window.location.href = 'edit_order.php?id=' + orderId;
}

function cancelOrder(orderId) {
    if (confirm('Are you sure you want to cancel this order?')) {
        updateOrderStatus(orderId, 'cancelled');
    }
}

function filterOrders() {
    const status = document.getElementById('statusFilter').value;
    const dateRange = document.getElementById('dateFilter').value;
    showToast(`Filtering by: ${status} orders, ${dateRange} range`);
    // Implement actual filtering logic
}

function exportOrders() {
    showToast('Exporting orders...');
    // Implement export logic
}

function handleSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#ordersTableBody tr');
    
    rows.forEach(row => {
        if (row.cells.length > 1) {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>