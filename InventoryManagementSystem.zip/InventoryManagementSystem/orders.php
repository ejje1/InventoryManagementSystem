<?php
ob_start();
require_once 'config.php';
requireLogin();

// First, check what stock column exists in products table
$product_columns_check = $conn->query("SHOW COLUMNS FROM products");
$product_columns = [];
while ($column = $product_columns_check->fetch_assoc()) {
    $product_columns[] = $column['Field'];
}

// Determine which stock column to use
$stock_column = 'stock'; // Default assumption
if (in_array('stock_quantity', $product_columns)) {
    $stock_column = 'stock_quantity';
} elseif (in_array('quantity', $product_columns)) {
    $stock_column = 'quantity';
} elseif (in_array('stock', $product_columns)) {
    $stock_column = 'stock';
} else {
    $stock_column = null; // No stock column found
}

// Handle delete order
if (isset($_GET['delete'])) {
    $order_id = intval($_GET['delete']);
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // First get order items to restore stock if needed
        $items_query = "SELECT * FROM order_items WHERE order_id = ?";
        $stmt = $conn->prepare($items_query);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $items_result = $stmt->get_result();
        
        // Restore stock for each item if stock column exists
        if ($stock_column) {
            while ($item = $items_result->fetch_assoc()) {
                $update_stock = "UPDATE products SET $stock_column = $stock_column + ? WHERE id = ?";
                $stock_stmt = $conn->prepare($update_stock);
                $stock_stmt->bind_param("ii", $item['quantity'], $item['product_id']);
                $stock_stmt->execute();
                $stock_stmt->close();
            }
            // Reset the result pointer to use again
            $items_result->data_seek(0);
        }
        
        // Delete order items first (foreign key constraint)
        $delete_items = "DELETE FROM order_items WHERE order_id = ?";
        $stmt = $conn->prepare($delete_items);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();
        
        // Delete the order
        $delete_order = "DELETE FROM orders WHERE id = ?";
        $stmt = $conn->prepare($delete_order);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();
        
        // Commit transaction
        $conn->commit();
        $_SESSION['success'] = "Order deleted successfully!";
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        $_SESSION['error'] = "Error deleting order: " . $e->getMessage();
    }
    
    header("Location: orders.php");
    exit();
}

// Handle update order status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];
    
    // Check if payment_method column exists
    $payment_column_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'payment_method'");
    if ($payment_column_check->num_rows > 0) {
        $payment_method = $_POST['payment_method'] ?? 'cash';
        $update_query = "UPDATE orders SET status = ?, payment_method = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssi", $status, $payment_method, $order_id);
    } else {
        $update_query = "UPDATE orders SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("si", $status, $order_id);
    }
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Order updated successfully!";
    } else {
        $_SESSION['error'] = "Error updating order: " . $conn->error;
    }
    $stmt->close();
    
    header("Location: orders.php");
    exit();
}

// Get orders with customer and item details
$orders = $conn->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 50");

// Get order statistics
$totalOrders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;
$completedOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='completed'")->fetch_assoc()['count'] ?? 0;
$pendingOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='pending'")->fetch_assoc()['count'] ?? 0;
$cancelledOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='cancelled'")->fetch_assoc()['count'] ?? 0;

// Check if payment_method column exists before counting
$payment_column_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'payment_method'");
if ($payment_column_check->num_rows > 0) {
    $cashOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE payment_method='cash'")->fetch_assoc()['count'] ?? 0;
} else {
    $cashOrders = $totalOrders; // If no payment_method column, assume all are cash
}

$current_user = getCurrentUser();

require_once 'include/header.php';
?>

<style>
/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(5px);
    animation: fadeIn 0.3s ease;
}

.modal-content {
    position: relative;
    background: var(--bg-primary);
    margin: 50px auto;
    width: 90%;
    max-width: 600px;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    animation: slideInDown 0.3s ease;
    border: 1px solid var(--border-navy);
}

.modal-lg {
    max-width: 800px;
}

.modal-sm {
    max-width: 400px;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    background: linear-gradient(135deg, #75e6da, #5fd9d0, #4ab9b0);
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px 12px 0 0;
}

.modal-header h2 {
    margin: 0;
    color: white;
    font-size: 18px;
    font-weight: 600;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.close-modal {
    color: white;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
}

.close-modal:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: rotate(90deg);
}

.modal-body {
    padding: 20px;
    max-height: 70vh;
    overflow-y: auto;
}

.modal-footer {
    padding: 16px 20px;
    background: var(--bg-secondary);
    border-top: 1px solid var(--border-navy);
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    border-radius: 0 0 12px 12px;
}

/* Order Details Styles */
.order-detail-row {
    display: flex;
    padding: 12px;
    border-bottom: 1px solid var(--border-navy);
}

.order-detail-label {
    width: 120px;
    font-weight: 600;
    color: var(--text-secondary);
}

.order-detail-value {
    flex: 1;
    color: var(--text-primary);
}

.order-items-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.order-items-table th {
    background: var(--bg-secondary);
    padding: 10px;
    text-align: left;
    font-size: 12px;
    font-weight: 600;
    color: var(--text-secondary);
    border-bottom: 2px solid var(--border-navy);
}

.order-items-table td {
    padding: 10px;
    border-bottom: 1px solid var(--border-navy);
    color: var(--text-primary);
}

.total-amount {
    font-size: 18px;
    font-weight: 700;
    color: #75e6da;
    text-align: right;
    padding: 15px;
    background: var(--bg-secondary);
    border-radius: 8px;
    margin-top: 15px;
}

/* Form Styles */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-primary);
    font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px 12px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-navy);
    border-radius: 8px;
    color: var(--text-primary);
    font-size: 14px;
    transition: all 0.3s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #75e6da;
    box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.1);
    outline: none;
}

.form-group input:hover,
.form-group select:hover,
.form-group textarea:hover {
    border-color: #75e6da;
}

/* Enhanced button styles */
.modal-footer .btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    font-weight: 500;
    transition: all 0.3s ease;
    border-radius: 8px;
    border: none;
    cursor: pointer;
}

.modal-footer .btn i {
    font-size: 14px;
}

.modal-footer .btn-primary {
    background: linear-gradient(135deg, #75e6da, #6c5ce7);
    border: none;
    box-shadow: 0 4px 15px rgba(117, 230, 218, 0.4);
    color: white;
}

.modal-footer .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(117, 230, 218, 0.6);
}

.modal-footer .btn-secondary {
    background: var(--navy-light);
    border: 1px solid var(--border-navy);
    color: #75e6da;
}

.modal-footer .btn-secondary:hover {
    background: var(--navy-dark);
    transform: translateY(-2px);
    border-color: #75e6da;
    box-shadow: 0 4px 15px rgba(117, 230, 218, 0.3);
}

.modal-footer .btn-danger {
    background: linear-gradient(135deg, #e84393, #d63031);
    border: none;
    box-shadow: 0 4px 15px rgba(232, 67, 147, 0.4);
    color: white;
}

.modal-footer .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(232, 67, 147, 0.6);
}

/* Action buttons */
.action-btn {
    width: 35px;
    height: 35px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
    margin: 0 3px;
}

.action-btn:hover {
    transform: translateY(-2px);
}

.action-btn.view {
    background: linear-gradient(135deg, #00b894, #75e6da);
    color: white;
    box-shadow: 0 4px 10px rgba(0, 184, 148, 0.3);
}

.action-btn.edit {
    background: linear-gradient(135deg, #75e6da, #6c5ce7);
    color: white;
    box-shadow: 0 4px 10px rgba(117, 230, 218, 0.3);
}

.action-btn.delete {
    background: linear-gradient(135deg, #e84393, #d63031);
    color: white;
    box-shadow: 0 4px 10px rgba(232, 67, 147, 0.3);
}

/* Status badges */
.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
}

.status-completed {
    background: rgba(117, 230, 218, 0.15);
    color: #75e6da;
}

.status-pending {
    background: rgba(243, 156, 18, 0.15);
    color: #f39c12;
}

.status-cancelled {
    background: rgba(214, 48, 49, 0.15);
    color: #d63031;
}

/* Payment badge */
.payment-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
    background: rgba(117, 230, 218, 0.1);
    color: #75e6da;
    border: 1px solid rgba(117, 230, 218, 0.3);
    margin-left: 5px;
}

/* Price cell */
.price-cell {
    font-weight: 600;
    color: #75e6da;
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideInDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}
</style>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Orders Management</h1>
        <p>Track and manage orders</p>
    </div>
    <button class="btn btn-primary" onclick="window.location.href='new_order.php'">
        <i class="fas fa-plus"></i>
        New Order
    </button>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL ORDERS</h3>
            <p class="stat-value"><?php echo $totalOrders; ?></p>
            <span class="stat-trend positive">All time</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-details">
            <h3>COMPLETED</h3>
            <p class="stat-value"><?php echo $completedOrders; ?></p>
            <span class="stat-trend positive"><?php echo $totalOrders ? round(($completedOrders/$totalOrders)*100, 1) : 0; ?>%</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-details">
            <h3>PENDING</h3>
            <p class="stat-value"><?php echo $pendingOrders; ?></p>
            <span class="stat-trend negative"><?php echo $totalOrders ? round(($pendingOrders/$totalOrders)*100, 1) : 0; ?>%</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-times-circle"></i>
        </div>
        <div class="stat-details">
            <h3>CANCELLED</h3>
            <p class="stat-value"><?php echo $cancelledOrders; ?></p>
            <span class="stat-trend negative"><?php echo $totalOrders ? round(($cancelledOrders/$totalOrders)*100, 1) : 0; ?>%</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-money-bill-wave"></i>
        </div>
        <div class="stat-details">
            <h3>CASH PAYMENTS</h3>
            <p class="stat-value"><?php echo $cashOrders; ?></p>
            <span class="stat-trend positive">100% Cash Only</span>
        </div>
    </div>
</div>

<!-- Top Bar with Search -->
<div class="top-bar" style="justify-content: flex-start;">
    <div class="search-wrapper" style="width: 300px;">
        <i class="fas fa-search"></i>
        <input type="text" id="orderSearch" placeholder="Search orders..." onkeyup="searchOrders()">
    </div>
</div>

<!-- Scrollable Table Wrapper -->
<div class="table-wrapper" style="max-height: 400px; overflow-y: auto; overflow-x: auto;">
    <table class="products-table" id="ordersTable">
        <thead style="position: sticky; top: 0; background: var(--bg-secondary); z-index: 10;">
            <tr>
                <th>Order #</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="ordersPageBody">
            <?php if ($orders && $orders->num_rows > 0): ?>
                <?php while($order = $orders->fetch_assoc()): 
                    $status_class = $order['status'] == 'completed' ? 'status-completed' : ($order['status'] == 'pending' ? 'status-pending' : 'status-cancelled');
                ?>
                    <tr data-order-id="<?php echo $order['id']; ?>" class="order-row">
                        <td><strong style="color: var(--text-primary);"><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                        <td style="color: var(--text-primary);"><?php echo htmlspecialchars($order['customer_name']); ?></td>
                        <td style="color: var(--text-primary);"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                        <td class="price-cell">₱<?php echo number_format($order['total_amount'], 2); ?></td>
                        <td>
                            <span class="payment-badge">
                                <i class="fas fa-money-bill-wave"></i> 
                                <?php echo ucfirst($order['payment_method'] ?? 'cash'); ?>
                            </span>
                        </td>
                        <td><span class="status-badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                        <td class="actions-cell">
                            <button class="action-btn view" onclick="viewOrder(<?php echo $order['id']; ?>)" title="View"><i class="fas fa-eye"></i></button>
                            <button class="action-btn edit" onclick="editOrder(<?php echo $order['id']; ?>)" title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="action-btn delete" onclick="deleteOrder(<?php echo $order['id']; ?>, '<?php echo htmlspecialchars($order['order_number']); ?>')" title="Delete"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align: center; padding: 40px; color: var(--text-secondary);">No orders found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- No Results Message -->
<div id="noResultsMessage" style="display: none; text-align: center; padding: 40px; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 12px; margin-top: 20px;">
    <i class="fas fa-search" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 15px;"></i>
    <h3 style="color: var(--text-primary); margin-bottom: 10px;">No Orders Found</h3>
    <p style="color: var(--text-secondary);">No orders match your search criteria. Try different keywords.</p>
</div>

<!-- View Order Modal -->
<div id="viewOrderModal" class="modal">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h2><i class="fas fa-eye"></i> Order Details</h2>
            <span class="close-modal" onclick="closeModal('viewOrderModal')">&times;</span>
        </div>
        <div class="modal-body" id="viewOrderContent">
            <!-- Content will be loaded dynamically -->
        </div>
        <!-- Removed footer with close button since we have X button -->
    </div>
</div>

<!-- Edit Order Modal -->
<div id="editOrderModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-edit"></i> Edit Order</h2>
            <!-- Removed X button -->
        </div>
        <form method="POST" action="">
            <div class="modal-body">
                <input type="hidden" name="order_id" id="edit_order_id">
                <input type="hidden" name="update_order" value="1">
                
                <div class="form-group">
                    <label>Order Number</label>
                    <input type="text" id="edit_order_number" readonly disabled class="bg-opacity-50">
                </div>
                
                <div class="form-group">
                    <label>Customer Name</label>
                    <input type="text" id="edit_customer_name" readonly disabled class="bg-opacity-50">
                </div>
                
                <?php
                // Check if payment_method column exists
                $payment_column_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'payment_method'");
                if ($payment_column_check->num_rows > 0):
                ?>
               
                <?php endif; ?>
                
                <div class="form-group">
                    <label>Order Status</label>
                    <select name="status" id="edit_status" required>
                        <option value="pending">Pending</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('editOrderModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Order
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Order Modal -->
<div id="deleteOrderModal" class="modal">
    <div class="modal-content modal-sm">
        <div class="modal-header">
            <h2><i class="fas fa-trash"></i> Delete Order</h2>
            <!-- Removed X button -->
        </div>
        <div class="modal-body">
            <p style="color: var(--text-primary); margin-bottom: 20px;">Are you sure you want to delete this order?</p>
            <p style="color: var(--text-secondary); margin-bottom: 10px;">Order: <strong id="delete_order_number"></strong></p>
            <p style="color: #d63031; font-size: 14px;"><i class="fas fa-exclamation-triangle"></i> This action cannot be undone and will restore product stock.</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('deleteOrderModal')">
                <i class="fas fa-times"></i> Cancel
            </button>
            <a href="#" id="confirmDeleteBtn" class="btn btn-danger">
                <i class="fas fa-trash"></i> Delete Order
            </a>
        </div>
    </div>
</div>

<!-- Success/Error Message Display -->
<?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success" style="position: fixed; top: 20px; right: 20px; z-index: 9999; padding: 15px 20px; background: #75e6da; color: #1a1c3c; border-radius: 8px; box-shadow: 0 4px 6px rgba(117, 230, 218, 0.3);">
        <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
    </div>
<?php endif; ?>

<?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-danger" style="position: fixed; top: 20px; right: 20px; z-index: 9999; padding: 15px 20px; background: #d63031; color: white; border-radius: 8px; box-shadow: 0 4px 6px rgba(214, 48, 49, 0.3);">
        <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>

<script>
// Search function
function searchOrders() {
    const searchTerm = document.getElementById('orderSearch').value.toLowerCase().trim();
    const rows = document.querySelectorAll('#ordersPageBody .order-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const orderNumber = row.cells[0]?.textContent.toLowerCase() || '';
        const customer = row.cells[1]?.textContent.toLowerCase() || '';
        const date = row.cells[2]?.textContent.toLowerCase() || '';
        const total = row.cells[3]?.textContent.toLowerCase() || '';
        const payment = row.cells[4]?.textContent.toLowerCase() || '';
        const status = row.cells[5]?.textContent.toLowerCase() || '';
        
        const matches = orderNumber.includes(searchTerm) || 
                       customer.includes(searchTerm) || 
                       date.includes(searchTerm) || 
                       total.includes(searchTerm) || 
                       payment.includes(searchTerm) || 
                       status.includes(searchTerm);
        
        if (searchTerm === '') {
            row.style.display = '';
            visibleCount++;
        } else {
            if (matches) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        }
    });
    
    const noResultsMsg = document.getElementById('noResultsMessage');
    if (visibleCount === 0 && searchTerm !== '') {
        noResultsMsg.style.display = 'block';
    } else {
        noResultsMsg.style.display = 'none';
    }
}

// Debounced search
let searchTimeout;
function debouncedSearch() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(searchOrders, 100);
}

// Global modal functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// View Order
function viewOrder(orderId) {
    fetch('get_order_details.php?id=' + orderId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const order = data.order;
                const items = data.items;
                
                let itemsHtml = '';
                items.forEach(item => {
                    itemsHtml += `
                        <tr>
                            <td>${item.product_name}</td>
                            <td>₱${parseFloat(item.price).toFixed(2)}</td>
                            <td>${item.quantity}</td>
                            <td>₱${(item.price * item.quantity).toFixed(2)}</td>
                        </tr>
                    `;
                });
                
                const paymentIcon = 'fa-money-bill-wave';
                
                const content = `
                    <div class="order-detail-row">
                        <div class="order-detail-label">Order Number:</div>
                        <div class="order-detail-value">${order.order_number}</div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Customer:</div>
                        <div class="order-detail-value">${order.customer_name}</div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Email:</div>
                        <div class="order-detail-value">${order.customer_email || 'N/A'}</div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Phone:</div>
                        <div class="order-detail-value">${order.customer_phone || 'N/A'}</div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Address:</div>
                        <div class="order-detail-value">${order.shipping_address || 'N/A'}</div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Payment Method:</div>
                        <div class="order-detail-value">
                            <span class="payment-badge">
                                <i class="fas ${paymentIcon}"></i> 
                                CASH
                            </span>
                        </div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Order Date:</div>
                        <div class="order-detail-value">${new Date(order.order_date).toLocaleString()}</div>
                    </div>
                    <div class="order-detail-row">
                        <div class="order-detail-label">Status:</div>
                        <div class="order-detail-value"><span class="status-badge status-${order.status}">${order.status.charAt(0).toUpperCase() + order.status.slice(1)}</span></div>
                    </div>
                    
                    <h3 style="color: var(--text-primary); margin: 20px 0 10px;">Order Items</h3>
                    <table class="order-items-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${itemsHtml}
                        </tbody>
                    </table>
                    
                    <div class="total-amount">
                        Total Amount: ₱${parseFloat(order.total_amount).toFixed(2)}
                    </div>
                `;
                
                document.getElementById('viewOrderContent').innerHTML = content;
                openModal('viewOrderModal');
            } else {
                alert('Error loading order details');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error loading order details');
        });
}

// Edit Order
function editOrder(orderId) {
    fetch('get_order_details.php?id=' + orderId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const order = data.order;
                document.getElementById('edit_order_id').value = order.id;
                document.getElementById('edit_order_number').value = order.order_number;
                document.getElementById('edit_customer_name').value = order.customer_name;
                document.getElementById('edit_status').value = order.status;
                openModal('editOrderModal');
            } else {
                alert('Error loading order details');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error loading order details');
        });
}

// Delete Order
function deleteOrder(orderId, orderNumber) {
    document.getElementById('delete_order_number').textContent = orderNumber;
    document.getElementById('confirmDeleteBtn').href = 'orders.php?delete=' + orderId;
    openModal('deleteOrderModal');
}

// Auto-hide alerts after 3 seconds
setTimeout(function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        alert.style.opacity = '0';
        setTimeout(() => {
            alert.style.display = 'none';
        }, 300);
    });
}, 3000);

// Initialize all event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Search input listener
    const searchInput = document.getElementById('orderSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', debouncedSearch);
    }
    
    // Close button listeners for all modals
    const closeButtons = document.querySelectorAll('.close-modal');
    closeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const modal = this.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    });
    
    // Cancel button listeners for Edit modal
    const cancelEditBtn = document.querySelector('#editOrderModal .btn-secondary');
    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const modal = document.getElementById('editOrderModal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    }
    
    // Cancel button listeners for Delete modal
    const cancelDeleteBtn = document.querySelector('#deleteOrderModal .btn-secondary');
    if (cancelDeleteBtn) {
        cancelDeleteBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const modal = document.getElementById('deleteOrderModal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    }
    
    // Also add click listeners to any element with onclick attribute as backup
    document.querySelectorAll('[onclick*="closeModal"]').forEach(element => {
        const originalOnClick = element.onclick;
        element.onclick = function(e) {
            e.preventDefault();
            const modalId = this.getAttribute('onclick').match(/'([^']+)'/)[1];
            if (modalId) {
                const modal = document.getElementById(modalId);
                if (modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            }
            if (originalOnClick) {
                originalOnClick.call(this, e);
            }
        };
    });
});

// Also add a direct function for cancel buttons as a backup
window.cancelEdit = function() {
    const modal = document.getElementById('editOrderModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};

window.cancelDelete = function() {
    const modal = document.getElementById('deleteOrderModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};
</script>

<?php require_once 'include/footer.php'; ?>