<?php
ob_start();
require_once 'config.php';
requireLogin();

// Get orders
$orders = $conn->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 50");

// Get order statistics
$totalOrders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;
$completedOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='completed'")->fetch_assoc()['count'] ?? 0;
$pendingOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='pending'")->fetch_assoc()['count'] ?? 0;
$cancelledOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='cancelled'")->fetch_assoc()['count'] ?? 0;

require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Orders Management</h1>
        <p>Track and manage orders</p>
    </div>
    <button class="btn btn-primary" onclick="openNewOrderModal()">
        <i class="fas fa-plus"></i>
        New Order
    </button>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL ORDERS</h3>
            <p class="stat-value"><?php echo $totalOrders; ?></p>
            <span class="stat-trend positive">All time</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-details">
            <h3>COMPLETED</h3>
            <p class="stat-value"><?php echo $completedOrders; ?></p>
            <span class="stat-trend positive"><?php echo $totalOrders ? round(($completedOrders/$totalOrders)*100, 1) : 0; ?>%</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-details">
            <h3>PENDING</h3>
            <p class="stat-value"><?php echo $pendingOrders; ?></p>
            <span class="stat-trend negative"><?php echo $totalOrders ? round(($pendingOrders/$totalOrders)*100, 1) : 0; ?>%</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-times-circle"></i>
        </div>
        <div class="stat-details">
            <h3>CANCELLED</h3>
            <p class="stat-value"><?php echo $cancelledOrders; ?></p>
            <span class="stat-trend negative"><?php echo $totalOrders ? round(($cancelledOrders/$totalOrders)*100, 1) : 0; ?>%</span>
        </div>
    </div>
</div>

<div class="table-wrapper">
    <table class="products-table" id="ordersTable">
        <thead>
            <tr>
                <th>Order #</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Total</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($orders && $orders->num_rows > 0): ?>
                <?php while($order = $orders->fetch_assoc()): 
                    $status_class = $order['status'] == 'completed' ? 'status-instock' : ($order['status'] == 'pending' ? 'status-out' : 'status-low');
                ?>
                    <tr data-order-id="<?php echo $order['id']; ?>">
                        <td><strong style="color: var(--text-primary);"><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                        <td style="color: var(--text-primary);"><?php echo htmlspecialchars($order['customer_name']); ?></td>
                        <td style="color: var(--text-primary);"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                        <td class="price-cell">₱<?php echo number_format($order['total_amount'], 2); ?></td>
                        <td><span class="status-badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                        <td class="actions-cell">
                            <button class="action-btn view" onclick='openViewOrderModal(<?php echo json_encode($order); ?>)' title="View"><i class="fas fa-eye"></i></button>
                            <button class="action-btn edit" onclick='openEditOrderModal(<?php echo json_encode($order); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align: center; padding: 40px;">No orders found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'include/footer.php'; ?>