<?php
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header("Location: index.php");
    exit();
}

$error = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    
    // For demo purposes - in production, use password_verify()
    // This is a simple check - in production you'd hash passwords
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = 'admin';
        $_SESSION['role'] = 'administrator';
        header("Location: index.php");
        exit();
    } else {
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JLC BEST CONSTRUCTION OPC - Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            overflow: hidden;
        }

        .gradient-sphere {
            position: absolute;
            width: 800px;
            height: 800px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(109, 90, 207, 0.3) 0%, rgba(167, 139, 250, 0.2) 50%, transparent 70%);
            top: -400px;
            right: -200px;
            animation: float 20s ease-in-out infinite;
        }

        .gradient-sphere-2 {
            position: absolute;
            width: 600px;
            height: 600px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(249, 115, 22, 0.2) 0%, rgba(251, 146, 60, 0.15) 50%, transparent 70%);
            bottom: -300px;
            left: -200px;
            animation: float 15s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(50px, 50px) scale(1.1); }
        }

        .login-container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 450px;
            margin: 20px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 50px 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .company-name {
            text-align: center;
            margin-bottom: 10px;
        }

        .company-name h1 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #6d5acf, #a78bfa);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: -0.5px;
        }

        .company-subtitle {
            text-align: center;
            margin-bottom: 30px;
        }

        .company-subtitle h2 {
            font-size: 22px;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .company-subtitle p {
            font-size: 14px;
            color: #6d5acf;
            font-weight: 500;
            letter-spacing: 1px;
        }

        .divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, #6d5acf, transparent);
            margin: 20px 0;
        }

        .login-badge {
            background: linear-gradient(135deg, #f3f4f6, #e5e7eb);
            padding: 15px;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 30px;
        }

        .login-badge p {
            color: #4b5563;
            font-size: 14px;
        }

        .login-badge strong {
            color: #6d5acf;
            font-size: 16px;
            display: block;
            margin-top: 5px;
            text-transform: uppercase;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e5e7eb;
            border-radius: 15px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: white;
        }

        .form-group input:focus {
            border-color: #6d5acf;
            outline: none;
            box-shadow: 0 0 0 3px rgba(109, 90, 207, 0.1);
        }

        .form-group input::placeholder {
            color: #9ca3af;
        }

        .login-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #6d5acf, #a78bfa);
            border: none;
            border-radius: 15px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(109, 90, 207, 0.3);
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(109, 90, 207, 0.4);
        }

        .forgot-password {
            text-align: center;
        }

        .forgot-password a {
            color: #6d5acf;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .forgot-password a:hover {
            color: #4f3f9f;
            text-decoration: underline;
        }

        .error-message {
            background: #fee2e2;
            border: 1px solid #ef4444;
            color: #dc2626;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }

        .footer-info {
            text-align: center;
            margin-top: 20px;
            color: rgba(255, 255, 255, 0.8);
            font-size: 13px;
        }

        .footer-info i {
            margin-right: 5px;
        }

        /* Dark mode support */
        body.dark-theme .login-card {
            background: rgba(31, 41, 55, 0.95);
        }

        body.dark-theme .company-subtitle h2 {
            color: #f9fafb;
        }

        body.dark-theme .login-badge {
            background: #374151;
        }

        body.dark-theme .login-badge p {
            color: #d1d5db;
        }

        body.dark-theme .form-group label {
            color: #f3f4f6;
        }

        body.dark-theme .form-group input {
            background: #374151;
            border-color: #4b5563;
            color: #f9fafb;
        }

        body.dark-theme .form-group input::placeholder {
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <div class="animated-bg">
        <div class="gradient-sphere"></div>
        <div class="gradient-sphere-2"></div>
    </div>

    <div class="login-container">
        <div class="login-card">
            <div class="company-name">
                <h1>JLC BEST CONSTRUCTION OPC</h1>
            </div>

            <div class="company-subtitle">
                <h2>COMPANY PAYROLL SYSTEM</h2>
                <p>Building Engineering Solutions Technology</p>
                <p style="margin-top: 5px; color: #f97316;">BEST CONSTRUCTION OPC</p>
            </div>

            <div class="divider"></div>

            <div class="login-badge">
                <p>Logging in as ADMINISTRATOR</p>
                <strong>You are logging in as ADMINISTRATOR</strong>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" placeholder="Enter your username" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="login-btn">
                    <i class="fas fa-sign-in-alt" style="margin-right: 10px;"></i>
                    Login as Administrator
                </button>

                <div class="forgot-password">
                    <a href="#">Forgot Password?</a>
                </div>
            </form>
        </div>

        <div class="footer-info">
            <i class="fas fa-search"></i> Type here to search
        </div>
    </div>

    <script>
        // Theme toggle (optional)
        function toggleTheme() {
            document.body.classList.toggle('dark-theme');
        }
    </script>
</body>
</html>