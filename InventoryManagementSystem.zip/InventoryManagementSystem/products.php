<?php
require_once 'config.php';
include 'includes/header.php';

// Handle product actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Add product
        if ($_POST['action'] == 'add') {
            $name = $conn->real_escape_string($_POST['name']);
            $description = $conn->real_escape_string($_POST['description']);
            $price = floatval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            $category = $conn->real_escape_string($_POST['category']);
            $sku = 'PRD-' . strtoupper(substr(md5(time()), 0, 8));
            
            $sql = "INSERT INTO products (name, description, price, quantity, category, sku) 
                    VALUES ('$name', '$description', $price, $quantity, '$category', '$sku')";
            
            if ($conn->query($sql)) {
                echo "<script>window.onload = function() { showToast('Product added successfully!'); }</script>";
            }
        }
        
        // Edit product
        if ($_POST['action'] == 'edit') {
            $id = intval($_POST['id']);
            $name = $conn->real_escape_string($_POST['name']);
            $description = $conn->real_escape_string($_POST['description']);
            $price = floatval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            $category = $conn->real_escape_string($_POST['category']);
            
            $sql = "UPDATE products SET 
                    name='$name', description='$description', price=$price, 
                    quantity=$quantity, category='$category' WHERE id=$id";
            
            if ($conn->query($sql)) {
                echo "<script>window.onload = function() { showToast('Product updated successfully!'); }</script>";
            }
        }
        
        // Delete product
        if ($_POST['action'] == 'delete') {
            $id = intval($_POST['id']);
            $sql = "DELETE FROM products WHERE id=$id";
            if ($conn->query($sql)) {
                echo "<script>window.onload = function() { showToast('Product deleted successfully!'); }</script>";
            }
        }
    }
}

// Get statistics
$total_products = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
$total_categories = $conn->query("SELECT COUNT(DISTINCT category) as count FROM products WHERE category IS NOT NULL")->fetch_assoc()['count'];
$avg_price = $conn->query("SELECT AVG(price) as avg FROM products")->fetch_assoc()['avg'];
$out_of_stock = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity = 0")->fetch_assoc()['count'];
$total_value = $conn->query("SELECT SUM(price * quantity) as total FROM products")->fetch_assoc()['total'];

// Get category distribution
$categories = $conn->query("SELECT category, COUNT(*) as count FROM products WHERE category IS NOT NULL GROUP BY category");

// Get all products
$products = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
?>

<!-- Products Page Content -->
<div class="page-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-text">
            <h1>Products Management</h1>
            <p>Manage your product inventory, categories, and pricing</p>
        </div>
        <button class="btn btn-primary" onclick="openAddModal()">
            <i class="fas fa-plus"></i>
            Add New Product
        </button>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #6d5acf 0%, #a78bfa 100%)">
                <i class="fas fa-cubes"></i>
            </div>
            <div class="stat-details">
                <h3>TOTAL PRODUCTS</h3>
                <p class="stat-value"><?php echo $total_products; ?></p>
                <span class="stat-trend positive">Active items</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%)">
                <i class="fas fa-tags"></i>
            </div>
            <div class="stat-details">
                <h3>CATEGORIES</h3>
                <p class="stat-value"><?php echo $total_categories; ?></p>
                <span class="stat-trend positive">Product categories</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #f97316 0%, #fb923c 100%)">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="stat-details">
                <h3>AVG PRICE</h3>
                <p class="stat-value">$<?php echo number_format($avg_price ?? 0, 2); ?></p>
                <span class="stat-trend positive">Per item</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #ef4444 0%, #f87171 100%)">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <div class="stat-details">
                <h3>OUT OF STOCK</h3>
                <p class="stat-value"><?php echo $out_of_stock; ?></p>
                <span class="stat-trend negative">Need restock</span>
            </div>
        </div>
    </div>

    <!-- Category Distribution -->
    <div class="filters-section" style="justify-content: space-between; flex-wrap: wrap;">
        <h3 style="font-size: 16px; font-weight: 600; color: var(--dark);">Category Distribution</h3>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <?php if ($categories && $categories->num_rows > 0): ?>
                <?php while($cat = $categories->fetch_assoc()): ?>
                    <?php $percentage = round(($cat['count'] / $total_products) * 100); ?>
                    <span class="category-badge" style="background: var(--primary); color: white; padding: 8px 15px;">
                        <?php echo htmlspecialchars($cat['category']); ?>: <?php echo $cat['count']; ?> (<?php echo $percentage; ?>%)
                    </span>
                <?php endwhile; ?>
            <?php else: ?>
                <span class="category-badge">No categories found</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div style="display: flex; gap: 15px; margin-bottom: 20px;">
        <button class="btn btn-primary" onclick="openAddModal()">
            <i class="fas fa-plus"></i>
            Add New Product
        </button>
        <button class="btn btn-secondary" onclick="exportProducts()">
            <i class="fas fa-file-export"></i>
            Export Products
        </button>
        <button class="btn btn-secondary" onclick="printCatalog()">
            <i class="fas fa-print"></i>
            Print Catalog
        </button>
    </div>

    <!-- Filters -->
    <div class="filters-section" style="margin-bottom: 20px;">
        <div class="filter-group">
            <label>Category:</label>
            <select id="categoryFilter" class="filter-select" onchange="filterByCategory()">
                <option value="">All Categories</option>
                <?php
                $cat_filter = $conn->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL ORDER BY category");
                while($cat = $cat_filter->fetch_assoc()):
                ?>
                    <option value="<?php echo htmlspecialchars($cat['category']); ?>">
                        <?php echo htmlspecialchars($cat['category']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        
        <div class="filter-group">
            <label>Sort by:</label>
            <select id="sortFilter" class="filter-select" onchange="sortProducts()">
                <option value="newest">Newest First</option>
                <option value="name">Name A-Z</option>
                <option value="price_low">Price: Low to High</option>
                <option value="price_high">Price: High to Low</option>
                <option value="stock_low">Stock: Low to High</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label>Stock Status:</label>
            <select id="stockFilter" class="filter-select" onchange="filterByStock()">
                <option value="">All</option>
                <option value="in">In Stock</option>
                <option value="low">Low Stock</option>
                <option value="out">Out of Stock</option>
            </select>
        </div>
    </div>

    <!-- Products Table -->
    <div class="table-wrapper">
        <table class="products-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>SKU</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Last Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="productsTableBody">
                <?php if ($products && $products->num_rows > 0): ?>
                    <?php while($row = $products->fetch_assoc()): ?>
                        <?php
                        $status = $row['quantity'] > 20 ? 'In Stock' : ($row['quantity'] > 0 ? 'Low Stock' : 'Out of Stock');
                        $statusClass = $row['quantity'] > 20 ? 'status-instock' : ($row['quantity'] > 0 ? 'status-low' : 'status-out');
                        $updated = date('M d, Y', strtotime($row['updated_at']));
                        ?>
                        <tr data-product-id="<?php echo $row['id']; ?>">
                            <td class="product-cell">
                                <div class="product-info">
                                    <div class="product-icon">
                                        <i class="fas fa-box"></i>
                                    </div>
                                    <div class="product-details">
                                        <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                        <p><?php echo htmlspecialchars(substr($row['description'] ?? '', 0, 50)) . '...'; ?></p>
                                    </div>
                                </div>
                            </td>
                            <td><span class="sku-badge"><?php echo htmlspecialchars($row['sku'] ?? 'N/A'); ?></span></td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($row['category'] ?? 'Uncategorized'); ?></span></td>
                            <td class="price-cell">$<?php echo number_format($row['price'], 2); ?></td>
                            <td class="stock-cell"><?php echo $row['quantity']; ?> units</td>
                            <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                            <td><?php echo $updated; ?></td>
                            <td class="actions-cell">
                                <button class="action-btn view" onclick='viewProduct(<?php echo json_encode($row); ?>)' title="View">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit" onclick='editProduct(<?php echo json_encode($row); ?>)' title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn delete" onclick="deleteProduct(<?php echo $row['id']; ?>)" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            No products found. Click "Add New Product" to get started.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="pagination">
        <button class="page-btn"><i class="fas fa-chevron-left"></i></button>
        <button class="page-btn active">1</button>
        <button class="page-btn">2</button>
        <button class="page-btn">3</button>
        <button class="page-btn">4</button>
        <span>...</span>
        <button class="page-btn">10</button>
        <button class="page-btn"><i class="fas fa-chevron-right"></i></button>
    </div>
</div>

<!-- Add/Edit Product Modal -->
<div id="productModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Add New Product</h2>
            <button class="close-btn" onclick="closeModal()"><i class="fas fa-times"></i></button>
        </div>
        
        <form id="productForm" method="POST">
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="id" id="productId">
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Product Name</label>
                    <input type="text" name="name" id="productName" placeholder="Enter product name" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-layer-group"></i> Category</label>
                    <select name="category" id="productCategory" required>
                        <option value="">Select Category</option>
                        <option value="Electronics">Electronics</option>
                        <option value="Accessories">Accessories</option>
                        <option value="Furniture">Furniture</option>
                        <option value="Office Supplies">Office Supplies</option>
                        <option value="Clothing">Clothing</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-align-left"></i> Description</label>
                <textarea name="description" id="productDescription" rows="3" placeholder="Enter product description"></textarea>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-dollar-sign"></i> Price ($)</label>
                    <input type="number" name="price" id="productPrice" step="0.01" min="0" placeholder="0.00" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-cubes"></i> Quantity</label>
                    <input type="number" name="quantity" id="productQuantity" min="0" placeholder="0" required>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Save Product
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeModal()">
                    <i class="fas fa-times"></i>
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<!-- View Product Modal -->
<div id="viewModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Product Details</h2>
            <button class="close-btn" onclick="closeViewModal()"><i class="fas fa-times"></i></button>
        </div>
        <div id="productDetails" class="product-details-view"></div>
    </div>
</div>

<script>
// Product functions
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Add New Product';
    document.getElementById('formAction').value = 'add';
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('productModal').style.display = 'block';
}

function editProduct(product) {
    document.getElementById('modalTitle').textContent = 'Edit Product';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('productId').value = product.id;
    document.getElementById('productName').value = product.name;
    document.getElementById('productDescription').value = product.description || '';
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productQuantity').value = product.quantity;
    document.getElementById('productCategory').value = product.category || '';
    document.getElementById('productModal').style.display = 'block';
}

function viewProduct(product) {
    const status = product.quantity > 20 ? 'In Stock' : (product.quantity > 0 ? 'Low Stock' : 'Out of Stock');
    const statusClass = product.quantity > 20 ? 'status-instock' : (product.quantity > 0 ? 'status-low' : 'status-out');
    const createdDate = product.created_at ? new Date(product.created_at).toLocaleDateString() : 'N/A';
    
    const detailsHtml = `
        <div style="padding: 30px;">
            <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 30px;">
                <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #f3f4f6, #e5e7eb); border-radius: 20px; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-box" style="font-size: 40px; color: var(--primary);"></i>
                </div>
                <div>
                    <h2 style="font-size: 28px; font-weight: 600; color: var(--dark); margin-bottom: 8px;">${product.name}</h2>
                    <span class="category-badge" style="background: #f3f4f6; padding: 6px 12px; border-radius: 20px; font-size: 14px;">${product.category || 'Uncategorized'}</span>
                </div>
            </div>
            
            <div style="background: #f9fafb; border-radius: 16px; padding: 20px; margin-bottom: 20px;">
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                    <div>
                        <p style="color: var(--gray); font-size: 14px; margin-bottom: 5px;">Price</p>
                        <p style="font-size: 24px; font-weight: 600; color: var(--primary);">$${parseFloat(product.price).toFixed(2)}</p>
                    </div>
                    <div>
                        <p style="color: var(--gray); font-size: 14px; margin-bottom: 5px;">Quantity</p>
                        <p style="font-size: 24px; font-weight: 600; color: var(--dark);">${product.quantity} units</p>
                    </div>
                    <div>
                        <p style="color: var(--gray); font-size: 14px; margin-bottom: 5px;">SKU</p>
                        <p style="font-size: 16px; color: var(--dark);">${product.sku || 'N/A'}</p>
                    </div>
                    <div>
                        <p style="color: var(--gray); font-size: 14px; margin-bottom: 5px;">Status</p>
                        <span class="status-badge ${statusClass}" style="display: inline-block; padding: 8px 16px;">${status}</span>
                    </div>
                </div>
            </div>
            
            <div style="margin-bottom: 30px;">
                <h3 style="font-size: 18px; font-weight: 600; color: var(--dark); margin-bottom: 12px;">Description</h3>
                <p style="color: var(--gray); line-height: 1.6; background: #f9fafb; padding: 16px; border-radius: 12px;">${product.description || 'No description available for this product.'}</p>
            </div>
            
            <div style="display: flex; gap: 12px;">
                <button class="btn btn-primary" onclick="editProduct(${JSON.stringify(product)}); closeViewModal();" style="flex: 1;">
                    <i class="fas fa-edit"></i> Edit Product
                </button>
                <button class="btn btn-secondary" onclick="closeViewModal()" style="flex: 1;">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
    `;
    
    document.getElementById('productDetails').innerHTML = detailsHtml;
    document.getElementById('viewModal').style.display = 'block';
}

function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${id}">`;
        document.body.appendChild(form);
        form.submit();
    }
}

function closeModal() {
    document.getElementById('productModal').style.display = 'none';
}

function closeViewModal() {
    document.getElementById('viewModal').style.display = 'none';
}

// Filter and sort functions
function filterByCategory() {
    const category = document.getElementById('categoryFilter').value;
    const rows = document.querySelectorAll('#productsTableBody tr');
    
    rows.forEach(row => {
        if (row.cells.length > 1) {
            const rowCategory = row.querySelector('.category-badge')?.textContent || '';
            row.style.display = (category === '' || rowCategory === category) ? '' : 'none';
        }
    });
}

function filterByStock() {
    const stockFilter = document.getElementById('stockFilter').value;
    const rows = document.querySelectorAll('#productsTableBody tr');
    
    rows.forEach(row => {
        if (row.cells.length > 1) {
            const status = row.querySelector('.status-badge')?.textContent.toLowerCase() || '';
            let show = true;
            
            if (stockFilter === 'in' && !status.includes('in stock')) show = false;
            if (stockFilter === 'low' && !status.includes('low')) show = false;
            if (stockFilter === 'out' && !status.includes('out')) show = false;
            
            row.style.display = show ? '' : 'none';
        }
    });
}

function sortProducts() {
    const sortBy = document.getElementById('sortFilter').value;
    const tbody = document.getElementById('productsTableBody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    if (rows.length === 0 || rows[0].cells.length <= 1) return;
    
    rows.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                const nameA = a.querySelector('.product-details h4')?.textContent || '';
                const nameB = b.querySelector('.product-details h4')?.textContent || '';
                return nameA.localeCompare(nameB);
            case 'price_low':
                const priceA = parseFloat(a.querySelector('.price-cell')?.textContent.replace('$', '') || 0);
                const priceB = parseFloat(b.querySelector('.price-cell')?.textContent.replace('$', '') || 0);
                return priceA - priceB;
            case 'price_high':
                const priceHighA = parseFloat(a.querySelector('.price-cell')?.textContent.replace('$', '') || 0);
                const priceHighB = parseFloat(b.querySelector('.price-cell')?.textContent.replace('$', '') || 0);
                return priceHighB - priceHighA;
            case 'stock_low':
                const stockA = parseInt(a.querySelector('.stock-cell')?.textContent || '0');
                const stockB = parseInt(b.querySelector('.stock-cell')?.textContent || '0');
                return stockA - stockB;
            default:
                return 0;
        }
    });
    
    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));
}

function exportProducts() {
    const rows = document.querySelectorAll('#productsTableBody tr');
    let csv = ['Product,SKU,Category,Price,Stock,Status'];
    
    rows.forEach(row => {
        if (row.cells.length > 1 && row.style.display !== 'none') {
            const productName = row.querySelector('.product-details h4')?.textContent || '';
            const sku = row.querySelector('.sku-badge')?.textContent || '';
            const category = row.querySelector('.category-badge')?.textContent || '';
            const price = row.querySelector('.price-cell')?.textContent || '';
            const stock = row.querySelector('.stock-cell')?.textContent.replace(' units', '') || '';
            const status = row.querySelector('.status-badge')?.textContent || '';
            
            csv.push(`"${productName}","${sku}","${category}","${price}","${stock}","${status}"`);
        }
    });
    
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'products_export.csv';
    a.click();
    showToast('Products exported successfully!');
}

function printCatalog() {
    window.print();
}

function handleSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#productsTableBody tr');
    
    rows.forEach(row => {
        if (row.cells.length > 1) {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        }
    });
}

// Toast function
function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    toastMessage.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('productModal');
    const viewModal = document.getElementById('viewModal');
    if (event.target == modal) closeModal();
    if (event.target == viewModal) closeViewModal();
}
</script>

<?php include 'includes/footer.php'; ?>