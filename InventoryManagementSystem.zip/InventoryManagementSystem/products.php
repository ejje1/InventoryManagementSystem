<?php
// Start output buffering
ob_start();

require_once 'config.php';

// Require login
requireLogin();

// Get products data
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");

// Get statistics for products page
$totalProducts = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'] ?? 0;
$categoryCount = $conn->query("SELECT COUNT(DISTINCT category) as cat_count FROM products WHERE category IS NOT NULL AND category != ''")->fetch_assoc()['cat_count'] ?? 0;
$avgPrice = number_format($conn->query("SELECT AVG(price) as avg_price FROM products")->fetch_assoc()['avg_price'] ?? 0, 2);
$outOfStock = $conn->query("SELECT COUNT(*) as out_count FROM products WHERE quantity = 0")->fetch_assoc()['out_count'] ?? 0;

// Get categories for filter
$categories = $conn->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category");

// Get category distribution
$catDistribution = $conn->query("SELECT category, COUNT(*) as count FROM products WHERE category IS NOT NULL AND category != '' GROUP BY category");

$current_user = getCurrentUser();

// Include header
require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Products Management</h1>
        <p>Manage your product inventory</p>
    </div>
    <button class="btn btn-primary" onclick="openAddModal()">
        <i class="fas fa-plus"></i>
        Add New Product
    </button>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-cubes"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL PRODUCTS</h3>
            <p class="stat-value"><?php echo $totalProducts; ?></p>
            <span class="stat-trend positive">Active items</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-tags"></i>
        </div>
        <div class="stat-details">
            <h3>CATEGORIES</h3>
            <p class="stat-value"><?php echo $categoryCount; ?></p>
            <span class="stat-trend positive">Categories</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-details">
            <h3>AVG PRICE</h3>
            <p class="stat-value">₱<?php echo $avgPrice; ?></p>
            <span class="stat-trend positive">Per item</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-exclamation-circle"></i>
        </div>
        <div class="stat-details">
            <h3>OUT OF STOCK</h3>
            <p class="stat-value"><?php echo $outOfStock; ?></p>
            <span class="stat-trend negative">Need restock</span>
        </div>
    </div>
</div>

<div class="filters-section" style="justify-content: space-between; flex-wrap: wrap;">
    <h3 style="font-size: 16px; font-weight: 600; color: var(--text-primary);">Category Distribution</h3>
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <?php if ($catDistribution && $catDistribution->num_rows > 0): ?>
            <?php while($cat = $catDistribution->fetch_assoc()): ?>
                <span class="category-badge" style="background: var(--gradient-1); color: white; padding: 8px 15px; border: none;">
                    <?php echo htmlspecialchars($cat['category']); ?>: <?php echo $cat['count']; ?>
                </span>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</div>

<div class="table-wrapper">
    <table class="products-table" id="productsTable">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Category</th>
                <th>Product Description</th>
                <th>Price</th>
                <th>Quantity Stock/Units</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="productsPageBody">
            <?php if ($products && $products->num_rows > 0): ?>
                <?php while($row = $products->fetch_assoc()): 
                    $status = $row['quantity'] > 20 ? 'In Stock' : ($row['quantity'] > 0 ? 'Low Stock' : 'Out of Stock');
                    $statusClass = $row['quantity'] > 20 ? 'status-instock' : ($row['quantity'] > 0 ? 'status-low' : 'status-out');
                    $description = htmlspecialchars($row['description'] ?? '');
                ?>
                    <tr data-product-id="<?php echo $row['id']; ?>">
                        <td class="product-cell">
                            <div class="product-info">
                                <div class="product-icon"><i class="fas fa-box"></i></div>
                                <div class="product-details">
                                    <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                </div>
                            </div>
                        </td>
                        <td><span class="category-badge"><?php echo htmlspecialchars($row['category'] ?? 'Accessories'); ?></span></td>
                        <td><?php echo $description; ?></td>
                        <td class="price-cell">₱<?php echo number_format($row['price'], 2); ?></td>
                        <td class="stock-cell">
                            <select class="filter-select" style="width: auto;" onchange="updateStockQuantity(<?php echo $row['id']; ?>, this.value)">
                                <option value="<?php echo $row['quantity']; ?>" selected><?php echo $row['quantity']; ?> units</option>
                                <?php for($i = 1; $i <= 20; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?> units</option>
                                <?php endfor; ?>
                                <option value="25">25 units</option>
                                <option value="30">30 units</option>
                                <option value="40">40 units</option>
                                <option value="50">50 units</option>
                                <option value="75">75 units</option>
                                <option value="100">100 units</option>
                            </select>
                        </td>
                        <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                        <td class="actions-cell">
                            <button class="action-btn edit" onclick='openEditModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>, <?php echo json_encode($row['description'] ?? ''); ?>, <?php echo $row['price']; ?>, <?php echo $row['quantity']; ?>, <?php echo json_encode($row['category'] ?? ''); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="action-btn delete" onclick='openDeleteProductModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>)' title="Delete"><i class="fas fa-trash"></i></button>
                            <button class="action-btn view" onclick='openViewModal(<?php echo json_encode($row); ?>)' title="View"><i class="fas fa-eye"></i></button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
// Include footer
require_once 'include/footer.php';
?>