<?php
require_once 'config.php';
include 'includes/header.php';

// Get analytics data
$current_year = date('Y');
$last_year = $current_year - 1;

// Monthly revenue for current year
$monthly_revenue = [];
for ($i = 1; $i <= 12; $i++) {
    $month = sprintf("%02d", $i);
    $result = $conn->query("
        SELECT COALESCE(SUM(total_amount), 0) as total 
        FROM orders 
        WHERE status='completed' 
        AND DATE_FORMAT(order_date, '%Y-%m') = '$current_year-$month'
    ");
    $monthly_revenue[$i] = $result->fetch_assoc()['total'];
}

// Category performance
$category_performance = $conn->query("
    SELECT p.category, 
           COUNT(DISTINCT p.id) as product_count,
           COALESCE(SUM(oi.quantity), 0) as items_sold,
           COALESCE(SUM(oi.total), 0) as revenue
    FROM products p
    LEFT JOIN order_items oi ON p.id = oi.product_id
    LEFT JOIN orders o ON oi.order_id = o.id AND o.status='completed'
    WHERE p.category IS NOT NULL
    GROUP BY p.category
");

// Top products
$top_products = $conn->query("
    SELECT p.name, p.category, 
           COALESCE(SUM(oi.quantity), 0) as quantity_sold,
           COALESCE(SUM(oi.total), 0) as revenue
    FROM products p
    LEFT JOIN order_items oi ON p.id = oi.product_id
    LEFT JOIN orders o ON oi.order_id = o.id AND o.status='completed'
    GROUP BY p.id
    ORDER BY revenue DESC
    LIMIT 5
");

// Get overall stats
$total_revenue = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE status='completed'")->fetch_assoc()['total'];
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='completed'")->fetch_assoc()['count'];
$total_items_sold = $conn->query("SELECT COALESCE(SUM(quantity), 0) as total FROM order_items oi JOIN orders o ON oi.order_id=o.id WHERE o.status='completed'")->fetch_assoc()['total'];
$avg_order_value = $total_orders > 0 ? $total_revenue / $total_orders : 0;

// Get previous period for comparison
$prev_revenue = $conn->query("
    SELECT COALESCE(SUM(total_amount), 0) as total 
    FROM orders 
    WHERE status='completed' 
    AND order_date BETWEEN DATE_SUB(NOW(), INTERVAL 60 DAY) AND DATE_SUB(NOW(), INTERVAL 30 DAY)
")->fetch_assoc()['total'];

$revenue_growth = $prev_revenue > 0 ? (($total_revenue - $prev_revenue) / $prev_revenue) * 100 : 0;
?>

<!-- Analytics Page Content -->
<div class="page-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-text">
            <h1>Analytics Dashboard</h1>
            <p>View insights and reports about your business</p>
        </div>
        <div>
            <select class="filter-select" style="width: 180px;" onchange="changePeriod(this.value)">
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
                <option value="365">Last year</option>
                <option value="all">All time</option>
            </select>
        </div>
    </div>

    <!-- Key Metrics -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #6d5acf 0%, #a78bfa 100%)">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-details">
                <h3>TOTAL REVENUE</h3>
                <p class="stat-value">$<?php echo number_format($total_revenue, 2); ?></p>
                <span class="stat-trend <?php echo $revenue_growth >= 0 ? 'positive' : 'negative'; ?>">
                    <i class="fas fa-arrow-<?php echo $revenue_growth >= 0 ? 'up' : 'down'; ?>"></i>
                    <?php echo number_format(abs($revenue_growth), 1); ?>% vs last period
                </span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%)">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="stat-details">
                <h3>ITEMS SOLD</h3>
                <p class="stat-value"><?php echo number_format($total_items_sold); ?></p>
                <span class="stat-trend positive">All time</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #f97316 0%, #fb923c 100%)">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="stat-details">
                <h3>TOTAL ORDERS</h3>
                <p class="stat-value"><?php echo number_format($total_orders); ?></p>
                <span class="stat-trend positive">Completed orders</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="background: linear-gradient(135deg, #ef4444 0%, #f87171 100%)">
                <i class="fas fa-percent"></i>
            </div>
            <div class="stat-details">
                <h3>AVG ORDER VALUE</h3>
                <p class="stat-value">$<?php echo number_format($avg_order_value, 2); ?></p>
                <span class="stat-trend positive">Per order</span>
            </div>
        </div>
    </div>

    <!-- Revenue Chart -->
    <div class="table-wrapper" style="margin-bottom: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h3 style="color: var(--dark);">Revenue Overview - <?php echo $current_year; ?></h3>
            <div style="display: flex; gap: 20px;">
                <span style="display: flex; align-items: center; gap: 5px;">
                    <span style="width: 12px; height: 12px; background: var(--primary); border-radius: 3px;"></span> Revenue
                </span>
            </div>
        </div>
        
        <div style="height: 300px; display: flex; align-items: flex-end; gap: 15px; padding: 20px 0;">
            <?php 
            $max_revenue = max($monthly_revenue) ?: 1;
            $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            for ($i = 1; $i <= 12; $i++): 
                $height = ($monthly_revenue[$i] / $max_revenue) * 250;
            ?>
                <div style="flex: 1; display: flex; flex-direction: column; align-items: center;">
                    <div style="width: 100%; display: flex; gap: 2px; align-items: flex-end; justify-content: center;">
                        <div style="width: 70%; background: var(--primary); height: <?php echo $height; ?>px; border-radius: 6px 6px 0 0; transition: height 0.3s ease;"></div>
                    </div>
                    <div style="margin-top: 15px; font-size: 12px; color: var(--gray);"><?php echo $months[$i-1]; ?></div>
                    <div style="font-size: 11px; font-weight: 600; color: var(--primary);">$<?php echo number_format($monthly_revenue[$i] / 1000, 1); ?>k</div>
                </div>
            <?php endfor; ?>
        </div>
    </div>

    <!-- Two Column Layout -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px;">
        <!-- Top Products -->
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px; color: var(--dark);">Top Selling Products</h3>
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <?php if ($top_products && $top_products->num_rows > 0): ?>
                    <?php 
                    $max_revenue = 0;
                    $top_products->data_seek(0);
                    while($prod = $top_products->fetch_assoc()) {
                        $max_revenue = max($max_revenue, $prod['revenue']);
                    }
                    $top_products->data_seek(0);
                    
                    while($product = $top_products->fetch_assoc()): 
                        $percentage = $max_revenue > 0 ? ($product['revenue'] / $max_revenue) * 100 : 0;
                    ?>
                        <div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                <div>
                                    <span style="font-weight: 600;"><?php echo htmlspecialchars($product['name']); ?></span>
                                    <span style="color: var(--gray); margin-left: 10px;">(<?php echo $product['quantity_sold']; ?> sold)</span>
                                </div>
                                <span style="color: var(--primary); font-weight: 600;">$<?php echo number_format($product['revenue'], 2); ?></span>
                            </div>
                            <div style="width: 100%; height: 10px; background: #f3f4f6; border-radius: 5px;">
                                <div style="width: <?php echo $percentage; ?>%; height: 100%; background: linear-gradient(135deg, #6d5acf 0%, #a78bfa 100%); border-radius: 5px;"></div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="color: var(--gray); text-align: center;">No sales data available</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Category Performance -->
        <div class="table-wrapper">
            <h3 style="margin-bottom: 25px; color: var(--dark);">Category Performance</h3>
            <table class="products-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Products</th>
                        <th>Items Sold</th>
                        <th>Revenue</th>
                        <th>%</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($category_performance && $category_performance->num_rows > 0): ?>
                        <?php 
                        $category_performance->data_seek(0);
                        while($cat = $category_performance->fetch_assoc()): 
                            $percentage = $total_revenue > 0 ? ($cat['revenue'] / $total_revenue) * 100 : 0;
                        ?>
                            <tr>
                                <td><span class="category-badge"><?php echo htmlspecialchars($cat['category']); ?></span></td>
                                <td><?php echo $cat['product_count']; ?></td>
                                <td><?php echo $cat['items_sold']; ?></td>
                                <td class="price-cell">$<?php echo number_format($cat['revenue'], 2); ?></td>
                                <td>
                                    <span class="stat-trend positive"><?php echo number_format($percentage, 1); ?>%</span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 20px;">No category data available</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Orders -->
    <div class="table-wrapper">
        <h3 style="margin-bottom: 20px; color: var(--dark);">Recent Orders</h3>
        <div style="display: flex; flex-direction: column; gap: 15px;">
            <?php
            $recent_orders = $conn->query("
                SELECT order_number, customer_name, total_amount, status, order_date 
                FROM orders 
                ORDER BY order_date DESC 
                LIMIT 5
            ");
            
            if ($recent_orders && $recent_orders->num_rows > 0):
                while($order = $recent_orders->fetch_assoc()):
                    $status_colors = [
                        'pending' => 'status-out',
                        'processing' => 'status-low',
                        'completed' => 'status-instock',
                        'cancelled' => 'status-out'
                    ];
                    $status_class = $status_colors[$order['status']] ?? 'status-out';
            ?>
                <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f9fafb; border-radius: 10px;">
                    <div style="width: 40px; height: 40px; background: var(--primary); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div style="flex: 1;">
                        <p style="font-weight: 600;"><?php echo $order['order_number']; ?></p>
                        <p style="font-size: 12px; color: var(--gray);"><?php echo htmlspecialchars($order['customer_name']); ?></p>
                    </div>
                    <div style="text-align: right;">
                        <p class="price-cell" style="font-size: 16px;">$<?php echo number_format($order['total_amount'], 2); ?></p>
                        <span class="status-badge <?php echo $status_class; ?>" style="font-size: 10px;"><?php echo ucfirst($order['status']); ?></span>
                    </div>
                    <div style="color: var(--gray); font-size: 12px;">
                        <?php echo date('M d, H:i', strtotime($order['order_date'])); ?>
                    </div>
                </div>
            <?php 
                endwhile;
            endif;
            ?>
        </div>
    </div>
</div>

<script>
function changePeriod(period) {
    showToast(`Loading data for: ${period} days`);
    // Implement period change logic
}

function handleSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    // Implement search logic for analytics
    showToast(`Searching: ${searchTerm}`);
}
</script>

<?php include 'includes/footer.php'; ?>