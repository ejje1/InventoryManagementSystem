<?php
ob_start();
require_once 'config.php';
requireLogin();

// Get category performance
$categoryPerf = $conn->query("
    SELECT p.category, 
           COUNT(DISTINCT p.id) as product_count,
           COALESCE(SUM(oi.quantity), 0) as items_sold,
           COALESCE(SUM(oi.total), 0) as revenue
    FROM products p
    LEFT JOIN order_items oi ON p.id = oi.product_id
    WHERE p.category IS NOT NULL
    GROUP BY p.category
");

// Get analytics statistics
$totalRevenue = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status='completed'")->fetch_assoc()['total'] ?? 0;
$totalQuantity = $conn->query("SELECT SUM(quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$totalOrders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;

require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Analytics Dashboard</h1>
        <p>View insights and reports</p>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL REVENUE</h3>
            <p class="stat-value">₱<?php echo number_format($totalRevenue, 2); ?></p>
            <span class="stat-trend positive">All time</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-boxes"></i>
        </div>
        <div class="stat-details">
            <h3>ITEMS SOLD</h3>
            <p class="stat-value"><?php echo $totalQuantity; ?></p>
            <span class="stat-trend positive">All time</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL ORDERS</h3>
            <p class="stat-value"><?php echo $totalOrders; ?></p>
            <span class="stat-trend positive">Completed</span>
        </div>
    </div>
</div>

<div class="table-wrapper">
    <h3 style="margin-bottom: 20px; color: var(--text-primary);">Category Performance</h3>
    <table class="products-table" id="analyticsTable">
        <thead>
            <tr>
                <th>Category</th>
                <th>Products</th>
                <th>Items Sold</th>
                <th>Revenue</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($categoryPerf && $categoryPerf->num_rows > 0): ?>
                <?php while($cat = $categoryPerf->fetch_assoc()): ?>
                    <tr>
                        <td><span class="category-badge"><?php echo htmlspecialchars($cat['category']); ?></span></td>
                        <td style="color: var(--text-primary);"><?php echo $cat['product_count']; ?></td>
                        <td style="color: var(--text-primary);"><?php echo $cat['items_sold']; ?></td>
                        <td class="price-cell">₱<?php echo number_format($cat['revenue'], 2); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'include/footer.php'; ?> 