<?php
// Start output buffering
ob_start();

require_once 'config.php';

// Require login
requireLogin();

// Define redirect function
function redirect($url) {
    header("Location: $url");
    exit();
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Handle Product Actions
    if (isset($_POST['product_action'])) {
        // Add Product
        if ($_POST['product_action'] == 'add') {
            $name = $conn->real_escape_string($_POST['name']);
            $description = $conn->real_escape_string($_POST['description']);
            $price = floatval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            $category = $conn->real_escape_string($_POST['category']);
            
            $sql = "INSERT INTO products (name, description, price, quantity, category) 
                    VALUES ('$name', '$description', $price, $quantity, '$category')";
            
            if ($conn->query($sql)) {
                $_SESSION['toast'] = ['message' => 'Product added successfully!', 'type' => 'success'];
            } else {
                $_SESSION['toast'] = ['message' => 'Error adding product: ' . $conn->error, 'type' => 'error'];
            }
            redirect('index.php');
        }
        
        // Edit Product
        if ($_POST['product_action'] == 'edit') {
            $id = intval($_POST['id']);
            $name = $conn->real_escape_string($_POST['name']);
            $description = $conn->real_escape_string($_POST['description']);
            $price = floatval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            $category = $conn->real_escape_string($_POST['category']);
            
            $sql = "UPDATE products SET 
                    name='$name', 
                    description='$description', 
                    price=$price, 
                    quantity=$quantity, 
                    category='$category' 
                    WHERE id=$id";
            
            if ($conn->query($sql)) {
                $_SESSION['toast'] = ['message' => 'Product updated successfully!', 'type' => 'success'];
            } else {
                $_SESSION['toast'] = ['message' => 'Error updating product: ' . $conn->error, 'type' => 'error'];
            }
            redirect('index.php');
        }
    }
    
    // Handle Customer Actions
    if (isset($_POST['add_customer'])) {
        $first_name = $conn->real_escape_string($_POST['first_name']);
        $last_name = $conn->real_escape_string($_POST['last_name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $address = $conn->real_escape_string($_POST['address']);
        $city = $conn->real_escape_string($_POST['city']);
        $customer_type = $conn->real_escape_string($_POST['customer_type']);
        
        $sql = "INSERT INTO customers (first_name, last_name, email, phone, address, city, customer_type) 
                VALUES ('$first_name', '$last_name', '$email', '$phone', '$address', '$city', '$customer_type')";
        
        if ($conn->query($sql)) {
            $_SESSION['toast'] = ['message' => 'Customer added successfully!', 'type' => 'success'];
        } else {
            $_SESSION['toast'] = ['message' => 'Error adding customer: ' . $conn->error, 'type' => 'error'];
        }
        redirect('index.php');
    }
    
    // Edit Customer
    if (isset($_POST['edit_customer'])) {
        $id = intval($_POST['id']);
        $first_name = $conn->real_escape_string($_POST['first_name']);
        $last_name = $conn->real_escape_string($_POST['last_name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $address = $conn->real_escape_string($_POST['address']);
        $city = $conn->real_escape_string($_POST['city']);
        $customer_type = $conn->real_escape_string($_POST['customer_type']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "UPDATE customers SET 
                first_name='$first_name', 
                last_name='$last_name', 
                email='$email', 
                phone='$phone', 
                address='$address', 
                city='$city', 
                customer_type='$customer_type',
                status='$status'
                WHERE id=$id";
        
        if ($conn->query($sql)) {
            $_SESSION['toast'] = ['message' => 'Customer updated successfully!', 'type' => 'success'];
        } else {
            $_SESSION['toast'] = ['message' => 'Error updating customer: ' . $conn->error, 'type' => 'error'];
        }
        redirect('index.php');
    }
    
    // Handle New Order
    if (isset($_POST['new_order'])) {
        $order_number = 'ORD-' . date('Ymd') . '-' . str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT);
        $customer_name = $conn->real_escape_string($_POST['customer_name']);
        $customer_email = $conn->real_escape_string($_POST['customer_email']);
        $total_amount = floatval($_POST['total_amount']);
        $payment_method = $conn->real_escape_string($_POST['payment_method']);
        
        $sql = "INSERT INTO orders (order_number, customer_name, customer_email, total_amount, payment_method, status) 
                VALUES ('$order_number', '$customer_name', '$customer_email', $total_amount, '$payment_method', 'pending')";
        
        if ($conn->query($sql)) {
            $_SESSION['toast'] = ['message' => 'Order created successfully!', 'type' => 'success'];
        } else {
            $_SESSION['toast'] = ['message' => 'Error creating order: ' . $conn->error, 'type' => 'error'];
        }
        redirect('index.php');
    }
    
    // Edit Order Status
    if (isset($_POST['edit_order'])) {
        $id = intval($_POST['id']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "UPDATE orders SET status='$status' WHERE id=$id";
        
        if ($conn->query($sql)) {
            $_SESSION['toast'] = ['message' => 'Order status updated successfully!', 'type' => 'success'];
        } else {
            $_SESSION['toast'] = ['message' => 'Error updating order: ' . $conn->error, 'type' => 'error'];
        }
        redirect('index.php');
    }
}

// Handle AJAX Delete requests
if (isset($_GET['delete_product'])) {
    $id = intval($_GET['delete_product']);
    $sql = "DELETE FROM products WHERE id=$id";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

if (isset($_GET['delete_customer'])) {
    $id = intval($_GET['delete_customer']);
    $sql = "DELETE FROM customers WHERE id=$id";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

// Get statistics
$totalProducts = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'] ?? 0;
$totalValue = $conn->query("SELECT SUM(price * quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$totalQuantity = $conn->query("SELECT SUM(quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$lowStock = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity < 10")->fetch_assoc()['count'] ?? 0;

// Get products
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");

// Get customers
$customers = $conn->query("SELECT * FROM customers ORDER BY created_at DESC");

// Get orders
$orders = $conn->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 50");

// Get category performance
$categoryPerf = $conn->query("
    SELECT p.category, 
           COUNT(DISTINCT p.id) as product_count,
           COALESCE(SUM(oi.quantity), 0) as items_sold,
           COALESCE(SUM(oi.total), 0) as revenue
    FROM products p
    LEFT JOIN order_items oi ON p.id = oi.product_id
    WHERE p.category IS NOT NULL
    GROUP BY p.category
");

// Get order statistics
$totalOrders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;
$completedOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='completed'")->fetch_assoc()['count'] ?? 0;
$pendingOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='pending'")->fetch_assoc()['count'] ?? 0;
$cancelledOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='cancelled'")->fetch_assoc()['count'] ?? 0;
$totalRevenue = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status='completed'")->fetch_assoc()['total'] ?? 0;

// Get customer statistics
$totalCustomers = $conn->query("SELECT COUNT(*) as count FROM customers")->fetch_assoc()['count'] ?? 0;
$activeCustomers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE status='active'")->fetch_assoc()['count'] ?? 0;
$vipCustomers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE customer_type='vip'")->fetch_assoc()['count'] ?? 0;
$wholesaleCustomers = $conn->query("SELECT COUNT(*) as count FROM customers WHERE customer_type='wholesale'")->fetch_assoc()['count'] ?? 0;

// Get category count
$categoryCount = $conn->query("SELECT COUNT(DISTINCT category) as cat_count FROM products WHERE category IS NOT NULL AND category != ''")->fetch_assoc()['cat_count'] ?? 0;

// Get average price
$avgPrice = number_format($conn->query("SELECT AVG(price) as avg_price FROM products")->fetch_assoc()['avg_price'] ?? 0, 2);

// Get out of stock count
$outOfStock = $conn->query("SELECT COUNT(*) as out_count FROM products WHERE quantity = 0")->fetch_assoc()['out_count'] ?? 0;

// Get categories for filter
$categories = $conn->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category");

// Get category distribution
$catDistribution = $conn->query("SELECT category, COUNT(*) as count FROM products WHERE category IS NOT NULL AND category != '' GROUP BY category");

$current_user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JLC BEST CONSTRUCTION - Inventory Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        :root {
            --bg-primary: #0B0F1E;
            --bg-secondary: #151A2C;
            --text-primary: #FFFFFF;
            --text-secondary: #8B8E9B;
            --accent-blue: #1E4AE9;
            --accent-green: #2DC973;
            --accent-orange: #FF6B2C;
            --accent-red: #FF3B5C;
            --border-color: #2A2F42;
            --card-bg: #151A2C;
            --hover-bg: #1E2342;
            --gradient-1: linear-gradient(135deg, #1E4AE9, #7B4AFF);
            --gradient-2: linear-gradient(135deg, #2DC973, #1E4AE9);
            --gradient-3: linear-gradient(135deg, #FF6B2C, #FF3B5C);
            --modal-overlay: rgba(0, 0, 0, 0.8);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }

        /* Light theme variables */
        body.light-theme {
            --bg-primary: #F5F7FB;
            --bg-secondary: #FFFFFF;
            --text-primary: #1A1F36;
            --text-secondary: #6B7280;
            --border-color: #E5E7EB;
            --card-bg: #FFFFFF;
            --hover-bg: #F3F4F6;
            --modal-overlay: rgba(0, 0, 0, 0.5);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Top Navigation */
        .top-nav {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 12px 24px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow);
            transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 8px;
            list-style: none;
        }

        .nav-links li {
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 500;
        }

        .nav-links li:hover {
            background: var(--hover-bg);
            color: var(--text-primary);
        }

        .nav-links li.active {
            background: var(--gradient-1);
            color: white;
        }

        .nav-links li a {
            color: inherit;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-links li i {
            font-size: 14px;
        }

        .company-title {
            font-size: 18px;
            font-weight: 700;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-profile img {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            object-fit: cover;
            border: 2px solid var(--border-color);
            transition: border-color 0.3s ease;
        }

        .user-info {
            text-align: right;
        }

        .user-info h4 {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            transition: color 0.3s ease;
        }

        .user-info p {
            font-size: 11px;
            color: var(--text-secondary);
            transition: color 0.3s ease;
        }

        .logout-btn {
            color: var(--accent-red);
            margin-left: 12px;
            transition: transform 0.3s ease;
        }

        .logout-btn:hover {
            transform: scale(1.1);
        }

        /* Main Content */
        .main-content {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 24px;
            box-shadow: var(--shadow);
            transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .search-wrapper {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 8px 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            width: 300px;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .search-wrapper i {
            color: var(--text-secondary);
            font-size: 14px;
            transition: color 0.3s ease;
        }

        .search-wrapper input {
            background: none;
            border: none;
            color: var(--text-primary);
            font-size: 14px;
            width: 100%;
            outline: none;
            transition: color 0.3s ease;
        }

        .search-wrapper input::placeholder {
            color: var(--text-secondary);
            transition: color 0.3s ease;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .notification-btn {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 8px 12px;
            color: var(--text-primary);
            cursor: pointer;
            position: relative;
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }

        .notification-btn:hover {
            transform: translateY(-2px);
            background: var(--hover-bg);
        }

        .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--accent-red);
            color: white;
            font-size: 10px;
            padding: 2px 5px;
            border-radius: 10px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.1);
            }
            100% {
                transform: scale(1);
            }
        }

        .theme-toggle {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 8px 12px;
            color: var(--text-primary);
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }

        .theme-toggle:hover {
            transform: rotate(15deg);
            background: var(--hover-bg);
        }

        /* Welcome Section */
        .welcome-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .welcome-text h1 {
            font-size: 24px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
            transition: color 0.3s ease;
            animation: fadeInUp 0.5s ease;
        }

        .welcome-text p {
            font-size: 14px;
            color: var(--text-secondary);
            transition: color 0.3s ease;
            animation: fadeInUp 0.5s ease 0.1s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--gradient-1);
            color: white;
            position: relative;
            overflow: hidden;
        }

        .btn-primary::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn-primary:hover::before {
            width: 300px;
            height: 300px;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 74, 233, 0.3);
        }

        .btn-secondary {
            background: var(--bg-primary);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }

        .btn-secondary:hover {
            background: var(--hover-bg);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: all 0.3s ease;
            animation: fadeInUp 0.5s ease;
            animation-fill-mode: both;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }
        .stat-card:nth-child(4) { animation-delay: 0.4s; }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            border-color: var(--accent-blue);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: transform 0.3s ease;
        }

        .stat-card:hover .stat-icon {
            transform: scale(1.1) rotate(5deg);
        }

        .stat-details h3 {
            font-size: 12px;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 4px;
            transition: color 0.3s ease;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
            transition: color 0.3s ease;
        }

        .stat-trend {
            font-size: 11px;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .stat-trend.positive {
            color: var(--accent-green);
        }

        .stat-trend.negative {
            color: var(--accent-red);
        }

        /* Filters Section */
        .filters-section {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            transition: background-color 0.3s ease, border-color 0.3s ease;
            animation: fadeInUp 0.5s ease 0.5s both;
        }

        .filter-group {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-group label {
            font-size: 14px;
            color: var(--text-secondary);
            transition: color 0.3s ease;
        }

        .filter-select {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 8px 12px;
            color: var(--text-primary);
            font-size: 13px;
            outline: none;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }

        .filter-select:hover {
            border-color: var(--accent-blue);
        }

        /* Table Styles */
        .table-wrapper {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 24px;
            transition: background-color 0.3s ease, border-color 0.3s ease;
            animation: fadeInUp 0.5s ease 0.6s both;
        }

        .products-table {
            width: 100%;
            border-collapse: collapse;
        }

        .products-table th {
            background: var(--bg-secondary);
            padding: 16px 20px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border-color);
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }

        .products-table td {
            padding: 16px 20px;
            font-size: 14px;
            color: var(--text-primary);
            border-bottom: 1px solid var(--border-color);
            transition: color 0.3s ease, border-color 0.3s ease;
        }

        .products-table tr:last-child td {
            border-bottom: none;
        }

        .products-table tbody tr {
            transition: background-color 0.3s ease;
        }

        .products-table tbody tr:hover {
            background: var(--hover-bg);
        }

        .product-cell {
            min-width: 200px;
        }

        .product-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .product-icon {
            width: 40px;
            height: 40px;
            background: var(--bg-secondary);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent-blue);
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .product-info:hover .product-icon {
            transform: scale(1.1) rotate(5deg);
        }

        .product-details h4 {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 2px;
            transition: color 0.3s ease;
        }

        .product-details p {
            font-size: 12px;
            color: var(--text-secondary);
            transition: color 0.3s ease;
        }

        .category-badge {
            background: var(--bg-secondary);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            display: inline-block;
        }

        .category-badge:hover {
            background: var(--gradient-1);
            color: white;
            border-color: transparent;
            transform: translateY(-2px);
        }

        .price-cell {
            font-weight: 600;
            color: var(--accent-green);
            transition: color 0.3s ease;
        }

        .stock-cell {
            font-weight: 500;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .status-badge:hover {
            transform: scale(1.05);
        }

        .status-instock {
            background: rgba(45, 201, 115, 0.15);
            color: var(--accent-green);
        }

        .status-low {
            background: rgba(255, 107, 44, 0.15);
            color: var(--accent-orange);
        }

        .status-out {
            background: rgba(255, 59, 92, 0.15);
            color: var(--accent-red);
        }

        .actions-cell {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
            background: var(--bg-secondary);
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            background: var(--hover-bg);
            color: var(--text-primary);
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        .action-btn.edit:hover {
            background: var(--accent-blue);
            color: white;
            border-color: var(--accent-blue);
        }

        .action-btn.delete:hover {
            background: var(--accent-red);
            color: white;
            border-color: var(--accent-red);
        }

        .action-btn.view:hover {
            background: var(--accent-green);
            color: white;
            border-color: var(--accent-green);
        }

        /* Footer */
        .footer-info {
            display: flex;
            gap: 24px;
            padding: 20px 0 0;
            color: var(--text-secondary);
            font-size: 13px;
            transition: color 0.3s ease;
            animation: fadeInUp 0.5s ease 0.7s both;
        }

        .footer-info i {
            margin-right: 6px;
            color: var(--accent-blue);
            transition: color 0.3s ease;
        }

        /* Page Visibility */
        .page {
            display: none;
        }

        .page.active-page {
            display: block;
        }

        /* Modal Styles - Enhanced with animations */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: var(--modal-overlay);
            backdrop-filter: blur(5px);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .modal-content {
            background: var(--bg-secondary);
            margin: 50px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            border: 1px solid var(--border-color);
            overflow: hidden;
            box-shadow: var(--shadow);
            animation: slideInDown 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            transform-origin: top center;
        }

        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-100px) scale(0.8);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-header {
            background: var(--bg-primary);
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .modal-header h2 {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            transition: color 0.3s ease;
            animation: slideInRight 0.3s ease;
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .close-btn {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            width: 32px;
            height: 32px;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            transition: all 0.3s ease;
        }

        .close-btn:hover {
            background: var(--accent-red);
            color: white;
            border-color: var(--accent-red);
            transform: rotate(90deg);
        }

        form {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 16px;
            animation: fadeInUp 0.3s ease;
            animation-fill-mode: both;
        }

        .form-group:nth-child(1) { animation-delay: 0.1s; }
        .form-group:nth-child(2) { animation-delay: 0.15s; }
        .form-group:nth-child(3) { animation-delay: 0.2s; }
        .form-group:nth-child(4) { animation-delay: 0.25s; }
        .form-group:nth-child(5) { animation-delay: 0.3s; }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
            transition: color 0.3s ease;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-primary);
            font-size: 14px;
            outline: none;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(30, 74, 233, 0.1);
            transform: translateY(-2px);
        }

        .form-group input:hover,
        .form-group select:hover,
        .form-group textarea:hover {
            border-color: var(--accent-blue);
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            animation: fadeInUp 0.3s ease 0.35s both;
        }

        .form-actions button {
            flex: 1;
            padding: 10px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .form-actions button:first-child:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 74, 233, 0.3);
        }

        .form-actions button:last-child:hover {
            transform: translateY(-2px);
            background: var(--hover-bg);
        }

        .btn-danger {
            background: var(--accent-red);
            color: white;
            transition: all 0.3s ease;
        }

        .btn-danger:hover {
            background: #ff1f45;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 59, 92, 0.3);
        }

        /* Delete Modal Specific Animation */
        #deleteModal .modal-content {
            animation: shakeIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        @keyframes shakeIn {
            0% {
                opacity: 0;
                transform: scale(0.5) rotate(-10deg);
            }
            50% {
                transform: scale(1.1) rotate(5deg);
            }
            100% {
                opacity: 1;
                transform: scale(1) rotate(0);
            }
        }

        #deleteModal i {
            animation: pulse 2s infinite;
        }

        /* Settings Tabs */
        .settings-tab {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .settings-tab:hover {
            background: var(--hover-bg);
            transform: translateY(-2px);
        }

        .settings-tab.active {
            background: var(--gradient-1);
            color: white;
            border: none;
        }

        .settings-section {
            display: none;
            animation: fadeIn 0.3s ease;
        }

        .settings-section.active-section {
            display: block;
        }

        .settings-input, .settings-select {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 10px 12px;
            border-radius: 6px;
            width: 100%;
            transition: all 0.3s ease;
        }

        .settings-input:focus, .settings-select:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(30, 74, 233, 0.1);
            transform: translateY(-2px);
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-primary);
            font-size: 14px;
            margin-bottom: 10px;
            transition: color 0.3s ease;
            cursor: pointer;
        }

        .checkbox-label:hover {
            color: var(--accent-blue);
        }

        .checkbox-label input[type="checkbox"] {
            width: 16px;
            height: 16px;
            cursor: pointer;
            accent-color: var(--accent-blue);
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-left: 3px solid var(--accent-green);
            padding: 12px 20px;
            border-radius: 8px;
            display: none;
            align-items: center;
            gap: 12px;
            box-shadow: var(--shadow);
            z-index: 1100;
            animation: slideInRight 0.3s ease;
        }

        .toast.show {
            display: flex;
            animation: slideInRight 0.3s ease;
        }

        .toast i {
            color: var(--accent-green);
            font-size: 18px;
            animation: pulse 2s infinite;
        }

        .toast span {
            color: var(--text-primary);
            font-size: 14px;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .nav-links {
                flex-wrap: wrap;
            }
            
            .top-nav {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Top Navigation -->
        <nav class="top-nav">
            <div class="company-title">
                JLC BEST CONSTRUCTION OPC
            </div>
            
            <ul class="nav-links">
                <li class="active" data-page="dashboard">
                    <a href="#" onclick="switchPage('dashboard'); return false;">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li data-page="products">
                    <a href="#" onclick="switchPage('products'); return false;">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                    </a>
                </li>
                <li data-page="orders">
                    <a href="#" onclick="switchPage('orders'); return false;">
                        <i class="fas fa-shopping-cart"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li data-page="customers">
                    <a href="#" onclick="switchPage('customers'); return false;">
                        <i class="fas fa-users"></i>
                        <span>Customers</span>
                    </a>
                </li>
                <li data-page="analytics">
                    <a href="#" onclick="switchPage('analytics'); return false;">
                        <i class="fas fa-chart-line"></i>
                        <span>Analytics</span>
                    </a>
                </li>
                <li data-page="settings">
                    <a href="#" onclick="switchPage('settings'); return false;">
                        <i class="fas fa-cog"></i>
                        <span>Settings</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-profile">
                <div class="user-info">
                    <h4><?php echo ucfirst($current_user['username'] ?? 'Admin'); ?></h4>
                    <p><?php echo strtoupper($current_user['role'] ?? 'ADMINISTRATOR'); ?></p>
                </div>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($current_user['username'] ?? 'Admin'); ?>&background=1E4AE9&color=fff&size=128" alt="Profile">
                <a href="logout.php" class="logout-btn" title="Logout">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div class="search-wrapper">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Type here to search..." onkeyup="handleSearch()">
                </div>
                
                <div class="header-actions">
                    <button class="notification-btn">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </button>
                    <button class="theme-toggle" onclick="toggleTheme()">
                        <i class="fas fa-moon"></i>
                    </button>
                </div>
            </header>

            <!-- Dynamic Page Content -->
            <div id="page-content">
                <!-- DASHBOARD PAGE -->
                <div id="dashboard-page" class="page active-page">
                    <div class="welcome-section">
                        <div class="welcome-text">
                            <h1>Welcome back, <?php echo ucfirst($current_user['username'] ?? 'Admin'); ?>! 🎉</h1>
                            <p>Here's what's happening with your inventory today.</p>
                        </div>
                        <div></div>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #1E4AE9 0%, #7B4AFF 100%)">
                                <i class="fas fa-box"></i>
                            </div>
                            <div class="stat-details">
                                <h3>PRODUCTS</h3>
                                <p class="stat-value"><?php echo $totalProducts; ?></p>
                                <span class="stat-trend positive">Active items</span>
                            </div>
                        </div>

                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #2DC973 0%, #1E4AE9 100%)">
                                <i class="fas fa-peso-sign"></i>
                            </div>
                            <div class="stat-details">
                                <h3>TOTAL VALUE</h3>
                                <p class="stat-value">₱<?php echo number_format($totalValue, 2); ?></p>
                                <span class="stat-trend positive">Inventory value</span>
                            </div>
                        </div>

                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF6B2C 0%, #FF3B5C 100%)">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stat-details">
                                <h3>IN STOCK</h3>
                                <p class="stat-value"><?php echo $totalQuantity; ?></p>
                                <span class="stat-trend positive">Units available</span>
                            </div>
                        </div>

                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF3B5C 0%, #FF6B2C 100%)">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div class="stat-details">
                                <h3>LOW STOCK</h3>
                                <p class="stat-value"><?php echo $lowStock; ?></p>
                                <span class="stat-trend positive">Need reorder</span>
                            </div>
                        </div>
                    </div>

                    <div class="filters-section">
                        <div class="filter-group">
                            <label>All Categories</label>
                            <select id="categoryFilter" class="filter-select" onchange="filterByCategory()">
                                <option value="">All Categories</option>
                                <?php
                                if ($categories && $categories->num_rows > 0) {
                                    while($row = $categories->fetch_assoc()) {
                                        echo '<option value="' . htmlspecialchars($row['category']) . '">' . htmlspecialchars($row['category']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label>Sort by:</label>
                            <select id="sortFilter" class="filter-select" onchange="sortProducts()">
                                <option value="newest">Newest First</option>
                                <option value="name">Name A-Z</option>
                                <option value="price_low">Price: Low to High</option>
                                <option value="price_high">Price: High to Low</option>
                                <option value="stock_low">Stock: Low to High</option>
                            </select>
                        </div>
                        
                        <button class="btn btn-secondary" onclick="exportTableToCSV('products')">
                            <i class="fas fa-download"></i>
                            Export
                        </button>
                        
                        <button class="btn btn-primary" onclick="openAddModal()">
                            <i class="fas fa-plus"></i>
                            Add New Product
                        </button>
                    </div>

                    <div class="table-wrapper">
                        <table class="products-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="productsBody">
                                <?php if ($products && $products->num_rows > 0): ?>
                                    <?php while($row = $products->fetch_assoc()): 
                                        $status = $row['quantity'] > 20 ? 'In Stock' : ($row['quantity'] > 0 ? 'Low Stock' : 'Out of Stock');
                                        $statusClass = $row['quantity'] > 20 ? 'status-instock' : ($row['quantity'] > 0 ? 'status-low' : 'status-out');
                                        $description = htmlspecialchars(substr($row['description'] ?? '', 0, 30));
                                        if (strlen($row['description'] ?? '') > 30) $description .= '...';
                                    ?>
                                        <tr data-product-id="<?php echo $row['id']; ?>">
                                            <td class="product-cell">
                                                <div class="product-info">
                                                    <div class="product-icon">
                                                        <i class="fas fa-box"></i>
                                                    </div>
                                                    <div class="product-details">
                                                        <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                                        <p><?php echo $description; ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><span class="category-badge"><?php echo htmlspecialchars($row['category'] ?? 'Accessories'); ?></span></td>
                                            <td class="price-cell">₱<?php echo number_format($row['price'], 2); ?></td>
                                            <td class="stock-cell"><?php echo $row['quantity']; ?> units</td>
                                            <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                                            <td class="actions-cell">
                                                <button class="action-btn edit" onclick='openEditModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>, <?php echo json_encode($row['description'] ?? ''); ?>, <?php echo $row['price']; ?>, <?php echo $row['quantity']; ?>, <?php echo json_encode($row['category'] ?? ''); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                                                <button class="action-btn delete" onclick='openDeleteProductModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>)' title="Delete"><i class="fas fa-trash"></i></button>
                                                <button class="action-btn view" onclick='openViewModal(<?php echo json_encode($row); ?>)' title="View"><i class="fas fa-eye"></i></button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" style="text-align: center; padding: 40px;">No products found. Click "Add New Product" to get started.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- PRODUCTS PAGE -->
                <div id="products-page" class="page">
                    <div class="welcome-section">
                        <div class="welcome-text">
                            <h1>Products Management</h1>
                            <p>Manage your product inventory</p>
                        </div>
                        <button class="btn btn-primary" onclick="openAddModal()">
                            <i class="fas fa-plus"></i>
                            Add New Product
                        </button>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #1E4AE9 0%, #7B4AFF 100%)">
                                <i class="fas fa-cubes"></i>
                            </div>
                            <div class="stat-details">
                                <h3>TOTAL PRODUCTS</h3>
                                <p class="stat-value"><?php echo $totalProducts; ?></p>
                                <span class="stat-trend positive">Active items</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #2DC973 0%, #1E4AE9 100%)">
                                <i class="fas fa-tags"></i>
                            </div>
                            <div class="stat-details">
                                <h3>CATEGORIES</h3>
                                <p class="stat-value"><?php echo $categoryCount; ?></p>
                                <span class="stat-trend positive">Categories</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF6B2C 0%, #FF3B5C 100%)">
                                <i class="fas fa-peso-sign"></i>
                            </div>
                            <div class="stat-details">
                                <h3>AVG PRICE</h3>
                                <p class="stat-value">₱<?php echo $avgPrice; ?></p>
                                <span class="stat-trend positive">Per item</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF3B5C 0%, #FF6B2C 100%)">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                            <div class="stat-details">
                                <h3>OUT OF STOCK</h3>
                                <p class="stat-value"><?php echo $outOfStock; ?></p>
                                <span class="stat-trend negative">Need restock</span>
                            </div>
                        </div>
                    </div>

                    <div class="filters-section" style="justify-content: space-between; flex-wrap: wrap;">
                        <h3 style="font-size: 16px; font-weight: 600; color: var(--text-primary);">Category Distribution</h3>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            <?php if ($catDistribution && $catDistribution->num_rows > 0): ?>
                                <?php while($cat = $catDistribution->fetch_assoc()): ?>
                                    <span class="category-badge" style="background: var(--gradient-1); color: white; padding: 8px 15px; border: none;">
                                        <?php echo htmlspecialchars($cat['category']); ?>: <?php echo $cat['count']; ?>
                                    </span>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <table class="products-table" id="productsTable">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="productsPageBody">
                                <?php 
                                $products->data_seek(0);
                                if ($products && $products->num_rows > 0): 
                                    while($row = $products->fetch_assoc()): 
                                        $status = $row['quantity'] > 20 ? 'In Stock' : ($row['quantity'] > 0 ? 'Low Stock' : 'Out of Stock');
                                        $statusClass = $row['quantity'] > 20 ? 'status-instock' : ($row['quantity'] > 0 ? 'status-low' : 'status-out');
                                ?>
                                    <tr data-product-id="<?php echo $row['id']; ?>">
                                        <td class="product-cell">
                                            <div class="product-info">
                                                <div class="product-icon"><i class="fas fa-box"></i></div>
                                                <div class="product-details">
                                                    <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                                    <p><?php echo htmlspecialchars(substr($row['description'] ?? '', 0, 30)) . '...'; ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td><span class="category-badge"><?php echo htmlspecialchars($row['category'] ?? 'Accessories'); ?></span></td>
                                        <td class="price-cell">₱<?php echo number_format($row['price'], 2); ?></td>
                                        <td class="stock-cell"><?php echo $row['quantity']; ?> units</td>
                                        <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                                        <td class="actions-cell">
                                            <button class="action-btn edit" onclick='openEditModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>, <?php echo json_encode($row['description'] ?? ''); ?>, <?php echo $row['price']; ?>, <?php echo $row['quantity']; ?>, <?php echo json_encode($row['category'] ?? ''); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                                            <button class="action-btn delete" onclick='openDeleteProductModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>)' title="Delete"><i class="fas fa-trash"></i></button>
                                            <button class="action-btn view" onclick='openViewModal(<?php echo json_encode($row); ?>)' title="View"><i class="fas fa-eye"></i></button>
                                        </td>
                                    </tr>
                                <?php endwhile; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- ORDERS PAGE -->
                <div id="orders-page" class="page">
                    <div class="welcome-section">
                        <div class="welcome-text">
                            <h1>Orders Management</h1>
                            <p>Track and manage orders</p>
                        </div>
                        <button class="btn btn-primary" onclick="openNewOrderModal()">
                            <i class="fas fa-plus"></i>
                            New Order
                        </button>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #1E4AE9 0%, #7B4AFF 100%)">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="stat-details">
                                <h3>TOTAL ORDERS</h3>
                                <p class="stat-value"><?php echo $totalOrders; ?></p>
                                <span class="stat-trend positive">All time</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #2DC973 0%, #1E4AE9 100%)">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stat-details">
                                <h3>COMPLETED</h3>
                                <p class="stat-value"><?php echo $completedOrders; ?></p>
                                <span class="stat-trend positive"><?php echo $totalOrders ? round(($completedOrders/$totalOrders)*100, 1) : 0; ?>%</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF6B2C 0%, #FF3B5C 100%)">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="stat-details">
                                <h3>PENDING</h3>
                                <p class="stat-value"><?php echo $pendingOrders; ?></p>
                                <span class="stat-trend negative"><?php echo $totalOrders ? round(($pendingOrders/$totalOrders)*100, 1) : 0; ?>%</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF3B5C 0%, #FF6B2C 100%)">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <div class="stat-details">
                                <h3>CANCELLED</h3>
                                <p class="stat-value"><?php echo $cancelledOrders; ?></p>
                                <span class="stat-trend negative"><?php echo $totalOrders ? round(($cancelledOrders/$totalOrders)*100, 1) : 0; ?>%</span>
                            </div>
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <table class="products-table" id="ordersTable">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Customer</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="ordersTableBody">
                                <?php if ($orders && $orders->num_rows > 0): ?>
                                    <?php while($order = $orders->fetch_assoc()): 
                                        $status_class = $order['status'] == 'completed' ? 'status-instock' : ($order['status'] == 'pending' ? 'status-out' : 'status-low');
                                    ?>
                                        <tr data-order-id="<?php echo $order['id']; ?>">
                                            <td><strong style="color: var(--text-primary);"><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                                            <td style="color: var(--text-primary);"><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                            <td style="color: var(--text-primary);"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                            <td class="price-cell">₱<?php echo number_format($order['total_amount'], 2); ?></td>
                                            <td><span class="status-badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                                            <td class="actions-cell">
                                                <button class="action-btn view" onclick='openViewOrderModal(<?php echo json_encode($order); ?>)' title="View"><i class="fas fa-eye"></i></button>
                                                <button class="action-btn edit" onclick='openEditOrderModal(<?php echo json_encode($order); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" style="text-align: center; padding: 40px;">No orders found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- CUSTOMERS PAGE -->
                <div id="customers-page" class="page">
                    <div class="welcome-section">
                        <div class="welcome-text">
                            <h1>Customer Management</h1>
                            <p>Manage your customers</p>
                        </div>
                        <button class="btn btn-primary" onclick="openAddCustomerModal()">
                            <i class="fas fa-user-plus"></i>
                            Add Customer
                        </button>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #1E4AE9 0%, #7B4AFF 100%)">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stat-details">
                                <h3>TOTAL CUSTOMERS</h3>
                                <p class="stat-value"><?php echo $totalCustomers; ?></p>
                                <span class="stat-trend positive">Registered</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #2DC973 0%, #1E4AE9 100%)">
                                <i class="fas fa-user-check"></i>
                            </div>
                            <div class="stat-details">
                                <h3>ACTIVE</h3>
                                <p class="stat-value"><?php echo $activeCustomers; ?></p>
                                <span class="stat-trend positive"><?php echo $totalCustomers ? round(($activeCustomers/$totalCustomers)*100, 1) : 0; ?>%</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF6B2C 0%, #FF3B5C 100%)">
                                <i class="fas fa-crown"></i>
                            </div>
                            <div class="stat-details">
                                <h3>VIP</h3>
                                <p class="stat-value"><?php echo $vipCustomers; ?></p>
                                <span class="stat-trend positive">Premium</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF3B5C 0%, #FF6B2C 100%)">
                                <i class="fas fa-briefcase"></i>
                            </div>
                            <div class="stat-details">
                                <h3>WHOLESALE</h3>
                                <p class="stat-value"><?php echo $wholesaleCustomers; ?></p>
                                <span class="stat-trend positive">Business</span>
                            </div>
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <table class="products-table" id="customersTable">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Contact</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="customersTableBody">
                                <?php if ($customers && $customers->num_rows > 0): ?>
                                    <?php while($customer = $customers->fetch_assoc()): 
                                        $type_colors = [
                                            'regular' => 'var(--bg-secondary)',
                                            'vip' => '#FF6B2C',
                                            'wholesale' => '#2DC973'
                                        ];
                                        $type_color = $type_colors[$customer['customer_type']] ?? 'var(--bg-secondary)';
                                        $text_color = in_array($customer['customer_type'], ['vip', 'wholesale']) ? 'white' : 'var(--text-primary)';
                                    ?>
                                        <tr data-customer-id="<?php echo $customer['id']; ?>">
                                            <td class="product-cell">
                                                <div class="product-info">
                                                    <div class="product-icon" style="background: <?php echo $type_color; ?>; color: <?php echo $text_color; ?>;">
                                                        <i class="fas fa-user"></i>
                                                    </div>
                                                    <div class="product-details">
                                                        <h4 style="color: var(--text-primary);"><?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></h4>
                                                    </div>
                                                </div>
                                            </td>
                                            <td style="color: var(--text-primary);"><?php echo htmlspecialchars($customer['email']); ?></td>
                                            <td>
                                                <span class="category-badge" style="background: <?php echo $type_color; ?>; color: <?php echo $text_color; ?>; border: none;">
                                                    <?php echo ucfirst($customer['customer_type']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge <?php echo $customer['status'] == 'active' ? 'status-instock' : 'status-out'; ?>">
                                                    <?php echo ucfirst($customer['status']); ?>
                                                </span>
                                            </td>
                                            <td class="actions-cell">
                                                <button class="action-btn view" onclick='openCustomerViewModal(<?php echo json_encode($customer); ?>)' title="View"><i class="fas fa-eye"></i></button>
                                                <button class="action-btn edit" onclick='openCustomerEditModal(<?php echo json_encode($customer); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                                                <button class="action-btn delete" onclick='openDeleteCustomerModal(<?php echo $customer['id']; ?>, <?php echo json_encode($customer['first_name'] . ' ' . $customer['last_name']); ?>)' title="Delete"><i class="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- ANALYTICS PAGE -->
                <div id="analytics-page" class="page">
                    <div class="welcome-section">
                        <div class="welcome-text">
                            <h1>Analytics Dashboard</h1>
                            <p>View insights and reports</p>
                        </div>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #1E4AE9 0%, #7B4AFF 100%)">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div class="stat-details">
                                <h3>TOTAL REVENUE</h3>
                                <p class="stat-value">₱<?php echo number_format($totalRevenue, 2); ?></p>
                                <span class="stat-trend positive">All time</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #2DC973 0%, #1E4AE9 100%)">
                                <i class="fas fa-boxes"></i>
                            </div>
                            <div class="stat-details">
                                <h3>ITEMS SOLD</h3>
                                <p class="stat-value"><?php echo $totalQuantity; ?></p>
                                <span class="stat-trend positive">All time</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #FF6B2C 0%, #FF3B5C 100%)">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="stat-details">
                                <h3>TOTAL ORDERS</h3>
                                <p class="stat-value"><?php echo $totalOrders; ?></p>
                                <span class="stat-trend positive">Completed</span>
                            </div>
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <h3 style="margin-bottom: 20px; color: var(--text-primary);">Category Performance</h3>
                        <table class="products-table" id="analyticsTable">
                            <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Products</th>
                                    <th>Items Sold</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($categoryPerf && $categoryPerf->num_rows > 0): ?>
                                    <?php while($cat = $categoryPerf->fetch_assoc()): ?>
                                        <tr>
                                            <td><span class="category-badge"><?php echo htmlspecialchars($cat['category']); ?></span></td>
                                            <td style="color: var(--text-primary);"><?php echo $cat['product_count']; ?></td>
                                            <td style="color: var(--text-primary);"><?php echo $cat['items_sold']; ?></td>
                                            <td class="price-cell">₱<?php echo number_format($cat['revenue'], 2); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- SETTINGS PAGE -->
                <div id="settings-page" class="page">
                    <div class="welcome-section">
                        <div class="welcome-text">
                            <h1>Settings</h1>
                            <p>Configure your preferences</p>
                        </div>
                    </div>

                    <div style="display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;">
                        <button class="settings-tab active" onclick="switchSettingsTab('general')">General</button>
                        <button class="settings-tab" onclick="switchSettingsTab('notifications')">Notifications</button>
                        <button class="settings-tab" onclick="switchSettingsTab('security')">Security</button>
                    </div>

                    <div id="general-settings" class="settings-section active-section">
                        <div class="table-wrapper">
                            <h3 style="margin-bottom: 25px; color: var(--text-primary);">General Settings</h3>
                            <div class="form-group">
                                <label style="color: var(--text-primary);">Store Name</label>
                                <input type="text" value="JLC BEST CONSTRUCTION" class="settings-input">
                            </div>
                            <div class="form-group">
                                <label style="color: var(--text-primary);">Currency</label>
                                <select class="settings-select">
                                    <option value="PHP" selected>PHP (₱)</option>
                                    <option value="USD">USD ($)</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div id="notifications-settings" class="settings-section">
                        <div class="table-wrapper">
                            <h3 style="margin-bottom: 25px; color: var(--text-primary);">Notifications</h3>
                            <label class="checkbox-label" style="color: var(--text-primary);">
                                <input type="checkbox" checked> Email notifications
                            </label>
                            <label class="checkbox-label" style="color: var(--text-primary);">
                                <input type="checkbox" checked> Low stock alerts
                            </label>
                        </div>
                    </div>

                    <div id="security-settings" class="settings-section">
                        <div class="table-wrapper">
                            <h3 style="margin-bottom: 25px; color: var(--text-primary);">Security</h3>
                            <div class="form-group">
                                <label style="color: var(--text-primary);">Minimum password length</label>
                                <input type="number" value="8" class="settings-input" style="width: 100px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-info">
                <div><i class="fas fa-sun"></i> 89°F Partly sunny</div>
                <div><i class="far fa-clock"></i> <span id="currentTime"></span></div>
                <div><i class="far fa-calendar"></i> <span id="currentDate"></span></div>
            </div>
        </main>
    </div>

    <!-- Add Product Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Add New Product</h2>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <form id="productForm" method="POST" action="">
                <input type="hidden" name="product_action" id="formAction" value="add">
                <input type="hidden" name="id" id="productId">
                <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" name="name" id="productName" required>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="category" id="productCategory" required>
                        <option value="Accessories">Accessories</option>
                        <option value="Electronics">Electronics</option>
                        <option value="Furniture">Furniture</option>
                        <option value="Office Supplies">Office Supplies</option>
                        <option value="Clothing">Clothing</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="productDescription" rows="3"></textarea>
                </div>
                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div class="form-group">
                        <label>Price (₱)</label>
                        <input type="number" name="price" id="productPrice" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" name="quantity" id="productQuantity" required>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Product Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Product Details</h2>
                <button class="close-btn" onclick="closeViewModal()">&times;</button>
            </div>
            <div id="productDetails" class="product-details-view" style="padding: 20px;"></div>
        </div>
    </div>

    <!-- Add Customer Modal -->
    <div id="customerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="customerModalTitle">Add Customer</h2>
                <button class="close-btn" onclick="closeCustomerModal()">&times;</button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="add_customer" id="customerFormAction" value="1">
                <input type="hidden" name="id" id="customerId">
                <input type="hidden" name="status" id="customerStatus" value="active">
                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" id="customerFirstName" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" id="customerLastName" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="customerEmail" required>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" id="customerPhone">
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" id="customerAddress" rows="2"></textarea>
                </div>
                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" id="customerCity">
                    </div>
                    <div class="form-group">
                        <label>Customer Type</label>
                        <select name="customer_type" id="customerType">
                            <option value="regular">Regular</option>
                            <option value="vip">VIP</option>
                            <option value="wholesale">Wholesale</option>
                        </select>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary" id="customerSubmitBtn">Save</button>
                    <button type="button" class="btn btn-secondary" onclick="closeCustomerModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- New Order Modal -->
    <div id="newOrderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Order</h2>
                <button class="close-btn" onclick="closeNewOrderModal()">&times;</button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="new_order" value="1">
                <div class="form-group">
                    <label>Customer Name</label>
                    <input type="text" name="customer_name" required>
                </div>
                <div class="form-group">
                    <label>Customer Email</label>
                    <input type="email" name="customer_email" required>
                </div>
                <div class="form-group">
                    <label>Total Amount (₱)</label>
                    <input type="number" name="total_amount" step="0.01" required>
                </div>
                <div class="form-group">
                    <label>Payment Method</label>
                    <select name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="credit_card">Credit Card</option>
                        <option value="paypal">PayPal</option>
                        <option value="bank_transfer">Bank Transfer</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Create Order</button>
                    <button type="button" class="btn btn-secondary" onclick="closeNewOrderModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Order Modal -->
    <div id="viewOrderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Order Details</h2>
                <button class="close-btn" onclick="closeViewOrderModal()">&times;</button>
            </div>
            <div id="orderDetails" class="product-details-view" style="padding: 20px;"></div>
        </div>
    </div>

    <!-- Edit Order Modal -->
    <div id="editOrderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Order Status</h2>
                <button class="close-btn" onclick="closeEditOrderModal()">&times;</button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="edit_order" value="1">
                <input type="hidden" name="id" id="editOrderId">
                <div class="form-group">
                    <label>Order Status</label>
                    <select name="status" id="editOrderStatus" required>
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Status</button>
                    <button type="button" class="btn btn-secondary" onclick="closeEditOrderModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Customer Modal -->
    <div id="viewCustomerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Customer Details</h2>
                <button class="close-btn" onclick="closeViewCustomerModal()">&times;</button>
            </div>
            <div id="customerDetails" class="product-details-view" style="padding: 20px;"></div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h2>Confirm Delete</h2>
                <button class="close-btn" onclick="closeDeleteModal()">&times;</button>
            </div>
            <div style="padding: 30px; text-align: center;">
                <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: #FF3B5C; margin-bottom: 20px;"></i>
                <p id="deleteMessage" style="margin-bottom: 20px; color: var(--text-primary);">Are you sure you want to delete this item?</p>
                <p id="deleteItemName" style="margin-bottom: 30px; font-weight: 600; color: var(--text-primary);"></p>
                <div style="display: flex; gap: 15px;">
                    <button class="btn btn-danger" onclick="confirmDelete()" style="flex: 1;">Delete</button>
                    <button class="btn btn-secondary" onclick="closeDeleteModal()" style="flex: 1;">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <i class="fas fa-check-circle"></i>
        <span id="toastMessage">Action completed successfully!</span>
    </div>

    <script>
        // Global variables
        let currentPage = 'dashboard';
        let deleteId = null;
        let deleteType = null;

        // Page Navigation
        function switchPage(pageName) {
            document.querySelectorAll('.nav-links li').forEach(li => {
                li.classList.remove('active');
            });
            document.querySelector(`.nav-links li[data-page="${pageName}"]`).classList.add('active');
            
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active-page');
            });
            document.getElementById(`${pageName}-page`).classList.add('active-page');
            currentPage = pageName;
        }

        // Theme toggle with localStorage
        function toggleTheme() {
            document.body.classList.toggle('light-theme');
            const icon = document.querySelector('.theme-toggle i');
            if (document.body.classList.contains('light-theme')) {
                icon.className = 'fas fa-sun';
                localStorage.setItem('theme', 'light');
            } else {
                icon.className = 'fas fa-moon';
                localStorage.setItem('theme', 'dark');
            }
        }

        // Load saved theme
        function loadTheme() {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                document.body.classList.add('light-theme');
                document.querySelector('.theme-toggle i').className = 'fas fa-sun';
            }
        }

        // Search function
        function handleSearch() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            let tableBody;
            
            if (currentPage === 'dashboard' || currentPage === 'products') {
                tableBody = document.getElementById('productsPageBody') || document.getElementById('productsBody');
            } else if (currentPage === 'orders') {
                tableBody = document.getElementById('ordersTableBody');
            } else if (currentPage === 'customers') {
                tableBody = document.getElementById('customersTableBody');
            }
            
            if (tableBody) {
                const rows = tableBody.getElementsByTagName('tr');
                for (let row of rows) {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(searchTerm) ? '' : 'none';
                }
            }
        }

        // Filter functions
        function filterByCategory() {
            const category = document.getElementById('categoryFilter').value;
            const rows = document.querySelectorAll('#productsBody tr, #productsPageBody tr');
            rows.forEach(row => {
                const rowCategory = row.querySelector('.category-badge')?.textContent || '';
                row.style.display = (category === '' || rowCategory === category) ? '' : 'none';
            });
        }

        function sortProducts() {
            const sortBy = document.getElementById('sortFilter').value;
            const tbody = document.getElementById('productsBody') || document.getElementById('productsPageBody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            
            rows.sort((a, b) => {
                switch(sortBy) {
                    case 'name':
                        return a.querySelector('.product-details h4').textContent.localeCompare(b.querySelector('.product-details h4').textContent);
                    case 'price_low':
                        return parseFloat(a.querySelector('.price-cell').textContent.replace('₱', '')) - parseFloat(b.querySelector('.price-cell').textContent.replace('₱', ''));
                    case 'price_high':
                        return parseFloat(b.querySelector('.price-cell').textContent.replace('₱', '')) - parseFloat(a.querySelector('.price-cell').textContent.replace('₱', ''));
                    case 'stock_low':
                        return parseInt(a.querySelector('.stock-cell').textContent) - parseInt(b.querySelector('.stock-cell').textContent);
                    default:
                        return 0;
                }
            });
            
            tbody.innerHTML = '';
            rows.forEach(row => tbody.appendChild(row));
        }

        // Settings tabs
        function switchSettingsTab(tabName) {
            document.querySelectorAll('.settings-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            event.target.classList.add('active');
            
            document.querySelectorAll('.settings-section').forEach(section => {
                section.classList.remove('active-section');
            });
            document.getElementById(`${tabName}-settings`).classList.add('active-section');
        }

        // Toast notification
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            toastMessage.textContent = message;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 3000);
        }

        // Product Modal functions
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Add New Product';
            document.getElementById('formAction').value = 'add';
            document.getElementById('productForm').reset();
            document.getElementById('productId').value = '';
            document.getElementById('productModal').style.display = 'block';
        }

        function openEditModal(id, name, description, price, quantity, category) {
            document.getElementById('modalTitle').textContent = 'Edit Product';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('productId').value = id;
            document.getElementById('productName').value = name;
            document.getElementById('productDescription').value = description;
            document.getElementById('productPrice').value = price;
            document.getElementById('productQuantity').value = quantity;
            document.getElementById('productCategory').value = category;
            document.getElementById('productModal').style.display = 'block';
        }

        function openViewModal(product) {
            const status = product.quantity > 20 ? 'In Stock' : (product.quantity > 0 ? 'Low Stock' : 'Out of Stock');
            const statusClass = product.quantity > 20 ? 'status-instock' : (product.quantity > 0 ? 'status-low' : 'status-out');
            
            const detailsHtml = `
                <div>
                    <p style="color: var(--text-primary);"><strong>Name:</strong> ${product.name}</p>
                    <p style="color: var(--text-primary);"><strong>Category:</strong> ${product.category || 'Accessories'}</p>
                    <p style="color: var(--text-primary);"><strong>Price:</strong> ₱${parseFloat(product.price).toFixed(2)}</p>
                    <p style="color: var(--text-primary);"><strong>Quantity:</strong> ${product.quantity} units</p>
                    <p style="color: var(--text-primary);"><strong>Status:</strong> <span class="status-badge ${statusClass}">${status}</span></p>
                    <p style="color: var(--text-primary);"><strong>Description:</strong> ${product.description || 'No description'}</p>
                </div>
            `;
            
            document.getElementById('productDetails').innerHTML = detailsHtml;
            document.getElementById('viewModal').style.display = 'block';
        }

        function closeModal() {
            const modal = document.getElementById('productModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        function closeViewModal() {
            const modal = document.getElementById('viewModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        // Customer Modal functions
        function openAddCustomerModal() {
            document.getElementById('customerModalTitle').textContent = 'Add Customer';
            document.getElementById('customerFormAction').name = 'add_customer';
            document.getElementById('customerFormAction').value = '1';
            document.getElementById('customerId').value = '';
            document.getElementById('customerFirstName').value = '';
            document.getElementById('customerLastName').value = '';
            document.getElementById('customerEmail').value = '';
            document.getElementById('customerPhone').value = '';
            document.getElementById('customerAddress').value = '';
            document.getElementById('customerCity').value = '';
            document.getElementById('customerType').value = 'regular';
            document.getElementById('customerSubmitBtn').textContent = 'Save Customer';
            document.getElementById('customerModal').style.display = 'block';
        }

        function openCustomerEditModal(customer) {
            document.getElementById('customerModalTitle').textContent = 'Edit Customer';
            document.getElementById('customerFormAction').name = 'edit_customer';
            document.getElementById('customerFormAction').value = '1';
            document.getElementById('customerId').value = customer.id;
            document.getElementById('customerFirstName').value = customer.first_name;
            document.getElementById('customerLastName').value = customer.last_name;
            document.getElementById('customerEmail').value = customer.email;
            document.getElementById('customerPhone').value = customer.phone || '';
            document.getElementById('customerAddress').value = customer.address || '';
            document.getElementById('customerCity').value = customer.city || '';
            document.getElementById('customerType').value = customer.customer_type || 'regular';
            document.getElementById('customerStatus').value = customer.status || 'active';
            document.getElementById('customerSubmitBtn').textContent = 'Update Customer';
            document.getElementById('customerModal').style.display = 'block';
        }

        function openCustomerViewModal(customer) {
            const detailsHtml = `
                <div>
                    <p style="color: var(--text-primary);"><strong>Name:</strong> ${customer.first_name} ${customer.last_name}</p>
                    <p style="color: var(--text-primary);"><strong>Email:</strong> ${customer.email}</p>
                    <p style="color: var(--text-primary);"><strong>Phone:</strong> ${customer.phone || 'N/A'}</p>
                    <p style="color: var(--text-primary);"><strong>Address:</strong> ${customer.address || 'N/A'}, ${customer.city || 'N/A'}</p>
                    <p style="color: var(--text-primary);"><strong>Type:</strong> ${customer.customer_type}</p>
                    <p style="color: var(--text-primary);"><strong>Status:</strong> ${customer.status}</p>
                    <p style="color: var(--text-primary);"><strong>Joined:</strong> ${new Date(customer.created_at).toLocaleDateString()}</p>
                </div>
            `;
            document.getElementById('customerDetails').innerHTML = detailsHtml;
            document.getElementById('viewCustomerModal').style.display = 'block';
        }

        function closeCustomerModal() {
            const modal = document.getElementById('customerModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        function closeViewCustomerModal() {
            const modal = document.getElementById('viewCustomerModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        // New Order Modal functions
        function openNewOrderModal() {
            document.getElementById('newOrderModal').style.display = 'block';
        }

        function closeNewOrderModal() {
            const modal = document.getElementById('newOrderModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        // Order Modal functions
        function openViewOrderModal(order) {
            const statusClass = order.status === 'completed' ? 'status-instock' : (order.status === 'pending' ? 'status-out' : 'status-low');
            
            const detailsHtml = `
                <div>
                    <p style="color: var(--text-primary);"><strong>Order #:</strong> ${order.order_number}</p>
                    <p style="color: var(--text-primary);"><strong>Customer:</strong> ${order.customer_name}</p>
                    <p style="color: var(--text-primary);"><strong>Email:</strong> ${order.customer_email}</p>
                    <p style="color: var(--text-primary);"><strong>Date:</strong> ${new Date(order.order_date).toLocaleString()}</p>
                    <p style="color: var(--text-primary);"><strong>Total:</strong> ₱${parseFloat(order.total_amount).toFixed(2)}</p>
                    <p style="color: var(--text-primary);"><strong>Payment Method:</strong> ${order.payment_method || 'N/A'}</p>
                    <p style="color: var(--text-primary);"><strong>Status:</strong> <span class="status-badge ${statusClass}">${order.status}</span></p>
                </div>
            `;
            
            document.getElementById('orderDetails').innerHTML = detailsHtml;
            document.getElementById('viewOrderModal').style.display = 'block';
        }

        function openEditOrderModal(order) {
            document.getElementById('editOrderId').value = order.id;
            document.getElementById('editOrderStatus').value = order.status;
            document.getElementById('editOrderModal').style.display = 'block';
        }

        function closeViewOrderModal() {
            const modal = document.getElementById('viewOrderModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        function closeEditOrderModal() {
            const modal = document.getElementById('editOrderModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
        }

        // Delete Modal functions
        function openDeleteProductModal(id, name) {
            deleteId = id;
            deleteType = 'product';
            document.getElementById('deleteMessage').textContent = 'Are you sure you want to delete this product?';
            document.getElementById('deleteItemName').textContent = `"${name}"`;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function openDeleteCustomerModal(id, name) {
            deleteId = id;
            deleteType = 'customer';
            document.getElementById('deleteMessage').textContent = 'Are you sure you want to delete this customer?';
            document.getElementById('deleteItemName').textContent = `"${name}"`;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function closeDeleteModal() {
            const modal = document.getElementById('deleteModal');
            modal.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                modal.style.animation = '';
            }, 200);
            deleteId = null;
            deleteType = null;
        }

        function confirmDelete() {
            if (!deleteId || !deleteType) return;
            
            let url = deleteType === 'product' ? `?delete_product=${deleteId}` : `?delete_customer=${deleteId}`;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast(`${deleteType} deleted successfully!`);
                        const row = document.querySelector(`tr[data-${deleteType}-id="${deleteId}"]`);
                        if (row) {
                            row.remove();
                        }
                        closeDeleteModal();
                    } else {
                        showToast(`Error deleting ${deleteType}`, 'error');
                        closeDeleteModal();
                    }
                })
                .catch(error => {
                    showToast(`Error deleting ${deleteType}`, 'error');
                    closeDeleteModal();
                });
        }

        // Export function
        function exportTableToCSV(type) {
            showToast(`Exporting ${type}...`, 'info');
        }

        // Update footer time
        function updateFooterTime() {
            const now = new Date();
            document.getElementById('currentTime').textContent = now.toLocaleTimeString();
            document.getElementById('currentDate').textContent = now.toLocaleDateString();
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const modals = ['productModal', 'viewModal', 'customerModal', 'viewCustomerModal', 'newOrderModal', 'viewOrderModal', 'editOrderModal', 'deleteModal'];
            modals.forEach(modalId => {
                const modal = document.getElementById(modalId);
                if (event.target == modal) {
                    modal.style.animation = 'fadeOut 0.3s ease';
                    setTimeout(() => {
                        modal.style.display = 'none';
                        modal.style.animation = '';
                    }, 200);
                }
            });
        }

        // Add fadeOut animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeOut {
                from {
                    opacity: 1;
                }
                to {
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            loadTheme();
            updateFooterTime();
            setInterval(updateFooterTime, 1000);
        });
    </script>

    <?php if (isset($_SESSION['toast'])): ?>
    <script>
        showToast(<?php echo json_encode($_SESSION['toast']['message']); ?>, <?php echo json_encode($_SESSION['toast']['type']); ?>);
    </script>
    <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
</body>
</html>