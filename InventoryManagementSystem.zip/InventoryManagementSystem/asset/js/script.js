// Add these new functions to your existing script.js

// New Order Modal functions
function openNewOrderModal() {
    document.getElementById('newOrderModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeNewOrderModal() {
    document.getElementById('newOrderModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Order functions (make them functional)
function viewOrder(order) {
    showToast(`Viewing order: ${order.order_number}`, 'info');
    // You can implement a view modal here
}

function editOrder(id) {
    showToast(`Edit order feature coming soon`, 'info');
    // You can implement edit functionality here
}

// Make sure these customer functions are defined
function openCustomerViewModal(customer) {
    // Your existing customer view code
    showToast(`Viewing customer: ${customer.first_name} ${customer.last_name}`, 'info');
}

function openCustomerEditModal(customer) {
    // Your existing customer edit code
    document.getElementById('customerModalTitle').textContent = 'Edit Customer';
    document.getElementById('customerFormAction').name = 'edit_customer';
    document.getElementById('customerFormAction').value = '1';
    document.getElementById('customerId').value = customer.id;
    document.getElementById('customerFirstName').value = customer.first_name;
    document.getElementById('customerLastName').value = customer.last_name;
    document.getElementById('customerEmail').value = customer.email;
    document.getElementById('customerPhone').value = customer.phone || '';
    document.getElementById('customerAddress').value = customer.address || '';
    document.getElementById('customerCity').value = customer.city || '';
    document.getElementById('customerType').value = customer.customer_type || 'regular';
    document.getElementById('customerStatus').value = customer.status || 'active';
    document.getElementById('customerSubmitBtn').textContent = 'Update Customer';
    document.getElementById('customerModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Make sure delete modals work
function openDeleteProductModal(id, name) {
    window.deleteId = id;
    window.deleteType = 'product';
    document.getElementById('deleteMessage').textContent = 'Are you sure you want to delete this product?';
    document.getElementById('deleteItemName').textContent = `"${name}"`;
    document.getElementById('deleteModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function openDeleteCustomerModal(id, name) {
    window.deleteId = id;
    window.deleteType = 'customer';
    document.getElementById('deleteMessage').textContent = 'Are you sure you want to delete this customer?';
    document.getElementById('deleteItemName').textContent = `"${name}"`;
    document.getElementById('deleteModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
    document.body.style.overflow = 'auto';
    window.deleteId = null;
    window.deleteType = null;
}

function confirmDelete() {
    if (!window.deleteId || !window.deleteType) return;
    
    let url = window.deleteType === 'product' ? `?delete_product=${window.deleteId}` : `?delete_customer=${window.deleteId}`;
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`${window.deleteType} deleted successfully!`);
                const row = document.querySelector(`tr[data-${window.deleteType}-id="${window.deleteId}"]`);
                if (row) {
                    row.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => {
                        row.remove();
                        closeDeleteModal();
                    }, 300);
                }
            } else {
                showToast(`Error deleting ${window.deleteType}`, 'error');
                closeDeleteModal();
            }
        })
        .catch(error => {
            showToast(`Error deleting ${window.deleteType}`, 'error');
            closeDeleteModal();
        });
}