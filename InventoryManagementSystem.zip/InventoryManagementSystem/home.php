<?php
// Start output buffering
ob_start();

require_once 'config.php';

// Require login
requireLogin();

// Get statistics
$totalProducts = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'] ?? 0;
$totalValue = $conn->query("SELECT SUM(price * quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$totalQuantity = $conn->query("SELECT SUM(quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$lowStock = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity < 10")->fetch_assoc()['count'] ?? 0;

// Get products for dashboard
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");

// Get categories for filter
$categories = $conn->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category");

$current_user = getCurrentUser();

// Include header
require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Welcome back, <?php echo ucfirst($current_user['username'] ?? 'Admin'); ?>! 🎉</h1>
        <p>Here's what's happening with your inventory today.</p>
    </div>
    <div></div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-box"></i>
        </div>
        <div class="stat-details">
            <h3>PRODUCTS</h3>
            <p class="stat-value"><?php echo $totalProducts; ?></p>
            <span class="stat-trend positive">Active items</span>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL VALUE</h3>
            <p class="stat-value">₱<?php echo number_format($totalValue, 2); ?></p>
            <span class="stat-trend positive">Inventory value</span>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-details">
            <h3>IN STOCK</h3>
            <p class="stat-value"><?php echo $totalQuantity; ?></p>
            <span class="stat-trend positive">Units available</span>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="stat-details">
            <h3>LOW STOCK</h3>
            <p class="stat-value"><?php echo $lowStock; ?></p>
            <span class="stat-trend positive">Need reorder</span>
        </div>
    </div>
</div>

<div class="filters-section">
    <div class="filter-group">
        <label>All Categories</label>
        <select id="categoryFilter" class="filter-select" onchange="filterByCategory()">
            <option value="">All Categories</option>
            <?php
            if ($categories && $categories->num_rows > 0) {
                while($row = $categories->fetch_assoc()) {
                    echo '<option value="' . htmlspecialchars($row['category']) . '">' . htmlspecialchars($row['category']) . '</option>';
                }
            }
            ?>
        </select>
    </div>
    
    <div class="filter-group">
        <label>Sort by:</label>
        <select id="sortFilter" class="filter-select" onchange="sortProducts()">
            <option value="newest">Newest First</option>
            <option value="name">Name A-Z</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
            <option value="stock_low">Stock: Low to High</option>
        </select>
    </div>
    
    <button class="btn btn-secondary" onclick="exportTableToCSV('products')">
        <i class="fas fa-download"></i>
        Export
    </button>
    
    <button class="btn btn-primary" onclick="openAddModal()">
        <i class="fas fa-plus"></i>
        Add New Product
    </button>
</div>

<div class="table-wrapper">
    <table class="products-table">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Category</th>
                <th>Product Description</th>
                <th>Price</th>
                <th>Quantity Stock/Units</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="productsBody">
            <?php if ($products && $products->num_rows > 0): ?>
                <?php while($row = $products->fetch_assoc()): 
                    $status = $row['quantity'] > 20 ? 'In Stock' : ($row['quantity'] > 0 ? 'Low Stock' : 'Out of Stock');
                    $statusClass = $row['quantity'] > 20 ? 'status-instock' : ($row['quantity'] > 0 ? 'status-low' : 'status-out');
                    $description = htmlspecialchars($row['description'] ?? '');
                ?>
                    <tr data-product-id="<?php echo $row['id']; ?>">
                        <td class="product-cell">
                            <div class="product-info">
                                <div class="product-icon">
                                    <i class="fas fa-box"></i>
                                </div>
                                <div class="product-details">
                                    <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                </div>
                            </div>
                        </td>
                        <td><span class="category-badge"><?php echo htmlspecialchars($row['category'] ?? 'Accessories'); ?></span></td>
                        <td><?php echo $description; ?></td>
                        <td class="price-cell">₱<?php echo number_format($row['price'], 2); ?></td>
                        <td class="stock-cell">
                            <select class="filter-select" style="width: auto;" onchange="updateStockQuantity(<?php echo $row['id']; ?>, this.value)">
                                <option value="<?php echo $row['quantity']; ?>" selected><?php echo $row['quantity']; ?> units</option>
                                <?php for($i = 1; $i <= 20; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?> units</option>
                                <?php endfor; ?>
                                <option value="25">25 units</option>
                                <option value="30">30 units</option>
                                <option value="40">40 units</option>
                                <option value="50">50 units</option>
                                <option value="75">75 units</option>
                                <option value="100">100 units</option>
                            </select>
                        </td>
                        <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                        <td class="actions-cell">
                            <button class="action-btn edit" onclick='openEditModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>, <?php echo json_encode($row['description'] ?? ''); ?>, <?php echo $row['price']; ?>, <?php echo $row['quantity']; ?>, <?php echo json_encode($row['category'] ?? ''); ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="action-btn delete" onclick='openDeleteProductModal(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>)' title="Delete"><i class="fas fa-trash"></i></button>
                            <button class="action-btn view" onclick='openViewModal(<?php echo json_encode($row); ?>)' title="View"><i class="fas fa-eye"></i></button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align: center; padding: 40px;">No products found. Click "Add New Product" to get started.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
// Include footer
require_once 'include/footer.php';
?>