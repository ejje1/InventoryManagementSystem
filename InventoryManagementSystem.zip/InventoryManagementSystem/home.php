<?php
// Start output buffering
ob_start();

require_once 'config.php';

// Require login
requireLogin();

// Get statistics
$totalProducts = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'] ?? 0;
$totalValue = $conn->query("SELECT SUM(price * quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$totalQuantity = $conn->query("SELECT SUM(quantity) as total FROM products")->fetch_assoc()['total'] ?? 0;
$lowStock = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity < 10")->fetch_assoc()['count'] ?? 0;

$current_user = getCurrentUser();

// Include header
require_once 'include/header.php';
?>

<div class="welcome-section">
    <div class="welcome-text">
        <h1>Welcome back, <?php echo ucfirst($current_user['username'] ?? 'Admin'); ?>! 🎉</h1>
        <p>Here's what's happening with your inventory today.</p>
    </div>
    <div></div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-box"></i>
        </div>
        <div class="stat-details">
            <h3>PRODUCTS</h3>
            <p class="stat-value"><?php echo $totalProducts; ?></p>
            <span class="stat-trend positive">Active items</span>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-details">
            <h3>TOTAL VALUE</h3>
            <p class="stat-value">₱<?php echo number_format($totalValue, 2); ?></p>
            <span class="stat-trend positive">Inventory value</span>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-details">
            <h3>IN STOCK</h3>
            <p class="stat-value"><?php echo $totalQuantity; ?></p>
            <span class="stat-trend positive">Units available</span>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="stat-details">
            <h3>LOW STOCK</h3>
            <p class="stat-value"><?php echo $lowStock; ?></p>
            <span class="stat-trend positive">Need reorder</span>
        </div>
    </div>
</div>

<?php
// Include footer
require_once 'include/footer.php';
?>