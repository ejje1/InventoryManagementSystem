            <!-- Footer Info -->
            <div class="footer-info">
                <div>
                    <i class="fas fa-search"></i> Type here to search
                </div>
                <div>
                    <i class="fas fa-sun"></i> <span id="weather">89°F Partly sunny</span>
                </div>
                <div>
                    <i class="far fa-clock"></i> <span id="currentTime"></span>
                </div>
                <div>
                    <i class="far fa-calendar"></i> <span id="currentDate"></span>
                </div>
            </div>
        </main>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <i class="fas fa-check-circle"></i>
        <span id="toastMessage">Action completed successfully!</span>
    </div>

    <script src="asset\js\script.js"></script>
    <script>
        // Update footer time
        function updateFooterTime() {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
            const dateStr = now.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' });
            
            document.getElementById('currentTime').textContent = timeStr;
            document.getElementById('currentDate').textContent = dateStr;
        }
        updateFooterTime();
        setInterval(updateFooterTime, 60000);
    </script>
</body>
</html>